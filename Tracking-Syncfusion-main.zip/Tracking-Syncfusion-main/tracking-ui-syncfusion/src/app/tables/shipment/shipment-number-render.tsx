import { useState, useMemo } from "react";
import type { CustomCellRendererProps } from "ag-grid-react";

import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import {
	Popover,
	PopoverClose,
	PopoverContent,
	PopoverDescription,
	PopoverHeader,
	PopoverTitle,
	PopoverTrigger,
} from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { MiniChatBox } from "@/components/mini-chat";
import { cn } from "@/lib/utils";
import {
	type ShipmentNotes,
	type ShipmentTypes,
} from "@/schemas/shipment-schema";
import {
	updateShipmentType,
	updateShipmentSB,
	addNewNoteWithShipmentId,
} from "@/services/shipment-api";
import MyCustomsBadge from "./badge";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";

import { useAuth } from "@/context/auth-context";
import { type User } from "@/schemas/user-schema";
import useDropDownEditList from "@/hooks/useDropDownEditList";

dayjs.extend(utc);
dayjs.extend(timezone);

const TIMEZONE_AU = "Australia/Sydney"; // Khóa cứng múi giờ Úc (Sydney)

const dateFormat = "DD/MM/YYYY HH:mm";
interface Props extends CustomCellRendererProps {
	dropDownEditList?: any;
}

export default function ShipmentNumberRender(props: Props) {
	const [isSending, setIsSending] = useState(false);

	const context = useAuth();

	const handleAddNote = async (noteText: string) => {
		setIsSending(true);
		if (noteText === "") {
			setIsSending(false);
			return;
		}
		try {
			const user: User = context?.user;
			if (!user) return;
			await addNewNoteWithShipmentId(
				props.data.shipment.id,
				user?.id,
				props.colDef?.colId ?? "",
				noteText,
			);

			setIsSending(false);
		} catch (error) {
			console.log(error);
			setIsSending(false);
		}
	};
	const onChangeShipmentType = (value: any) => {
		try {
			updateShipmentType(
				props.data?.shipment?.id,
				value,
				props.colDef?.colId || "",
			);
		} catch (error) {
			console.log(error);
		}
	};
	const onChangeShipmentSB = (value: any) => {
		try {
			updateShipmentSB(
				props.data?.shipment?.id,
				value,
				props.colDef?.colId || "",
			);
		} catch (error) {
			console.log(error);
		}
	};

	const dropDownEditList = useDropDownEditList();
	const types = dropDownEditList?.data?.shipment_type ?? [];

	const shipmenTypeRadioButton = () => {
		try {
			const output = (types ?? []).map((type: ShipmentTypes) => {
				return (
					<div className={cn("flex items-center gap-3 p-3")} key={type?.id}>
						<RadioGroupItem value={type?.id} id={type?.id?.toString()} />
						<Label htmlFor={type?.id?.toString()}>{type?.name ?? ""}</Label>
					</div>
				);
			});
			return output;
		} catch (error) {
			console.log(error);
			return [];
		}
	};

	// 1. Tối ưu mapping danh sách tin nhắn bằng useMemo
	const chatMessages = useMemo(() => {
		const notes = Array.isArray(props.data?.notes) ? props.data.notes : [];
		const users = dropDownEditList?.data?.users ?? [];

		return notes.map((n: ShipmentNotes) => {
			const foundUser = users.find((u: any) => u.id === n.user_id);
			return {
				id: n.id,
				userName: foundUser?.name ?? "Unknown", // Chống crash bằng optional chaining
				userId: n.user_id,
				message: n.note,
				time: dayjs(n.created_at).tz(TIMEZONE_AU).format(dateFormat),
			};
		});
	}, [props.data?.notes, dropDownEditList?.data?.users]);

	const isNew =
		props.data?.type?.name == null && props.data.info?.is_s_job == null;
	let is_s_job = "TBA";
	switch (props.data.info?.is_s_job) {
		case true:
			is_s_job = "S";
			break;
		case false:
			is_s_job = "B";
			break;
		default:
			is_s_job = "TBA";
			break;
	}

	return (
		<div className="flex max-w-90 items-center gap-2 ps-2">
			{/* Đưa Popover lên đầu để nằm bên trái */}

			<Popover>
				<PopoverTrigger>
					{isNew ? (
						<MyCustomsBadge text="new" />
					) : (
						<MyCustomsBadge text={props.data?.type?.name} type={is_s_job} />
					)}
				</PopoverTrigger>
				<PopoverContent className="min-w-[600px] p-4">
					<div className="flex flex-col gap-3">
						<div>
							<RadioGroup
								onValueChange={onChangeShipmentType}
								defaultValue={props?.data?.shipment?.shipments_type ?? ""}
								className="flex flex-row justify-between"
							>
								{shipmenTypeRadioButton()}
							</RadioGroup>
						</div>

						<Separator />
						<div>
							<RadioGroup
								className="flex flex-row justify-between"
								onValueChange={onChangeShipmentSB}
								defaultValue={props?.data?.info?.is_s_job ?? ""}
							>
								<div className="flex items-center gap-3 p-3 w-1/2">
									<RadioGroupItem value={true} id="true" />
									<Label htmlFor="true">S-Job</Label>
								</div>
								<div className="flex items-center gap-3 p-3  w-1/2">
									<RadioGroupItem value={false} id="false" />
									<Label htmlFor="false">B-Job</Label>
								</div>
							</RadioGroup>
						</div>

						<Separator />
						<div className="flex flex-col gap-2 border-t pt-3">
							<span className="text-xs font-semibold text-gray-500">Notes</span>

							{/* 1. Hiển thị ghi chú hiện có (cho phép cuộn nếu tràn) */}
							<MiniChatBox
								messages={chatMessages}
								className="h-80"
								handleSubmit={handleAddNote}
							/>
						</div>
					</div>

					<PopoverClose render={<Button>Close</Button>}></PopoverClose>
				</PopoverContent>

				{/* 			
			// 	title="Change job type"
			// 	trigger="click"
			// 	open={clicked}
			// 	onOpenChange={handleClickChange}
			// >
			// 	{isNew ? (
			// 		<MyCustomsBadge text="new" />
			// 	) : (
			// 		<MyCustomsBadge text={props.data?.type?.name} type={is_s_job} />
			// 	)} */}
			</Popover>

			{/* Chữ hiển thị phía sau */}

			<span>{props.data.shipment?.expedient_code}</span>

			{/* Tam giác màu đỏ góc trên bên phải */}
			{props.data.notes.length != 0 && (
				<div
					className="absolute top-0 right-0 w-0 h-0 
                                   border-t-[8px] border-t-red-600 
                                   border-l-[8px] border-l-transparent"
				/>
			)}
		</div>
	);
}
