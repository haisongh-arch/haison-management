import { z } from "zod";

const zNullableString = z.string().nullable();
const zNullableNumber = z.coerce.number().nullable();

export const VesselSchema = z.object({
	id: zNullableNumber,

	pod: zNullableString,
	terminal: zNullableString,
	name: zNullableString,
	lloyds: zNullableString,

	in_voyage: zNullableString,
	out_voyage: zNullableString,

	eta: zNullableString,
	pre_eta: zNullableString,
	etd: zNullableString,

	export_receive_start: zNullableString,
	export_haz_receive_start: zNullableString,
	export_empty_receive_start: zNullableString,

	export_reefer_cut_off: zNullableString,
	export_cargo_cut_off: zNullableString,
	export_haz_cut_off: zNullableString,
	export_empty_cut_off: zNullableString,

	first_available: zNullableString,
	first_free: zNullableString,
	storage_start: zNullableString,

	berth: zNullableString,
	line: zNullableString,
	route: zNullableString,

	updated_at: zNullableString,
});

export const VesselsSchema = z.array(VesselSchema);

export type Vessel = z.infer<typeof VesselSchema>;

export const VesselKey = VesselSchema.shape;

const DATE_FIELDS = new Set<keyof typeof VesselKey>([
	"eta",
	"etd",
	"export_receive_start",
	"export_haz_receive_start",
	"export_empty_receive_start",
	"export_reefer_cut_off",
	"export_cargo_cut_off",
	"export_haz_cut_off",
	"export_empty_cut_off",
	"first_available",
	"first_free",
	"storage_start",
	"updated_at",
]);

export function isVesselKeyDateFormat(field: keyof typeof VesselKey) {
	return DATE_FIELDS.has(field);
}
