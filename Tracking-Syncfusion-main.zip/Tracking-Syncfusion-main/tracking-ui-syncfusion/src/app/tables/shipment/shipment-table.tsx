import { useMemo, useRef, useEffect, useCallback, useState } from "react";

import { AllCommunityModule } from "ag-grid-community";
import {
	type ColDef,
	themeQuartz,
	type GetRowIdParams,
	type NewValueParams,
	type ValueGetterParams,
	type EditableCallbackParams,
	type ValueFormatterParams,
	type GridApi,
	type CellKeyDownEvent,
} from "ag-grid-community";
import {
	AgGridProvider,
	AgGridReact,
	type CustomCellRendererProps,
} from "ag-grid-react";

import { updateShipmentDetails } from "@/services/shipment-api";

import ContainerEditPopUp from "@/app/tables/shipment/container-cell-editor";

import CustomDatePicker from "@/components/date-picker";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { type Container } from "@/schemas/container-schema";

import { type Client } from "@/schemas/client-schema";
import { type Team } from "@/schemas/user-schema";
import {
	type ShipmentRefreshSignal,
	type ShipmentStatus,
	type ShipmentNotes,
} from "@/schemas/shipment-schema";

import ToEtaCell from "@/app/tables/shipment/to-eta-render";
import ShipmentNumberRender from "./shipment-number-render";
import useDropDownEditList from "@/hooks/useDropDownEditList";

import CustomRichSelect from "@/components/rich-select-cell-editor";
import CustomSetFilter from "@/app/ag-grid-utils/set-filter";
import { SetFilterHandler } from "@/app/ag-grid-utils/set-filter-handler";

import VesselCellEditor from "@/app/tables/shipment/vessel-cell-editor";

import { CellClass } from "./css-class";
import RequestPaymentRender from "./request-payment-render";
import CustomHeader from "./custom-column-header-aggrid";
import CustomGroupHeader from "./custom-columngroup-header-aggrid";

type Props = {
	data: any;
	refreshQueue: React.RefObject<ShipmentRefreshSignal[]>;
	refreshVersion: number;
	setGridApi: (params: GridApi) => void;
	searchTextForShipmentTable?: string;
	activeTab?: string;
	setPreviousActiveTab?: () => void;
};

dayjs.extend(utc);
dayjs.extend(timezone);

const TIMEZONE_AU = "Australia/Sydney"; // Khóa cứng múi giờ Úc (Sydney)

const dateFormat = "DD/MM/YYYY HH:mm";

const dateFormatNormal = "DD/MM/YYYY";
// Initilaize Table property

const COLUMN_STATE = "shipment-grid-column-state";
const COLUMN_DEFS = "shipment-grid-column-defs";
const AG_GRID_FONT_SIZE = "ag_grid_font_size";
const modules = [AllCommunityModule];

const defaultColDef = {
	cellStyle: {
		padding: 0,
		paddingLeft: 2,
	},
	// headerClass: "w-full",

	headerComponentParams: {
		innerHeaderComponent: CustomHeader,
	},
};

const defaultColGroupDef = {
	headerGroupComponentParams: {
		innerHeaderGroupComponent: CustomGroupHeader,
	},
};

function saveColumnsState(params: any) {
	try {
		const columnsSize = params.api.getColumnState();
		const columnsDef = params.api.getColumnDefs();
		localStorage.setItem(COLUMN_STATE, JSON.stringify(columnsSize));
		localStorage.setItem(COLUMN_DEFS, JSON.stringify(columnsDef));
	} catch (error) {}
}

function onGridReady(params: any) {
	try {
		const columnsSize = localStorage.getItem(COLUMN_STATE);
		const columnsDefs = localStorage.getItem(COLUMN_DEFS);
		if (columnsSize) {
			params.api.applyColumnState({
				state: JSON.parse(columnsSize),
				applyOrder: true,
			});
		}
		// 2. Restore thuộc tính columnGroupShow nhưng GIỮ NGUYÊN Custom Component gốc
		if (columnsDefs) {
			const savedDefs = JSON.parse(columnsDefs);
			const currentDefs = params.api.getColumnDefs() || [];

			// Hàm hợp nhất đệ quy (hỗ trợ cả Nhóm cột lồng nhau)
			const mergeGroupShow = (currentList: any[], savedList: any[]): any[] => {
				return currentList.map((col) => {
					// Tìm item tương ứng trong LocalStorage theo field hoặc colId
					const matched = savedList.find(
						(s) => (s.colId || s.field) === (col.colId || col.field),
					);

					let updatedCol = { ...col };

					// Khôi phục columnGroupShow nếu có
					if (matched?.columnGroupShow !== undefined) {
						updatedCol.columnGroupShow = matched.columnGroupShow;
					}

					// Đệ quy cho các cột con trong Group
					if (col.children && matched?.children) {
						updatedCol.children = mergeGroupShow(
							col.children,
							matched.children,
						);
					}

					return updatedCol;
				});
			};

			const updatedDefs = mergeGroupShow(currentDefs, savedDefs);

			// Cập nhật lại columnDefs an toàn mà không làm mất Component/Custom Header
			params.api.setGridOption("columnDefs", updatedDefs);
		}
	} catch (error) {}
}

export default function ShipmentTable(props: Props) {
	// Lấy trực tiếp dữ liệu đang nằm trong Cache (Không API Call, Không Stale Check)
	const { data: dropDownEditList, isPending: dropDownPending } =
		useDropDownEditList();

	// 1. Khởi tạo state từ localStorage (nếu có)
	const [fontSize, setFontSize] = useState<number>(() => {
		const saved = localStorage.getItem(AG_GRID_FONT_SIZE);
		return saved ? Number(saved) : 9;
	});

	// 2. Tự động tính headerFontSize tỉ lệ thuận (hoặc cho user chỉnh riêng)
	const headerFontSize = useMemo(() => fontSize + 1, [fontSize]);

	// 3. Tự động đồng bộ CSS Variable toàn cục cho các Portal / Cell Editor / Popover
	useEffect(() => {
		// Cập nhật lại biến :root để các Popover/Dialog con ăn theo ngay lập tức
		document.documentElement.style.setProperty(
			"--ag-font-size",
			`${fontSize}px`,
		);
		localStorage.setItem("ag_grid_font_size", String(fontSize));
	}, [fontSize]);

	// 4. Khai báo Theme động bằng useMemo (Chỉ re-calculate khi fontSize đổi)
	const myTheme = useMemo(() => {
		return themeQuartz.withParams({
			columnBorder: true,
			headerFontSize: headerFontSize,
			borderWidth: 1,
			borderColor: "#000",
			fontSize: fontSize, // 👈 Truyền giá trị từ state vào đây
		});
	}, [fontSize, headerFontSize]);

	// Hold grid API
	const gridRef = useRef<any>(null);

	// Khi statusRefMap đã sẵn sàng trong Context
	useEffect(() => {
		if (dropDownEditList?.statusRefMap && gridRef.current?.api) {
			// Ra lệnh cho AG Grid vẽ lại các ô Status để ăn theo context mới
			gridRef.current.api.refreshCells({
				columns: ["status.id"],
				force: true,
			});
		}
	}, [dropDownEditList?.statusRefMap]);
	// Process message queue to refresh cell
	useEffect(() => {
		try {
			const signals = props.refreshQueue.current.splice(0);

			if (!signals || signals.length === 0) return;

			let rowNodesToRefresh: any[] = [];
			let colIdsToRefresh: any[] = [];
			signals.forEach((signal: ShipmentRefreshSignal) => {
				const node = gridRef.current.api.getRowNode(signal.rowId);
				if (node) {
					rowNodesToRefresh.push(gridRef.current.api.getRowNode(signal.rowId));
					colIdsToRefresh.push(signal.colId);
				}
			});
			if (rowNodesToRefresh.length != 0) {
				gridRef.current.api.refreshCells({
					rowNodes: rowNodesToRefresh,
					columns: colIdsToRefresh,
					force: true,
				});
			}
		} catch (error) {
			console.log(error);
		}
	}, [props.refreshVersion]);

	// Grid selection
	const rowSelection: any = useMemo(() => {
		return {
			mode: "singleRow",
			checkboxes: false,
			enableClickSelection: true,
		};
	}, []);

	// GetRowID to prevent AG grid re-render whole list
	const getRowId = useMemo(() => {
		return (params: GetRowIdParams) => {
			const shipmentId = params.data?.shipment?.id;

			// Cảnh báo nếu ID bị undefined/null (thủ phạm khiến AG Grid không định danh được row)
			if (shipmentId == null) {
				console.warn(
					"[getRowId] WARNING: shipment.id is missing or undefined for row:",
					params.data,
				);
			}

			return String(shipmentId);
		};
	}, []);

	//Defind column
	const colDefs = useMemo<ColDef[]>(() => {
		return [
			//#region Mandatory columns
			//Shipment
			{
				field: "shipment.expedient_code",
				colId: "shipment.expedient_code",
				headerName: "Shipment",
				context: {
					targetTable: "shipments",
					targetColumn: "expedient_code",
				},
				editable: true,
				sortable: true,
				enableCellChangeFlash: true,
				pinned: true,

				filter: {
					component: CustomSetFilter,
					handler: SetFilterHandler,
				},
				// 2. Bật Floating Filter
				floatingFilter: true,
				floatingFilterComponent: "agTextColumnFloatingFilter",
				// 3. Chỉ định Floating Filter dùng giao diện Text đơn giản
				floatingFilterComponentParams: {
					suppressFilterButton: false, // Hiển thị hoặc ẩn nút phễu nhỏ bên cạnh ô text
				},
				cellRenderer: ShipmentNumberRender,
				cellClass: "!p-0 ",

				cellEditor: "agLargeTextCellEditor",
				cellEditorPopup: true,
				cellEditorPopupPosition: "under",
				cellEditorParams: {
					useFormatter: true,
					// 2. Cho phép xuống dòng
					wrapText: true,
					// (Tùy chọn) Giới hạn số ký tự tối đa
					maxLength: 200,
					// (Tùy chọn) Kích thước khung popup edit
					rows: 4,
					cols: 30,
				},
				getQuickFilterText: (params: any) => {
					return params.value;
				},
			},
			// Client
			{
				field: "shipment.client_id",
				colId: "shipment.client_id",
				headerName: "Client",
				context: {
					targetTable: "shipments",
					targetColumn: "client_id",
				},
				pinned: true,
				editable: true,
				sortable: true,
				enableCellChangeFlash: true,
				valueFormatter: (params: ValueFormatterParams) => {
					try {
						const clientId = params.value;
						if (clientId == null || clientId === "") return "";

						const clientRefMap = params.context?.clientRefMap;

						// Tra cứu linh hoạt từ context động
						return (
							clientRefMap?.[clientId] ??
							params.data?.client?.short_name ??
							clientId
						);
					} catch (error) {
						return "Error";
					}
				},
				filter: {
					component: CustomSetFilter,
					handler: SetFilterHandler,
				},
				getQuickFilterText: (params: any) => {
					const id = params.value;
					return params.context?.clientRefMap?.[id] ?? "";
				},

				// 2. Bật Floating Filter
				floatingFilter: true,
				floatingFilterComponent: "agTextColumnFloatingFilter",
				// 3. Chỉ định Floating Filter dùng giao diện Text đơn giản
				floatingFilterComponentParams: {
					suppressFilterButton: false, // Hiển thị hoặc ẩn nút phễu nhỏ bên cạnh ô text
				},

				cellEditor: CustomRichSelect,

				cellEditorParams: (params: any) => {
					const clients = params.context?.client || [];
					const values = clients.map((c: Client) => {
						return { value: c.id, label: c.short_name };
					});
					return {
						values: values,
					};
				},
			},
			// Status
			{
				field: "status.id",
				colId: "status.id",
				headerName: "Status",
				context: {
					targetTable: "shipments",
					targetColumn: "shipment_status_id",
				},
				pinned: true,
				editable: true,
				sortable: true,
				filter: {
					component: CustomSetFilter,
					handler: SetFilterHandler,
				},
				valueFormatter: (params: ValueFormatterParams) => {
					try {
						const id =
							params.value != null ? params.value : params.data.status.name;
						return (
							params.context?.statusRefMap?.[id] ?? params.data.status.name
						);
					} catch (error) {
						return "Error";
					}
				},
				// 2. Bật Floating Filter
				floatingFilter: true,
				floatingFilterComponent: "agTextColumnFloatingFilter",
				enableCellChangeFlash: true,
				cellEditor: CustomRichSelect,
				getQuickFilterText: (params: any) => {
					const id = params.value;
					const formatValue = params.context?.status?.find(
						(v: any) => v.id == id,
					);
					return formatValue?.name ?? "";
				},

				cellEditorParams: (params: any) => {
					const status = params.context?.status || [];
					const values = status.map((s: ShipmentStatus) => {
						return { value: s.id, label: s.name };
					});
					return {
						values: values,
					};
				},
				cellRenderer: (params: any) => {
					const id = params.value;

					const renderValue =
						params.valueFormatted || params.context?.statusRefMap?.[id] || "";

					if (!renderValue) return ""; // Evades empty state crash
					if (id <= 6) return renderValue;
					if (id > 6)
						return (
							<div className="flex items-center gap-1 w-full h-full text-left !p-1 bg-green-50 text-green-700 border border-green-300 rounded">
								{params.data?.info?.edo ? <span>✓</span> : <span>✘</span>}
								{renderValue}
							</div>
						);
				},
				cellClassRules: {
					"bg-[#8B0000] text-white": (params: any) =>
						[1, 2, 4, 6].includes(params.value),
					[CellClass.CELL_GREEN]: (params: any) => params.value == 5,
				},
				cellClass: "!p-0",
			},
			// To ETA
			{
				colId: "to_ETA",
				headerName: "To ETA",
				valueGetter: (p) => {
					const vesselEta = p.data?.vessel?.eta;
					const manualEta = p.data?.shipment?.manual_eta;
					const rawEta = vesselEta || manualEta;

					if (!rawEta) return 99999; // Hoặc trả về số cực lớn/bé nếu muốn đẩy lên đầu/cuối khi sort

					const eta = dayjs(rawEta).tz(TIMEZONE_AU);
					if (!eta.isValid()) return null;

					const now = dayjs().tz(TIMEZONE_AU);

					// Đặt true để lấy giá trị số thực (float) thay vì bị làm tròn nguyên
					// Ví dụ: 3.12456 thay vì 3
					return eta.diff(now, "day", true);
				},

				cellRenderer: ToEtaCell,
				cellClass: "!p-0",
				filter: "agNumberColumnFilter",
				filterParams: {
					// pass in additional parameters to the Number Filter
					buttons: ["clear"],
					defaultOption: "lessThanOrEqual",
				},
				filterValueGetter: (params: ValueGetterParams) => {
					const value = params.getValue("to_ETA");

					if (typeof value === "number") {
						return value ?? null;
					}
					return null;
				},
				pinned: true,
				editable: false,
				sortable: true,
				floatingFilter: true,
				enableCellChangeFlash: true,
				getQuickFilterText: (params: any) => {
					return "";
				},
			},
			//#endregion

			//#region B/L info
			{
				headerName: "B/L details",
				headerClass: CellClass.TABLE_HEADER_ORANGE,

				children: [
					//MBL
					{
						colId: "MBL",
						field: "shipment.mbl",
						headerName: "MBL",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						context: {
							targetTable: "shipments",
							targetColumn: "mbl",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},
					//HBL
					{
						colId: "HBL",
						field: "shipment.hbl",
						headerName: "HBL",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						context: {
							targetTable: "shipments",
							targetColumn: "hbl",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Containers (No target table, seperate API)
					{
						field: "containers",
						colId: "CONTAINERS",
						headerName: "Containers",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditorPopup: true,
						// cellEditorPopupPosition: "over",
						cellEditor: ContainerEditPopUp,
						cellEditorParams: {},
						suppressKeyboardEvent: (params: any) => {
							const key = ["Enter", "Tab"];
							if (key.includes(params.event.key)) {
								return true;
							}

							return false;
						},
						valueGetter: (params: any) => {
							let containers = params.data.containers;
							if (!containers || !Array.isArray(containers)) return "";
							return (containers = containers
								.map((c: any) => c.number)
								.join(", "));
						},
						filterValueGetter: (params: any) => {
							let containers = params.data.containers;
							if (!containers || !Array.isArray(containers)) return "";
							return (containers = containers
								.map((c: any) => c.number)
								.join(", "));
						},
						getQuickFilterText: (params: any) => {
							let containers = params.data.containers;
							if (!containers || !Array.isArray(containers)) return "";
							return (containers = containers
								.map((c: any) => c.number)
								.join(", "));
						},
					},

					//Container type (No target table, seperate API)
					{
						field: "containers",
						colId: "CONTAINER-TYPE",
						headerName: "Type",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						columnGroupShow: "close",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueGetter: (params: ValueGetterParams) => {
							const containers = params.data.containers;
							if (
								!containers ||
								!Array.isArray(containers) ||
								containers.length === 0
							)
								return "";

							// 1. Dùng reduce để đếm số lượng từng loại container
							const counts = containers.reduce(
								(acc: Record<string, number>, container: Container) => {
									const typeID = container.type;
									const typeObj = params.context?.container_types?.find(
										(t: any) => t.id === typeID,
									);
									const typeName = typeObj?.name || "Unknown";

									// Tăng biến đếm
									acc[typeName] = (acc[typeName] || 0) + 1;
									return acc;
								},
								{},
							);

							// 2. Chuyển Object đếm được thành chuỗi hiển thị (VD: "2x 20GP, 1x 40HC")
							return Object.entries(counts)
								.map(([name, count]) => `${count}x${name}`)
								.join(" , ");
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},

					//PO & Quote
					{
						colId: "PO",
						field: "shipment.po",
						headerName: "PO & Quote",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						context: {
							targetTable: "shipments",
							targetColumn: "po",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Shipper
					{
						colId: "SHIPPER",
						field: "shipment.shipper",
						headerName: "Shipper",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						context: {
							targetTable: "shipments",
							targetColumn: "shipper",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Product
					{
						colId: "PRODUCT",
						field: "shipment.product",
						headerName: "Product",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						context: {
							targetTable: "shipments",
							targetColumn: "product",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Gross weight
					{
						colId: "GROSS WEIGHT",
						field: "info.gross_weight",
						headerName: "G.Weight",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						context: {
							targetTable: "shipment_info",
							targetColumn: "gross_weight",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Charge weight
					{
						colId: "CHARGE WEIGHT",
						field: "info.charge_weight",
						headerName: "C.Weight",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						context: {
							targetTable: "shipment_info",
							targetColumn: "charge_weight",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Unit
					{
						colId: "UNIT",
						field: "info.unit",
						headerName: "Unit",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						context: {
							targetTable: "shipment_info",
							targetColumn: "unit",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//POL
					{
						colId: "POL",
						field: "shipment.pol",
						headerName: "POL",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						context: {
							targetTable: "shipments",
							targetColumn: "pol",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//POD
					{
						colId: "POD",
						field: "shipment.pod",
						headerName: "POD",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						context: {
							targetTable: "shipments",
							targetColumn: "pod",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,

						filter: {
							component: CustomSetFilter,
							handler: SetFilterHandler,
						},
						// 2. Bật Floating Filter
						floatingFilter: true,
						floatingFilterComponent: "agTextColumnFloatingFilter",
						enableCellChangeFlash: true,
						filterValueGetter: (params: any) => {
							let pod = params.data.shipment.pod;
							if (!pod) return "";
							return pod;
						},
						cellEditor: CustomRichSelect,

						cellEditorParams: (params: any) => {
							const pod = params.context.pod || [];
							const values = pod.map((pod: String) => {
								return { value: pod, label: pod };
							});
							return {
								values: values,
							};
						},
						onCellValueChanged: (params: NewValueParams) => {
							if (params.oldValue != params.newValue) {
								params.node?.setDataValue("vessel", { id: null, name: "" });
							}
						},
					},
				],
			},
			//#endregion

			//#region Vessel details
			{
				headerName: "Vessel",
				headerClass: CellClass.TABLE_HEADER_PURPLE,
				children: [
					//Vessel name
					{
						field: "shipment.vessel_id",
						colId: "vessel",
						headerName: "Vessel",
						headerClass: CellClass.TABLE_HEADER_PURPLE,
						context: {
							targetTable: "shipments",
							targetColumn: "vessel_id",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						cellDataType: false,
						filter: {
							component: CustomSetFilter,
							handler: SetFilterHandler,
						},

						// 2. Bật Floating Filter
						floatingFilter: true,
						floatingFilterComponent: "agTextColumnFloatingFilter",
						// 3. Chỉ định Floating Filter dùng giao diện Text đơn giản
						floatingFilterComponentParams: {
							suppressFilterButton: false, // Hiển thị hoặc ẩn nút phễu nhỏ bên cạnh ô text
						},
						enableCellChangeFlash: true,

						valueFormatter: (params: ValueFormatterParams) => {
							return params.data.shipment.vessel_id
								? params.data.vessel?.name
								: params.data.shipment.manual_vessel_name;
						},

						filterValueGetter: (params: any) => {
							return params.data.shipment.vessel_id
								? params.data.vessel?.name
								: params.data.shipment.manual_vessel_name;
						},
						getQuickFilterText: (params: any) => {
							return params.data.shipment.vessel_id
								? params.data.vessel?.name
								: params.data.shipment.manual_vessel_name;
						},
						cellRenderer: (params: CustomCellRendererProps) => {
							if (
								!params.data.shipment?.vessel_id &&
								(!params.data.shipment?.manual_vessel_name ||
									params.data.shipment?.manual_vessel_name == "")
							)
								return (
									<div className="flex items-center gap-1 w-full h-full !p-1 bg-amber-50 text-amber-700 border border-amber-300 rounded font-medium">
										<span>⚠</span>
										<span>Pls update vessel</span>
									</div>
								);
							else if (
								!params.data.shipment?.vessel_id &&
								params.data.shipment.manual_vessel_name
							)
								return (
									<div className="flex items-center gap-0.5 w-full h-full bg-amber-50 text-amber-700 border border-amber-300 rounded ">
										<span>⚠</span>
										{params.data.shipment.manual_vessel_name}
									</div>
								);
							else if (
								params.data.vessel?.name &&
								params.data.vessel.first_available
							)
								return (
									<div className="flex items-center gap-0.5 w-full h-full bg-green-50 text-green-700 border border-green-300 rounded ">
										{params.data.vessel?.name}
									</div>
								);
							else return params.data.vessel?.name ?? "";
						},
						cellClass: "!p-0",
						cellEditor: VesselCellEditor,
					},

					//Vessel voy
					{
						field: "shipment.manual_vessel_voy",
						colId: "VESSEL_VOY",
						headerName: "Voy",
						headerClass: CellClass.TABLE_HEADER_PURPLE,
						columnGroupShow: "close",
						context: {
							targetTable: "shipments",
							targetColumn: "manual_vessel_voy",
						},
						editable: (params: EditableCallbackParams) => {
							return params.data.shipment?.vessel_id != null ? false : true;
						},
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueGetter: (params: ValueGetterParams) => {
							const voy =
								params.data.vessel?.in_voyage ||
								params.data.shipment.manual_vessel_voy;
							return voy;
						},
						cellClass: "!p-0",
						cellRenderer: (params: CustomCellRendererProps) => {
							if (!params.data.vessel) {
								return (
									<div className="flex items-center gap-0.5 w-full h-full  bg-amber-50 text-amber-700 border border-amber-300 rounded ">
										<span>⚠</span>
										{params.value}
									</div>
								);
							} else if (
								params.data.vessel?.name &&
								params.data.vessel?.first_available
							)
								return (
									<div className="flex items-center gap-0.5 w-full h-full bg-green-50 text-green-700 border border-green-300 rounded ">
										{params.value}
									</div>
								);
							else return params.value;
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},
					//ETD
					{
						field: "shipment.manual_etd",
						colId: "ETD",
						headerName: "ETD Transit",
						headerClass: CellClass.TABLE_HEADER_PURPLE,
						columnGroupShow: "close",
						context: {
							targetTable: "shipments",
							targetColumn: "manual_etd",
						},
						editable: (params: EditableCallbackParams) => {
							return params.data.vessel ? false : true;
						},
						cellEditor: CustomDatePicker,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueFormatter: (params: ValueFormatterParams) => {
							const value = params?.data?.shipment?.manual_etd;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},
					//ETA
					{
						field: "shipment.manual_eta",
						colId: "ETA",
						headerName: "ETA",
						headerClass: CellClass.TABLE_HEADER_PURPLE,
						columnGroupShow: "close",
						context: {
							targetTable: "shipments",
							targetColumn: "manual_eta",
						},
						editable: (params: EditableCallbackParams) => {
							return params.data.vessel ? false : true;
						},
						cellEditor: CustomDatePicker,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueFormatter: (params: ValueFormatterParams) => {
							let eta = params?.data?.vessel?.eta;
							if (eta) {
								return dayjs(eta).tz(TIMEZONE_AU).format(dateFormat);
							} else {
								eta = params.data.shipment.manual_eta;
								if (!eta) return "";
								return dayjs(eta).tz(TIMEZONE_AU).format(dateFormat);
							}
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},

					//Vessel FA
					{
						field: "vessel.first_available",
						colId: "FIRST AVAILABLE",
						headerName: "First Available",
						headerClass: CellClass.TABLE_HEADER_PURPLE,
						context: {
							targetTable: "vessels",
							targetColumn: "first_available",
						},
						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueGetter: (params: ValueGetterParams) => {
							let fa = params?.data?.vessel?.first_available;
							if (fa) {
								return dayjs(fa).tz(TIMEZONE_AU).format(dateFormat);
							} else {
								return "";
							}
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},
					//Vessel FFD
					{
						field: "vessel.first_free",
						colId: "FIRST FREE DAY",
						headerName: "First Free Day",
						headerClass: CellClass.TABLE_HEADER_PURPLE,
						context: {
							targetTable: "vessels",
							targetColumn: "first_free",
						},
						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueGetter: (params: ValueGetterParams) => {
							let ffd = params?.data?.vessel?.first_free;
							if (ffd) {
								return dayjs(ffd).tz(TIMEZONE_AU).format(dateFormat);
							} else {
								return "";
							}
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},
					//Vessel Last Free
					{
						field: "vessel.storage_start",
						colId: "WHARF STORAGE",
						headerName: "Wharf Storage",
						headerClass: CellClass.TABLE_HEADER_PURPLE,
						context: {
							targetTable: "vessels",
							targetColumn: "storage_start",
						},
						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueGetter: (params: ValueGetterParams) => {
							let str = params?.data?.vessel?.storage_start;
							if (str) {
								return dayjs(str).tz(TIMEZONE_AU).format(dateFormat);
							} else {
								return "";
							}
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},
				],
			},
			//#endregion

			//#region Staff Check list
			{
				headerName: "Check List",
				headerClass: CellClass.TABLE_HEADER_GREEN,
				children: [
					//Pre-Alert
					{
						field: "info.pre_alert",
						colId: "Pre-Alert",
						headerName: "Pre-Alert",
						headerClass: CellClass.TABLE_HEADER_GREEN,
						context: {
							targetTable: "shipment_info",
							targetColumn: "pre_alert",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,
						valueFormatter: (params: ValueFormatterParams) => {
							const value = params?.data?.info?.pre_alert;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
						cellClassRules: {
							"bg-[#8B0000] text-white": (params: any) =>
								!params.value || params.value.toString().trim() === "",
							// [CellClass.CELL_GREEN]: (params: any) =>
							// 	Boolean(params.value && params.value.toString().trim() !== ""),
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},

					//Cartage Adivce
					{
						field: "info.cartage_advice",
						colId: "Cartage Advice",
						headerName: "Cartage",
						headerClass: CellClass.TABLE_HEADER_GREEN,
						context: {
							targetTable: "shipment_info",
							targetColumn: "cartage_advice",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,
						valueFormatter: (params: ValueFormatterParams) => {
							const value = params?.data?.info?.cartage_advice;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
						cellClassRules: {
							"bg-[#8B0000] text-white": (params: any) =>
								!params.value || params.value.toString().trim() === "",
							// [CellClass.CELL_GREEN]: (params: any) =>
							// 	Boolean(params.value && params.value.toString().trim() !== ""),
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},

					//EDO
					{
						field: "info.edo",
						colId: "EDO",
						headerName: "EDO",
						headerClass: CellClass.TABLE_HEADER_GREEN,
						context: {
							targetTable: "shipment_info",
							targetColumn: "edo",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,
						valueFormatter: (params: ValueFormatterParams) => {
							const value = params?.data?.info?.edo;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
						cellClassRules: {
							"bg-[#8B0000] text-white": (params: any) =>
								!params.value || params.value.toString().trim() === "",
							[CellClass.CELL_GREEN]: (params: any) =>
								Boolean(params.value && params.value.toString().trim() !== ""),
						},
						cellRenderer: RequestPaymentRender,
						cellRendererParams: {
							requestType: "EDO",
							requestParty: "SHIPPING_LINE",
							title: "Request EDO",
						},
						cellClass: "!p-0",
						getQuickFilterText: (params: any) => {
							return "";
						},
					},

					//Docs to broker
					{
						field: "info.docs_to_broker",
						colId: "Docs to broker",
						headerName: "Docs broker",
						headerClass: CellClass.TABLE_HEADER_GREEN,
						context: {
							targetTable: "shipment_info",
							targetColumn: "docs_to_broker",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,
						valueFormatter: (params: ValueFormatterParams) => {
							const value = params?.data?.info?.docs_to_broker;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
						cellClassRules: {
							"bg-[#8B0000] text-white": (params: any) =>
								!params.value || params.value.toString().trim() === "",
							[CellClass.CELL_GREEN]: (params: any) =>
								Boolean(params.value && params.value.toString().trim() !== ""),
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},

					//Get entry
					{
						field: "info.get_entry",
						colId: "Get Entry",
						headerName: "Entry",
						headerClass: CellClass.TABLE_HEADER_GREEN,
						context: {
							targetTable: "shipment_info",
							targetColumn: "get_entry",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,
						valueFormatter: (params: ValueFormatterParams) => {
							const value = params?.data?.info?.get_entry;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
						cellClassRules: {
							"bg-[#8B0000] text-white": (params: any) =>
								!params.value || params.value.toString().trim() === "",
							[CellClass.CELL_GREEN]: (params: any) =>
								Boolean(params.value && params.value.toString().trim() !== ""),
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},

					//Manifest
					{
						field: "info.manifest",
						colId: "Manifest",
						headerName: "Manifest",
						context: {
							targetTable: "shipment_info",
							targetColumn: "manifest",
						},
						columnGroupShow: "close",
						headerClass: CellClass.TABLE_HEADER_GREEN,
						editable: (params: EditableCallbackParams) => {
							if (!params.data.info.is_s_job) return false;
							return params.data.type.id == 1 ? true : false;
						},
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,

						cellClass: "!p-0",
						cellRenderer: (params: CustomCellRendererProps) => {
							if (!params.data.type || !params.data.info) {
								return (
									<div className="flex items-center gap-1 w-full h-full !p-1 bg-amber-50 text-amber-700 border border-amber-300 rounded font-medium">
										<span>⚠</span>
										<span>Invalid shipment type</span>
									</div>
								);
							}
							if (
								[1, 4].includes(params.data?.type?.id) &&
								params.data?.info?.is_s_job
							) {
								if (!params.value) return "";
								return dayjs(params?.value)
									.tz(TIMEZONE_AU)
									.format(dateFormatNormal);
							} else
								return (
									<div className="flex items-center gap-1 w-full h-full !p-1 bg-green-50 text-green-700 border border-green-300 rounded ">
										<span>✓</span>
										<span>None</span>
									</div>
								);
						},
						cellClassRules: {
							"bg-[#8B0000] text-white": (params: any) =>
								!params.value || params.value.toString().trim() === "",
							[CellClass.CELL_GREEN]: (params: any) =>
								Boolean(params.value && params.value.toString().trim() !== ""),
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},

					//SCR
					{
						field: "info.sea_cargo_report",
						colId: "SCR",
						headerName: "Sea Cargo Report",
						headerClass: CellClass.TABLE_HEADER_GREEN,
						context: {
							targetTable: "shipment_info",
							targetColumn: "sea_cargo_report",
						},
						columnGroupShow: "close",
						editable: (params: EditableCallbackParams) => {
							return params.data?.info?.is_s_job || false;
						},
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,

						cellRenderer: (params: CustomCellRendererProps) => {
							if (!params.data.info) {
								return (
									<div className="flex items-center gap-1 w-full h-full text-center !p-1 bg-amber-50 text-amber-700 border border-amber-300 rounded ">
										<span>⚠</span>
										<span>Invalid shipment type</span>
									</div>
								);
							}
							if (params.data.info?.is_s_job) {
								if (!params.value) return "";
								return dayjs(params.value).tz(TIMEZONE_AU).format(dateFormat);
							} else
								return (
									<div className="flex items-center gap-1 w-full h-full text-center  bg-green-50 text-green-700 border border-green-300 ">
										<span>✓</span>
										<span>None</span>
									</div>
								);
						},
						cellClass: "!p-0",
						cellClassRules: {
							"bg-[#8B0000] text-white": (params: any) =>
								!params.value || params.value.toString().trim() === "",
							[CellClass.CELL_GREEN]: (params: any) =>
								Boolean(params.value && params.value.toString().trim() !== ""),
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},
				],
			},
			//#endregion

			//#region Payment status
			{
				headerName: "Payments",
				children: [
					//Shipping line
					{
						field: "payment.invoice_port",
						colId: "Pay Shipping Line",
						headerName: "Shipping Line",
						context: {
							targetTable: "shipment_payments",
							targetColumn: "invoice_port",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,
						valueFormatter: (params: ValueGetterParams) => {
							const value = params?.data?.payment?.invoice_port;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
						cellClassRules: {
							"bg-[#8B0000] text-white": (params: any) =>
								!params.value || params.value.toString().trim() === "",
							[CellClass.CELL_GREEN]: (params: any) =>
								Boolean(params.value && params.value.toString().trim() !== ""),
						},
						cellRenderer: RequestPaymentRender,
						cellRendererParams: {
							requestType: "INVOICE",
							requestParty: "SHIPPING_LINE",
							title: "Request invoice",
						},
						cellClass: "!p-0",
						getQuickFilterText: (params: any) => {
							return "";
						},
					},

					//Broker
					{
						field: "payment.invoice_broker",
						colId: "Pay Broker",
						headerName: "Duty&GST",
						context: {
							targetTable: "shipment_payments",
							targetColumn: "invoice_broker",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,
						valueFormatter: (params: ValueGetterParams) => {
							const value = params?.data?.payment?.invoice_broker;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
						cellClassRules: {
							"bg-[#8B0000] text-white": (params: any) =>
								!params.value || params.value.toString().trim() === "",
							[CellClass.CELL_GREEN]: (params: any) =>
								Boolean(params.value && params.value.toString().trim() !== ""),
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},

					//Invoice O/F to client
					{
						field: "payment.invoice_client_ocean_freight",
						colId: "OCEAN FREIGHT TO CLIENT",
						headerName: "O/F To Client",
						context: {
							targetTable: "shipment_payments",
							targetColumn: "invoice_client_ocean_freight",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,
						valueFormatter: (params: ValueGetterParams) => {
							const value = params?.data?.payment?.invoice_client_ocean_freight;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
					},

					//Invoice Duty to client
					{
						field: "payment.invoice_client_duty",
						colId: "DUTY TO CLIENT",
						headerName: "DUTY To Client",
						context: {
							targetTable: "shipment_payments",
							targetColumn: "invoice_client_duty",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,
						valueFormatter: (params: ValueGetterParams) => {
							const value = params?.data?.payment?.invoice_client_duty;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},
					//Invoice PORT to client
					{
						field: "payment.invoice_client_port",
						colId: "PORT TO CLIENT",
						headerName: "PORT To Client",
						context: {
							targetTable: "shipment_payments",
							targetColumn: "invoice_client_port",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,
						valueFormatter: (params: ValueGetterParams) => {
							const value = params?.data?.payment?.invoice_client_port;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},
					//Invoice PORT to client
					{
						field: "payment.invoice_client_others",
						colId: "OTHERS TO CLIENT",
						headerName: "OTHERS To Client",
						context: {
							targetTable: "shipment_payments",
							targetColumn: "invoice_client_others",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						cellEditor: CustomDatePicker,
						valueFormatter: (params: ValueGetterParams) => {
							const value = params?.data?.payment?.invoice_client_others;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},
				],
			},
			//#endregion

			//#region Others
			{
				headerName: "Others",
				children: [
					// Team
					{
						field: "info.team_id",
						colId: "Teams",
						headerName: "Team",
						context: {
							targetTable: "shipment_info",
							targetColumn: "team_id",
						},
						columnGroupShow: "close",
						editable: true,
						sortable: true,
						filter: {
							component: CustomSetFilter,
							handler: SetFilterHandler,
						},

						// 2. Bật Floating Filter
						floatingFilter: true,
						floatingFilterComponent: "agTextColumnFloatingFilter",
						enableCellChangeFlash: true,
						filterValueGetter: (params: any) => {
							let team = params.data.teams;
							if (!team) return "";
							return team.name;
						},
						valueFormatter: (params: ValueGetterParams) => {
							const value = params?.data?.teams?.name;
							if (value) {
								return value;
							} else return "";
						},
						cellEditor: CustomRichSelect,

						cellEditorParams: (params: any) => {
							const teams = params.context?.teams || [];
							const values = teams.map((t: Team) => {
								return { value: t.id, label: t.name };
							});
							return {
								values: values,
							};
						},
						getQuickFilterText: (params: any) => {
							const value = params?.data?.teams?.name;
							if (value) {
								return value;
							} else return "";
						},
					},

					// Shipment type
					{
						field: "type.name",
						colId: "SHIPMENT-TYPE",
						headerName: "Types",
						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: {
							component: CustomSetFilter,
							handler: SetFilterHandler,
						},
						// 2. Bật Floating Filter
						floatingFilter: true,
						floatingFilterComponent: "agTextColumnFloatingFilter",
						// 3. Chỉ định Floating Filter dùng giao diện Text đơn giản
						floatingFilterComponentParams: {
							suppressFilterButton: false, // Hiển thị hoặc ẩn nút phễu nhỏ bên cạnh ô text
						},
						enableCellChangeFlash: true,
						getQuickFilterText: (params: any) => {
							return params.value;
						},
					},

					// Shipment Notes
					{
						field: "notes",
						colId: "SHIPMENT-NOTES",
						headerName: "Notes",
						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: {
							component: CustomSetFilter,
							handler: SetFilterHandler,
						},
						// 2. Bật Floating Filter
						floatingFilter: true,
						floatingFilterComponent: "agTextColumnFloatingFilter",
						// 3. Chỉ định Floating Filter dùng giao diện Text đơn giản
						floatingFilterComponentParams: {
							suppressFilterButton: false, // Hiển thị hoặc ẩn nút phễu nhỏ bên cạnh ô text
						},
						enableCellChangeFlash: true,
						valueGetter: (params: ValueGetterParams) => {
							return params.data.notes
								.map((n: ShipmentNotes) => {
									return n.note;
								})
								.join(",");
						},
						valueFormatter: (params: ValueFormatterParams) => {
							return params.data.notes
								.map((n: ShipmentNotes) => {
									return n.note;
								})
								.join(",");
						},
						getQuickFilterText: (params: any) => {
							return "";
						},
					},
					// Is For Mr.Geoff
					{
						field: "info.for_geoff",
						colId: "Steel",
						headerName: "Steel",
						context: {
							targetTable: "shipment_info",
							targetColumn: "for_geoff",
						},
						columnGroupShow: "open",
						editable: true,
						sortable: true,

						floatingFilter: true,
						filter: {
							component: CustomSetFilter,
							handler: SetFilterHandler,
						},
						valueGetter: (params: ValueGetterParams) => {
							if (params.data?.info?.for_geoff) return true;
							else return false;
						},
						enableCellChangeFlash: true,
						cellEditor: "agCheckboxCellEditor",
						cellRenderer: "agCheckboxCellRenderer",
						getQuickFilterText: (params: any) => {
							return "";
						},
					},
				],
			},
			//#endregion
		];
	}, []);

	const cellValueChanged = async (params: any) => {
		// 1. Helper làm sạch chuỗi
		const sanitize = (val: any) =>
			typeof val === "string" ? val.replace(/[\r\n\t]+/g, "").trim() : val;

		const cleanedOldValue = sanitize(params.oldValue);
		const cleanedNewValue = sanitize(params.newValue);

		if (cleanedOldValue === cleanedNewValue) return;

		const shipmentID = params.data.shipment?.id;
		if (!shipmentID) return;
		// 💡 Spread trực tiếp colDef.context và đè/thêm colId + newValue ngay tại chỗ
		const context = {
			...params.colDef.context,
			colId: params.colDef.colId,
			newValue: cleanedNewValue,
		};
		if (params.column.colId == "vessel") {
			if (context.newValue.id == null) {
				context.targetColumn = "manual_vessel_name";
				context.newValue = context.newValue.name;
			} else {
				context.targetColumn = "vessel_id";
				context.newValue = context.newValue.id;
			}
		}

		const result = await updateShipmentDetails(shipmentID, context);
		if (!result) {
		}
	};

	const handleKeyDown = useCallback(async (e: CellKeyDownEvent) => {
		// Kiểm tra phím Ctrl (hoặc Cmd trên Mac) + phím 'c' hoặc 'C'
		const keyDown = e.event as KeyboardEvent;
		if (
			(keyDown.ctrlKey || keyDown.metaKey) &&
			keyDown.key.toLowerCase() === "c"
		) {
			let valueCopy = e.value;
			if (e.colDef.colId === "vessel") {
				valueCopy = e.api.getCellValue({
					rowNode: e.node!,
					colKey: e.column,
					useFormatter: true,
				});
			}

			navigator.clipboard.writeText(valueCopy);
			// 2. Lấy thẻ ô AG Grid và add trực tiếp các utility class của Tailwind
			const target = keyDown.target as HTMLElement;
			const cellElement = target?.closest(".ag-cell") as HTMLElement;

			if (cellElement) {
				cellElement.classList.add("cell-copied-flash");

				setTimeout(() => {
					cellElement.classList.remove("cell-copied-flash");
				}, 400);
			}
		}

		if (
			(keyDown.ctrlKey || keyDown.metaKey) &&
			keyDown.key.toLowerCase() === "v"
		) {
			try {
				// 1. Đọc chuỗi văn bản bất đồng bộ từ Clipboard
				const textToPaste = await navigator.clipboard.readText();
				if (textToPaste !== undefined && textToPaste !== null) {
					// 2. Gán giá trị vào ô bằng e.column hoặc e.colDef.field
					if (typeof e.value === "number")
						return e.node?.setDataValue(e.column, Number(textToPaste.trim()));
					e.node?.setDataValue(e.column, textToPaste);
				}
			} catch (err) {
				console.error("Không thể đọc dữ liệu từ Clipboard:", err);
			}
		}
	}, []);

	return (
		<AgGridProvider modules={modules}>
			<div style={{ height: "100%", width: "100%" }}>
				<AgGridReact
					theme={myTheme}
					rowData={props.data}
					columnDefs={colDefs}
					defaultColDef={defaultColDef}
					defaultColGroupDef={defaultColGroupDef}
					onColumnResized={saveColumnsState}
					onColumnMoved={saveColumnsState}
					onColumnPinned={saveColumnsState}
					onColumnVisible={saveColumnsState}
					onSortChanged={saveColumnsState}
					onDisplayedColumnsChanged={saveColumnsState}
					onGridReady={(params) => {
						onGridReady(params);

						gridRef.current = params;
						props.setGridApi(params.api);
					}}
					onCellValueChanged={(params) => {
						cellValueChanged(params);
					}}
					getRowId={getRowId}
					undoRedoCellEditing={true}
					rowSelection={rowSelection}
					rowHeight={27}
					suppressDragLeaveHidesColumns={true}
					enableFilterHandlers={true}
					loading={!props.data || dropDownPending}
					onCellKeyDown={handleKeyDown}
					suppressMoveWhenColumnDragging={true}
					context={dropDownEditList}
				/>
			</div>
		</AgGridProvider>
	);
}
