export function arrayToMap<T>(
	array: T[] = [],
	keyField: keyof T,
	valueField: keyof T,
): Record<string | number, string> {
	return array.reduce(
		(list, item) => {
			if (item[keyField] !== undefined) {
				list[item[keyField] as any] = String(item[valueField] ?? "");
			}
			return list;
		},
		{} as Record<string | number, string>,
	);
}
