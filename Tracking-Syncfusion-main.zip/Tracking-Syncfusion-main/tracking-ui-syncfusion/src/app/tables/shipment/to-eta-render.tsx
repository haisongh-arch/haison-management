import { useState } from "react";
import type { CustomCellEditorProps } from "ag-grid-react";
import dayjs from "dayjs";
import MyCustomsBadge from "./badge";
import { Button } from "@/components/ui/button";
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from "@/components/ui/popover";

import { CellClass } from "./css-class";
import { confirmNewETA } from "@/services/shipment-api";
import type { Container } from "@/schemas/container-schema";

const TIMEZONE_AU = "Australia/Sydney";
const dateFormat = "DD/MM/YYYY HH:mm";

interface Props extends CustomCellEditorProps {}

export default function ToEtaCell(props: Props) {
	const [openPopover, setOpenPopover] = useState(false);

	let eta;
	props.data.vessel?.eta
		? (eta = dayjs(props.data.vessel.eta).tz(TIMEZONE_AU))
		: (eta = dayjs(props.data.shipment.manual_eta).tz(TIMEZONE_AU)) || null;

	if (!eta.isValid() || (!props.data.shipment.manual_eta && !props.data.vessel))
		return (
			<button
				type="button"
				className="w-full h-full text-destructive bg-destructive/10 hover:bg-destructive/20 border border-destructive/30 rounded px-2 py-1 flex items-center justify-center font-medium cursor-pointer"
				onClick={() => {
					const rowNode = props.api.getRowNode(props.node?.id || "");
					if (!rowNode) return;
					const rowIndex = rowNode.rowIndex;
					if (rowIndex == null) return;
					props.api.startEditingCell({
						rowIndex: rowIndex,
						colKey: "vessel",
					});
				}}
			>
				Invalid vessel
			</button>
		);

	const dayDiff = Math.floor(props.value + 0.3);
	const isWarm = dayDiff < 7;
	const isNewETA = !props.data.info?.is_read_new_eta;

	// Get Pre-ETA
	let preETARaw = "";
	if (props.data.vessel) {
		if (props.data.vessel.pre_eta && !props.data.shipment.manual_eta) {
			preETARaw = props.data.vessel.pre_eta;
		} else {
			preETARaw = props.data.shipment.manual_pre_eta;
		}
	} else {
		preETARaw = props.data.shipment.manual_pre_eta;
	}

	let preETA = "";
	if (preETARaw) preETA = dayjs(preETARaw).tz(TIMEZONE_AU).format(dateFormat);

	// Get New- ETA
	const newETARaw = props.data.vessel
		? props.data.vessel?.eta
		: props.data.shipment?.manual_eta;
	let newETA = "";
	if (newETARaw) newETA = dayjs(newETARaw).tz(TIMEZONE_AU).format(dateFormat);

	const handleSendEmail = () => {
		try {
			const sanitize = (val: any) =>
				typeof val === "string" ? val.replace(/[\r\n\t]+/g, "").trim() : val;
			const emailList = [
				props.data.client?.mail1,
				props.data.client?.mail2,
				props.data.client?.mail3,
				props.data.client?.mail4,
				props.data.client?.mail5,
				props.data.client?.mail6,
			].filter(Boolean);

			const containerList = props.data.containers
				?.map((c: Container) => c.number)
				.join("\n");

			const emailAddress = emailList.join("; ");

			const { po, shipper, product, pod, pol, mbl, hbl, expedient_code } =
				props.data?.shipment || {};
			const { unit, gross_weight, charge_weight } = props.data?.info || {};

			const emailSubject = `Update ETA ${mbl ? `-MB/L ${sanitize(mbl) || ""}` : ""}${hbl ? `-HBL ${sanitize(hbl) || ""}` : ""}${expedient_code ? ` -Our ref ${sanitize(expedient_code) || ""}` : ""}`;

			let emailPreETA;
			let emailNewETA;
			const hasVesselInfo = !!props.data.vessel;
			if (hasVesselInfo) {
				emailPreETA = props.data.vessel.pre_eta;
				emailNewETA = props.data.vessel.eta;
			} else {
				emailPreETA = props.data.shipment.manual_pre_eta;
				emailNewETA = props.data.shipment.manual_eta;
			}

			const bodyLines = [
				"Dear Valued customer,",
				" ",
				`As per the shipping line notification, we would like to update you that the subject shipment's ETA has been changed ${
					emailPreETA
						? `from ${dayjs(emailPreETA).tz(TIMEZONE_AU).format(dateFormat)} `
						: ""
				}to ${dayjs(emailNewETA).tz(TIMEZONE_AU).format(dateFormat)}.`,
				" ",
				mbl ? `MBL: ${mbl}` : null,
				hbl ? `HBL: ${hbl}` : null,
				pol ? `POL: ${pol}` : null,
				pod ? `POD: ${pod}` : null,
				po ? `PO & Quote: ${po}` : null,
				shipper ? `Shipper: ${shipper}` : null,
				product ? `Product: ${product}` : null,
				unit ? `Unit: ${unit}` : null,
				gross_weight ? `Gross weight: ${gross_weight}` : null,
				charge_weight ? `Gross weight: ${charge_weight}` : null,

				"",
				containerList ? "Container list:" : null,
				containerList,
			].filter(Boolean);

			const emailBody = bodyLines.join("\n");
			const mailtoUrl = `mailto:${emailAddress}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
			window.location.href = mailtoUrl;
		} catch (error) {
			console.error(error);
		}
	};

	return (
		<div
			className={`w-full h-full flex ${isNewETA ? "justify-start" : "justify-center"} relative ${isWarm ? CellClass.ANTD_ERROR : ""}`}
		>
			<span>{dayDiff}</span>
			{isNewETA && (
				<div className="absolute -top-2 right-0">
					<Popover open={openPopover} onOpenChange={setOpenPopover}>
						<PopoverTrigger
							render={<MyCustomsBadge text="new" />}
							nativeButton={false}
						/>
						<PopoverContent align="end" className="w-64 p-3">
							<div className="flex flex-col gap-2">
								<div className="font-semibold text-xs border-b pb-1.5 text-foreground">
									ETA Updated
								</div>
								<div className="text-xs text-muted-foreground">
									<span>Previous ETA: </span>
									<strong className="text-foreground font-semibold">
										{preETA || "N/A"}
									</strong>
								</div>
								<div className="text-xs text-muted-foreground">
									<span>New ETA: </span>
									<strong className="text-foreground font-semibold">
										{newETA || "N/A"}
									</strong>
								</div>
								<div className="flex gap-2 pt-2">
									<Button size="sm" onClick={handleSendEmail}>
										Email client
									</Button>
									<Button
										size="sm"
										variant="outline"
										onClick={() => {
											try {
												confirmNewETA(
													props.data.info.shipment_id,
													props?.colDef?.colId || "",
												);
												setOpenPopover(false);
											} catch (error) {
												console.error(error);
											}
										}}
									>
										Confirm
									</Button>
								</div>
							</div>
						</PopoverContent>
					</Popover>
				</div>
			)}
		</div>
	);
}
