import { z } from "zod";

const zNullableString = z.string().nullable();
const zNullableNumber = z.coerce.number().nullable();
const zNullableBoolean = z.coerce.boolean().nullable();

export const ShipmentSchema = z.object({
	id: zNullableNumber,
	expedient_code: zNullableString,
	client_id: zNullableNumber,
	mbl: zNullableString,
	hbl: zNullableString,
	product: zNullableString,
	po: zNullableString,
	pol: zNullableString,
	pod: zNullableString,
	shipper: zNullableString,
	free_days: zNullableNumber,
	shipments_type: zNullableNumber,
	vessel_id: zNullableNumber,
	shipment_status_id: zNullableNumber,
	manual_vessel_name: zNullableString,
	manual_vessel_voy: zNullableString,
	manual_etd: zNullableString,
	manual_eta: zNullableString,
	manual_pre_eta: zNullableString,
	created_at: zNullableString,
});
export const ShipmentSchemaArray = z.array(ShipmentSchema);

export const ShipmentInfoSchema = z.object({
	shipment_id: zNullableNumber,
	pre_alert: zNullableString,
	cartage_advice: zNullableString,
	docs_to_broker: zNullableString,
	entry: zNullableString,
	sea_cargo_report: zNullableString,
	manifest: zNullableString,
	arrival_notice: zNullableString,
	port_invoice: zNullableString,
	edo: zNullableString,
	team_id: zNullableNumber,
	is_read_new_eta: zNullableBoolean,
	get_entry: zNullableString,
	is_s_job: zNullableBoolean,
	gross_weight: zNullableString,
	charge_weight: zNullableString,
	unit: zNullableString,
	for_geoff: zNullableBoolean,
});
export const ShipmentInfoSchemaArray = z.array(ShipmentInfoSchema);

export const ShipmentNotesSchema = z.object({
	id: zNullableNumber,
	shipment_id: zNullableNumber,
	created_at: zNullableString,
	note: zNullableString,
	user_id: zNullableNumber,
});
export const ShipmentNotesSchemaArray = z.array(ShipmentNotesSchema);

export const ShipmentStatusSchema = z.object({
	id: zNullableNumber,
	name: zNullableString,
});
export const ShipmentStatusSchemaArray = z.array(ShipmentStatusSchema);

export const ShipmentTypesSchema = z.object({
	id: zNullableNumber,
	name: zNullableString,
});
export const ShipmentTypesSchemaArray = z.array(ShipmentTypesSchema);

export const ShipmentPaymentsSchema = z.object({
	shipment_id: zNullableNumber,
	invoice_port: zNullableString,
	invoice_broker: zNullableString,
	invoice_client_ocean_freight: zNullableString,
	invoice_client_duty: zNullableString,
	invoice_client_port: zNullableString,
	invoice_client_others: zNullableString,
});
export const ShipmentPaymentsSchemaArray = z.array(ShipmentPaymentsSchema);

export const ShipmentRefreshSignalSchema = z.object({
	rowId: zNullableString,
	colId: zNullableString,
});
export const ShipmentRefreshSignalSchemaArray = z.array(
	ShipmentRefreshSignalSchema,
);

export type Shipment = z.infer<typeof ShipmentSchema>;
export type ShipmentInfo = z.infer<typeof ShipmentInfoSchema>;
export type ShipmentNotes = z.infer<typeof ShipmentNotesSchema>;
export type ShipmentStatus = z.infer<typeof ShipmentStatusSchema>;
export type ShipmentTypes = z.infer<typeof ShipmentTypesSchema>;
export type ShipmentPayments = z.infer<typeof ShipmentPaymentsSchema>;
export type ShipmentRefreshSignal = z.infer<typeof ShipmentRefreshSignalSchema>;
