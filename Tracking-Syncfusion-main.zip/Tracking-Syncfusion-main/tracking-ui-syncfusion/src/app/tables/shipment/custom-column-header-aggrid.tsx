import React, { useState } from "react";
import type { CustomInnerHeaderProps } from "ag-grid-react";
import { Settings, Pin, Eye } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

import {
	Tooltip,
	TooltipContent,
	TooltipTrigger,
} from "@/components/ui/tooltip";

export interface MyCustomInnerHeaderProps extends CustomInnerHeaderProps {
	icon?: string;
}

export default function CustomColumnHeaderAGGrid(
	props: MyCustomInnerHeaderProps,
) {
	const [isMainMenuOpen, setIsMainMenuOpen] = useState(false);
	const [isFreezeOpen, setIsFreezeOpen] = useState(false);
	const [isChooseColumnOpen, setIsChooseColumnOpen] = useState(false);

	const handleTogglePin = (value: string) => {
		const pinnedType = value === "left" || value === "right" ? value : null;
		props.api?.setColumnsPinned(
			[props.column.getColId().toString()],
			pinnedType,
		);
		setIsFreezeOpen(false);
		setIsMainMenuOpen(false);
	};

	const colDefs = props.api?.getColumns() || [];

	const handleColumnToggle = (colId: string, isChecked: boolean) => {
		props.api.setColumnsVisible([colId], isChecked);
		setIsFreezeOpen(false);
		setIsMainMenuOpen(false);
	};

	const currentPinned =
		props.column?.getPinned() == null
			? "null"
			: String(props.column.getPinned());

	return (
		<Tooltip>
			<div className="flex items-center justify-between w-full customInnerHeader ">
				<TooltipTrigger>
					<div className="flex flex-1 items-center gap-1.5 overflow-hidden">
						{props.icon && <i className={`fa ${props.icon}`}></i>}
						<span className="truncate">{props.displayName}</span>
					</div>
				</TooltipTrigger>
				<TooltipContent>
					<p>{props.displayName}</p>
				</TooltipContent>
				<Popover open={isMainMenuOpen} onOpenChange={setIsMainMenuOpen}>
					<PopoverTrigger
						render={
							<Button
								variant="ghost"
								size="icon-xs"
								onClick={(e) => e.stopPropagation()}
								className="h-5 w-2 p-0 opacity-60 hover:opacity-100 justify-end"
							>
								<Settings className="size-2.5" />
							</Button>
						}
					/>
					<PopoverContent align="end" className="w-48 p-2 flex flex-col gap-1">
						{/* Pin Options */}
						<Popover open={isFreezeOpen} onOpenChange={setIsFreezeOpen}>
							<PopoverTrigger
								render={
									<Button
										variant="ghost"
										size="sm"
										className="w-full justify-start gap-2 text-xs"
									>
										<Pin className="size-3.5" />
										Pin options
									</Button>
								}
							/>
							<PopoverContent side="right" align="start" className="w-40 p-3">
								<RadioGroup
									value={currentPinned}
									onValueChange={handleTogglePin}
								>
									<div className="flex items-center gap-2">
										<RadioGroupItem value="left" id="pin-left" />
										<Label
											htmlFor="pin-left"
											className="cursor-pointer text-xs"
										>
											Pin Left
										</Label>
									</div>
									<div className="flex items-center gap-2">
										<RadioGroupItem value="right" id="pin-right" />
										<Label
											htmlFor="pin-right"
											className="cursor-pointer text-xs"
										>
											Pin Right
										</Label>
									</div>
									<div className="flex items-center gap-2">
										<RadioGroupItem value="null" id="unpin" />
										<Label htmlFor="unpin" className="cursor-pointer text-xs">
											Unpin
										</Label>
									</div>
								</RadioGroup>
							</PopoverContent>
						</Popover>
						{/* Choose Column Options */}
						<Popover
							open={isChooseColumnOpen}
							onOpenChange={setIsChooseColumnOpen}
						>
							<PopoverTrigger
								render={
									<Button
										variant="ghost"
										size="sm"
										className="w-full justify-start gap-2 text-xs text-destructive hover:text-destructive"
									>
										<Eye className="size-3.5" />
										Choose column
									</Button>
								}
							/>
							<PopoverContent side="right" align="start" className="w-52 p-3">
								<div className="max-h-60 overflow-y-auto flex flex-col gap-2">
									{colDefs.map((col: any) => {
										const colId = col.getColId();
										const label = col.getColDef().headerName || colId;
										const isVisible = col.isVisible();
										return (
											<label
												key={colId}
												className="flex items-center gap-2 text-xs cursor-pointer select-none"
											>
												<Checkbox
													checked={isVisible}
													onCheckedChange={(checked) =>
														handleColumnToggle(colId, !!checked)
													}
												/>
												<span className="truncate">{label}</span>
											</label>
										);
									})}
								</div>
							</PopoverContent>
						</Popover>
					</PopoverContent>
				</Popover>
			</div>
		</Tooltip>
	);
}
