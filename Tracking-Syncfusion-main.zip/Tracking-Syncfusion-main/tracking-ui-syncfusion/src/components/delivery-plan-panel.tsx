import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getDeliveryScheduleForNormalShipments } from "@/services/container-api";
import { DeliveryScheduleList } from "@/app/tables/shipment/delivery-schedule-list";
interface DeliveryPanelProps {
	open: boolean;
	onClose: () => void;
	children?: React.ReactNode;
	className?: string;
}

export function DeliveryPanel({
	open,
	onClose,
	children,
	className,
}: DeliveryPanelProps) {
	const { data, isLoading } = useQuery({
		queryKey: ["deliveries-plan"],
		queryFn: getDeliveryScheduleForNormalShipments,
		retry: true,
		enabled: open,
	});

	return (
		<aside
			className={cn(
				// Layout & Animation
				"border-l bg-background transition-all duration-300 ease-in-out flex flex-col shrink-0 h-full",
				// Khi mở: Hiện flex và rộng 320px (sm:w-80) hoặc tùy chỉnh
				// Khi đóng: w-0, overflow-hidden, border-none => HOÀN TOÀN KHÔNG CHIẾM DIỆN TÍCH
				// 1. MOBILE (<640px): Dùng Fixed Overlay trượt đè lên trên, không đụng chạm đến layout AG Grid
				"fixed right-0 top-0 w-[60vw] max-w-[360px] shadow-2xl z-1000",
				open ? "translate-x-0" : "translate-x-full",

				// 2. DESKTOP (>=640px): Trở về dạng Flex Sidebar đẩy nội dung song song
				"sm:static sm:z-auto sm:shadow-none sm:max-w-none sm:translate-x-0",
				open
					? "sm:w-80 sm:border-border sm:opacity-100"
					: "sm:w-0 sm:border-transparent sm:overflow-hidden sm:opacity-0 sm:pointer-events-none",

				className,
			)}
		>
			{/* Header của Panel */}
			<div className="flex items-center justify-between p-4 border-b h-[var(--header-height)] shrink-0">
				<h3 className="font-semibold ">Delivery Panel</h3>
				<Button
					variant="ghost"
					size="icon"
					className="h-7 w-7"
					onClick={onClose}
				>
					<X className="h-4 w-4" />
				</Button>
			</div>

			{/* Content bên trong Panel */}
			<div className="flex-1 h-full overflow-y-auto p-4 min-w-[280px]">
				<DeliveryScheduleList data={data} isLoading={isLoading} />
			</div>
		</aside>
	);
}
