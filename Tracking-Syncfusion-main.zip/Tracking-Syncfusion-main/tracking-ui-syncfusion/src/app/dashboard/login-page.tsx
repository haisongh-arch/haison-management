import { useState } from "react";
import { Navigate } from "react-router";
import HaiSonLogo from "@/assets/haison-logo.png";
import { Eye, EyeOff } from "lucide-react";

import { useAuth } from "@/context/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
	Card,
	CardContent,
	CardDescription,
	CardHeader,
	CardTitle,
} from "@/components/ui/card";

export default function LoginPage() {
	const [userName, setUserName] = useState("");
	const [passWord, setPassWord] = useState("");
	const [warning, setWarning] = useState("");
	const [showPassWord, setShowPassWord] = useState(false);
	const { user, logIn } = useAuth();

	const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
		e.preventDefault();
		try {
			await logIn(userName, passWord);
		} catch (err: any) {
			setWarning(err.message);
		}
	};

	if (user) {
		return <Navigate to="/" replace />;
	}

	return (
		<div className="flex min-h-screen items-center justify-center bg-muted/40 p-4">
			<Card className="w-full max-w-sm">
				<CardHeader className="text-center">
					<img
						alt="Hai Son logo"
						src={HaiSonLogo}
						className="mx-auto h-18 w-auto mb-2"
					/>
					<CardTitle className="text-2xl font-bold">
						Sign in to your account
					</CardTitle>
					<CardDescription>
						Enter your credentials to access your account
					</CardDescription>
				</CardHeader>
				<CardContent>
					<form onSubmit={handleSubmit} className="space-y-4">
						<div className="space-y-2">
							<Label htmlFor="username">User name</Label>
							<Input
								id="username"
								name="username"
								type="text"
								required
								value={userName}
								onChange={(e) => setUserName(e.target.value)}
								placeholder="Enter username"
							/>
						</div>

						<div className="space-y-2">
							<div className="flex items-center justify-between">
								<Label htmlFor="password">Password</Label>
								<a
									href="#"
									className="text-xs font-semibold text-primary hover:underline"
								>
									Forgot password?
								</a>
							</div>
							<div className="relative">
								<Input
									id="password"
									name="password"
									type={showPassWord ? "text" : "password"}
									required
									autoComplete="current-password"
									value={passWord}
									onChange={(e) => setPassWord(e.target.value)}
									placeholder="Enter password"
									className="pr-10"
								/>
								<button
									type="button"
									onClick={() => setShowPassWord(!showPassWord)}
									className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer"
								>
									{showPassWord ? (
										<EyeOff className="size-4" />
									) : (
										<Eye className="size-4" />
									)}
								</button>
							</div>
						</div>

						<Button type="submit" className="w-full">
							Sign in
						</Button>
					</form>

					{warning && (
						<div className="mt-4 text-center text-sm font-semibold text-destructive">
							{warning}
						</div>
					)}
				</CardContent>
			</Card>
		</div>
	);
}
