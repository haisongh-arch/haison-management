import { useQuery, useQueryClient } from "@tanstack/react-query";

import { useMemo, useRef, useCallback, useState } from "react";

import { AllCommunityModule, type CellKeyDownEvent } from "ag-grid-community";
import {
	type ColDef,
	themeQuartz,
	type GetRowIdParams,
	type RowEditingStoppedEvent,
} from "ag-grid-community";
import { AgGridProvider, AgGridReact } from "ag-grid-react";
import type { CustomCellEditorProps } from "ag-grid-react";

import {
	deleteContainer,
	updateContainerDetails,
	getContainerByShipment,
	addNewContainer,
	updateContainerDelivery,
} from "@/services/container-api";

import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

import ContainerRender from "./container-render";
import type { Container } from "@/schemas/container-schema";
import { ContainersSchema } from "@/schemas/container-schema";

import useDropDownEditList from "@/hooks/useDropDownEditList";
import CustomRichSelect from "@/components/rich-select-cell-editor";
import DatePicker from "@/components/date-picker";

import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";

dayjs.extend(utc);
dayjs.extend(timezone);

const TIMEZONE_AU = "Australia/Sydney"; // Khóa cứng múi giờ Úc (Sydney)

const dateFormat = "DD/MM/YYYY HH:mm:ss";
const dateFormatNormal = "DD/MM/YYYY";

interface Props extends CustomCellEditorProps {
	apiData?: any;
}

const COLUMN_STATE = "container-pop-up-column-state";

const modules = [AllCommunityModule];

const defaultColDef = {
	cellStyle: {
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
	},
};

const myTheme = themeQuartz.withParams({
	borderRadius: 8,
	browserColorScheme: "light",
	columnBorder: true,
	headerFontSize: 16,
	headerFontWeight: 900,
	spacing: 8,
	wrapperBorderRadius: 15,
});
function saveColumnsState(params: any) {
	const columnsSize = params.api.getColumnState();
	localStorage.setItem(COLUMN_STATE, JSON.stringify(columnsSize));
}

function onGridReady(params: any) {
	const columnsSize = localStorage.getItem(COLUMN_STATE);
	if (columnsSize) {
		params.api.applyColumnState({
			state: JSON.parse(columnsSize),
			applyOrder: true,
		});
	}
}

export default function ContainerEditPopUp(props: Props) {
	const getContainers = async () => {
		return await getContainerByShipment(props.data.shipment.id);
	};
	const { data, isPending, isError } = useQuery({
		queryKey: ["containerListWithJobNumber", props.data.shipment.id],
		queryFn: getContainers,
		retry: true,
	});

	// Lấy trực tiếp dữ liệu đang nằm trong Cache (Không API Call, Không Stale Check)
	const { data: dropDownEditList, isPending: dropDownPending } =
		useDropDownEditList();
	const [pinnedBottomRowData, setPinnedBottomRowData] = useState([]);
	const [isAddNewState, setIsAddNewState] = useState(false);
	const isAddNewRef = useRef(false);
	const queryClient = useQueryClient();
	// Hold grid API

	const gridRef = useRef<any>(null);
	const addNewRow = useCallback(() => {
		setIsAddNewState(true);
		isAddNewRef.current = true;
		const { api } = gridRef.current || {};

		if (!api) {
			return;
		}
		// Khởi tạo đúng shape của Object mà các cột đang binding (field: "container.number", ...)
		const newEmptyRow = {
			container: {
				number: "",
				type: null,
			},
			delivery: {
				delivery_actual: null,
				dehire: null,
			},
		};
		setPinnedBottomRowData([newEmptyRow]);
		api.setGridOption("pinnedBottomRowData", [{}]);

		setTimeout(() => {
			api.startEditingCell({
				rowIndex: 0,
				rowPinned: "bottom",
				colKey: "containers",
			});
		});
	}, []);

	function handleDelete(data: Container, colId: string) {
		console.log("data nhan duoc tu component con" + data);
		deleteContainer(ContainersSchema.parse(data), colId);
	}
	const onRowEditingStopped = useCallback(
		async (params: RowEditingStoppedEvent) => {
			const { data } = params;
			setPinnedBottomRowData([]);

			// Luôn giải phóng cờ dù có thêm mới thành công hay huỷ
			const wasAddNew = isAddNewRef.current;
			setIsAddNewState(false);
			isAddNewRef.current = false;

			const container = data?.container ?? null;
			if (!wasAddNew || !container.number) {
				return;
			}
			const newContainer: Container = {
				id: null,
				number: container.number ? container.number : null,
				type: container.type ? container.type : null,
				shipment_id: props.data.shipment.id,
			};

			await addNewContainer(
				newContainer,
				props.data.shipment.id,
				props.colDef.colId || "",
			);
			queryClient.invalidateQueries({
				queryKey: ["containerListWithJobNumber"],
			});


		},
		[data],
	);

	// Grid selection

	const rowSelection: any = useMemo(() => {
		return {
			mode: "singleRow",
			checkboxes: false,
			enableClickSelection: true,
		};
	}, []);

	// GetRowID to prevent AG grid re-render whole list
	const getRowId = useMemo(() => {
		return (params: GetRowIdParams) => {
			const data = params.data.container?.id
				? String(params.data.container?.id)
				: "new-row";
			// const data = String(params.data?.id);
			return data;
		};
	}, []);

	const handleKeyDown = useCallback(async (e: CellKeyDownEvent) => {
		// Kiểm tra phím Ctrl (hoặc Cmd trên Mac) + phím 'c' hoặc 'C'
		const keyDown = e.event as KeyboardEvent;
		if (
			(keyDown.ctrlKey || keyDown.metaKey) &&
			keyDown.key.toLowerCase() === "c"
		) {
			navigator.clipboard.writeText(e.value);
			// 2. Lấy thẻ ô AG Grid và add trực tiếp các utility class của Tailwind
			const target = keyDown.target as HTMLElement;
			const cellElement = target?.closest(".ag-cell") as HTMLElement;

			if (cellElement) {
				cellElement.classList.add("cell-copied-flash");

				setTimeout(() => {
					cellElement.classList.remove("cell-copied-flash");
				}, 400);
			}
		}

		if (
			(keyDown.ctrlKey || keyDown.metaKey) &&
			keyDown.key.toLowerCase() === "v"
		) {
			try {
				// 1. Đọc chuỗi văn bản bất đồng bộ từ Clipboard
				const textToPaste = await navigator.clipboard.readText();
				if (textToPaste !== undefined && textToPaste !== null) {
					// 2. Gán giá trị vào ô bằng e.column hoặc e.colDef.field
					if (typeof e.value === "number")
						return e.node?.setDataValue(e.column, Number(textToPaste.trim()));
					e.node?.setDataValue(e.column, textToPaste);
				}
			} catch (err) {
				console.error("Không thể đọc dữ liệu từ Clipboard:", err);
			}
		}
	}, []);

	//Defind column
	const colDefs = useMemo<ColDef[]>(() => {
		return [
			//Container number
			{
				field: "container.number",
				colId: "containers",
				headerName: "Container",
				context: {
					targetTable: "containers",
					targetColumn: "number",
				},
				flex: 2,
				editable: true,
				sortable: true,
				filter: true,
				floatingFilter: true,
				enableCellChangeFlash: true,
				cellRenderer: ContainerRender,
				cellEditor: "agTextCellEditor",
				cellRendererParams: {
					onDeleteRow: handleDelete,
				},
				onCellValueChanged: async (params: any) => {
					if (isAddNewRef.current) return;
					await updateContainerDetails(
						params.data.container,
						params.data.container.shipment_id,
						props.colDef.colId || "",
					);
					props.api.refreshCells({
						rowNodes: [props.node],
						columns: ["CONTAINERS"],
					});
				},
			},
			// Container type
			{
				field: "container.type",
				colId: "type",
				headerName: "Type",
				context: {
					targetTable: "containers",
					targetColumn: "type",
				},
				flex: 1,
				editable: true,
				sortable: true,
				filter: true,
				floatingFilter: true,
				enableCellChangeFlash: true,
				valueFormatter: (params: any) => {
					let types = dropDownEditList.container_types;
					if (!types) return "";
					const result = types.find((type: any) => type.id === params.value);
					return result?.name || "";
				},
				cellEditor: CustomRichSelect,

				cellEditorParams: (params: any) => {
					const type = dropDownEditList?.container_types || [];
					const values = type.map((t: any) => {
						return { value: t.id, label: t.name };
					});
					return {
						values: values,
						autoFocus: false,
					};
				},
				filterValueGetter: (params: any) => {
					let types = dropDownEditList.container_types;
					if (!types) return "";
					return (
						types.find((type: any) => type.id === params.data.type)?.name || ""
					);
				},
				onCellValueChanged: async (params: any) => {
					if (isAddNewRef.current) return;
					await updateContainerDetails(
						params.data.container,
						params.data.container.shipment_id,
						props.colDef.colId || "",
					);
					props.api.refreshCells({
						rowNodes: [props.node],
						columns: ["CONTAINER-TYPE"],
					});
				},
			},

			// Delivery plan
			{
				field: "delivery.delivery_actual",
				colId: "delivery_actual",
				headerName: "DEL",
				context: {
					targetTable: "containers",
					targetColumn: "type",
				},
				flex: 1,
				editable: (params) => params.node.rowPinned !== "bottom",
				sortable: true,
				filter: true,
				floatingFilter: true,
				enableCellChangeFlash: true,
				valueFormatter: (params: any) => {
					if (params.value) {
						return dayjs(params.value).tz(TIMEZONE_AU).format(dateFormatNormal);
					}
					return "";
				},
				cellEditor: DatePicker,
				onCellValueChanged: async (params: any) => {
					if (isAddNewRef.current) return;
					await updateContainerDelivery(
						params.data.delivery,
						params.data.container.shipment_id,
						params.colDef.colId || "",
					);
					params.api.refreshCells({
						rowNodes: [params.node],
						columns: ["delivery"],
					});
				},
			},

			// Dehire
			{
				field: "delivery.dehire",
				colId: "dehire",
				headerName: "Dehire",
				context: {
					targetTable: "containers",
					targetColumn: "type",
				},
				flex: 1,
				editable: (params) => params.node.rowPinned !== "bottom",
				sortable: true,
				filter: true,
				floatingFilter: true,
				enableCellChangeFlash: true,
				valueFormatter: (params: any) => {
					if (params.value) {
						return dayjs(params.value).tz(TIMEZONE_AU).format(dateFormatNormal);
					}
					return "";
				},
				cellEditor: DatePicker,
				onCellValueChanged: async (params: any) => {
					if (isAddNewRef.current) return;
					await updateContainerDelivery(
						params.data.delivery,
						params.data.container.shipment_id,
						params.colDef.colId || "",
					);
					params.api.refreshCells({
						rowNodes: [params.node],
						columns: ["dehire"],
					});
				},
			},
		];
	}, [dropDownEditList]);

	if (!dropDownEditList) {
		return <Skeleton className="h-[340px] w-[500px] rounded-lg" />;
	}

	return (
		<AgGridProvider modules={modules}>
			{/* Bọc ngoài cố định rộng 480px, chiều cao tự động theo content nhưng tối đa 70% viewport */}
			<div className="box-content w-fit min-w-130  max-w-[90vw] max-h-[70vh] bg-white rounded-lg shadow-xl overflow-hidden border border-gray-200">
				{/* Header cố định */}
				<div className="flex items-center justify-between border-b border-grid-border p-2 bg-white">
					<Button onClick={addNewRow}>Add Container</Button>
					<span className="text-base text-gray">
						{data?.length || 0} containers
					</span>
				</div>

				{/* CHÚ Ý CHỖ NÀY: Set height cố định (ví dụ 300px) trực tiếp cho div chứa Grid */}
				<div className="h-[300px] w-full">
					<AgGridReact
						theme={myTheme}
						rowData={data}
						columnDefs={colDefs}
						defaultColDef={defaultColDef}
						onColumnResized={saveColumnsState}
						onColumnMoved={saveColumnsState}
						onColumnPinned={saveColumnsState}
						onColumnVisible={saveColumnsState}
						onSortChanged={saveColumnsState}
						onGridReady={(params) => {
							onGridReady(params);
							gridRef.current = params;
						}}
						getRowId={getRowId}
						undoRedoCellEditing={true}
						rowSelection={rowSelection}
						loading={isPending}
						pinnedBottomRowData={pinnedBottomRowData}
						onRowEditingStopped={onRowEditingStopped}
						editType={isAddNewState ? "fullRow" : undefined}
						// enableCellTextSelection={true}
						onCellKeyDown={handleKeyDown}
					/>
				</div>
			</div>
		</AgGridProvider>
	);
}
