import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

interface ShipmentTabsProps {
	defaultValue?: string;
	value?: string;
	items?: { label: string; value: string }[];
	onValueChange?: (value: string) => void;
	className?: string;
}
export function ShipmentTabs({
	value,
	items,
	onValueChange,
	className,
}: ShipmentTabsProps) {
	return (
		<Tabs
			value={value}
			className={cn("w-auto", className)}
			onValueChange={(value: string) => {
				onValueChange?.(value);
			}}
		>
			<TabsList>
				{items?.map((i) => (
					<TabsTrigger key={i.value} value={i.value}>
						{i.label}
					</TabsTrigger>
				))}
			</TabsList>
		</Tabs>
	);
}
