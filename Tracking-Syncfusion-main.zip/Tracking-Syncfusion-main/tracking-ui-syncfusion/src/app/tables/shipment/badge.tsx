import React from "react";
import { tv, type VariantProps } from "tailwind-variants";

// 1. Cấu hình tailwind-variants: Bỏ text-[11px] và w-[85px] cứng
const badgeStyle = tv({
	// Dùng text-[length:var(--ag-font-size,12px)] để tự bắt font size của AG Grid
	// Dùng w-max min-w-[70px] thay vì w-[85px] để không bị vỡ chữ khi font size thay đổi
	base: "inline-flex items-center justify-left h-[1.6em] min-w-[66px] w-max px-1 text-[length:var(--ag-font-size,12px)] font-bold leading-none shadow-xs transition-all cursor-pointer select-none",
	variants: {
		variant: {
			fcl: "bg-blue-100 text-blue-800 border border-blue-300",
			lcl: "bg-amber-100 text-amber-800 border border-amber-300",
			food: "bg-emerald-100 text-emerald-800 border border-emerald-300",
			bulk: "bg-purple-100 text-purple-800 border border-purple-300",
			coil: "bg-fuchsia-100 text-fuchsia-800 border border-fuchsia-300",
			air: "bg-sky-100 text-sky-800 border border-sky-300",
			new: "relative p-[1px] overflow-hidden shadow-md border-0 min-w-[45px]",
			default: "bg-slate-200 text-slate-800 border border-slate-300",
		},
	},
	defaultVariants: {
		variant: "default",
	},
});

type BadgeProps = VariantProps<typeof badgeStyle>;

interface Props extends BadgeProps, React.HTMLAttributes<HTMLSpanElement> {
	text?: string;
	type?: string;
	children?: React.ReactNode;
}

// Giữ nguyên ICON_MAP với kích thước linh hoạt theo em (0.9em)
const ICON_MAP: Record<string, React.ReactNode> = {
	fcl: (
		<svg
			className="w-[0.9em] h-[0.9em] text-blue-700 shrink-0 me-1"
			fill="none"
			stroke="currentColor"
			strokeWidth="1.8"
			viewBox="0 0 24 24"
		>
			<path strokeLinecap="round" strokeLinejoin="round" d="M3 6h18v12H3z" />
			<path strokeLinecap="round" d="M7 6v12M11 6v12M15 6v12M19 6v12" />
			<circle cx="6" cy="20" r="1" />
			<circle cx="18" cy="20" r="1" />
		</svg>
	),
	lcl: (
		<svg
			className="w-[0.9em] h-[0.9em] text-amber-700 shrink-0 me-1"
			fill="none"
			stroke="currentColor"
			strokeWidth="1.8"
			viewBox="0 0 24 24"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				d="M4 7.5 12 3l8 4.5v9L12 21l-8-4.5v-9Z"
			/>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				d="M4 7.5 12 12l8-4.5M12 12v9"
			/>
		</svg>
	),
	food: (
		<svg
			className="w-[0.9em] h-[0.9em] text-emerald-700 shrink-0 me-1"
			fill="none"
			stroke="currentColor"
			strokeWidth="1.8"
			viewBox="0 0 24 24"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				d="M20 4C11 4 5 8 5 14c0 3 2 5 5 5 6 0 10-6 10-15Z"
			/>
			<path strokeLinecap="round" d="M4 21c3-5 7-8 12-11" />
		</svg>
	),
	bulk: (
		<svg
			className="w-[0.9em] h-[0.9em] text-purple-700 shrink-0 me-1"
			fill="none"
			stroke="currentColor"
			strokeWidth="1.8"
			viewBox="0 0 24 24"
		>
			<circle cx="12" cy="12" r="8.5" />
			<circle cx="12" cy="12" r="4" />
			<path strokeLinecap="round" d="M12 3.5v4M12 16.5v4M3.5 12h4M16.5 12h4" />
		</svg>
	),
	coil: (
		<svg
			className="w-[0.9em] h-[0.9em] text-fuchsia-700 shrink-0 me-1"
			fill="none"
			stroke="currentColor"
			strokeWidth="1.8"
			viewBox="0 0 24 24"
		>
			<circle cx="12" cy="12" r="8.5" />
			<circle cx="12" cy="12" r="4" />
			<circle cx="12" cy="12" r="1.2" fill="currentColor" />
		</svg>
	),
	air: (
		<svg
			className="w-[0.9em] h-[0.9em] text-sky-700 shrink-0 me-1"
			fill="none"
			stroke="currentColor"
			strokeWidth="1.8"
			viewBox="0 0 24 24"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				d="M3 12l7-2.5V5l2-2 2 2v4.5L21 12v2l-7-1v5l2 2v1h-3l-1-3-1 3H8v-1l2-2v-5l-7 1v-2Z"
			/>
		</svg>
	),
};

function MyCustomsBadge(
	{ text = "", type, variant, className, children, ...rest }: Props,
	ref: React.ForwardedRef<HTMLSpanElement>,
) {
	const rawText = text?.toLowerCase() || "";
	const keyType = rawText.split(" ")[0];
	const activeVariant = (variant ||
		keyType) as keyof typeof badgeStyle.variants.variant;

	const textPart = text?.toUpperCase() || "";
	const typePart = type?.toUpperCase() || "";
	const displayText = typePart ? `${textPart} (${typePart})` : textPart;

	if (activeVariant === "new") {
		return (
			<span
				{...rest}
				ref={ref}
				className={badgeStyle({ variant: "new", className })}
			>
				<span className="absolute inset-[-300%] aspect-square animate-[spin_2.5s_linear_infinite] bg-[conic-gradient(from_0deg_at_50%_50%,transparent_0%,#EF4444_6%,#F87171_12%,transparent_18%)] blur-[3px]"></span>
				<span className="animate-pulse relative inline-flex items-center justify-center w-full h-full px-1.5 py-0.5 rounded-full text-[0.85em] font-extrabold bg-red-200 text-red-800 leading-none">
					🔥 NEW
				</span>
			</span>
		);
	}

	return (
		<span
			{...rest}
			ref={ref}
			className={badgeStyle({ variant: activeVariant, className })}
		>
			{ICON_MAP[activeVariant] || null}
			<span>{displayText}</span>
			{children}
		</span>
	);
}

export default React.forwardRef(MyCustomsBadge);
