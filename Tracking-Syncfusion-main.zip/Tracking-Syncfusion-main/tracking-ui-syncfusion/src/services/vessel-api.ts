import axios from "axios";
import { VesselsSchema } from "../schemas/vesselSchema";
import { type Vessel } from "../schemas/vesselSchema";
const host = import.meta.env.VITE_HOST_URL;

export async function getAllVessel() {
	try {
		let url: string = `${host}/api/vessels/all`;
		let vessels: Vessel[] = [];
		const res = await axios.get(url, { withCredentials: true });
		if (res.status == 403) return [];
		vessels = VesselsSchema.parse(res.data);
		// console.log(vessels);
		return vessels;
	} catch (err) {
		console.log(err);
		throw err;
	}
}

export async function getVesselByName(name: string, pod: string) {
	try {
		let url: string = `${host}/api/vessels?name=${name}&pod=${pod}`;

		const res = await axios.get(url, { withCredentials: true });
		const vessels: Vessel[] = VesselsSchema.parse(res.data);
		return vessels;
	} catch (err) {
		console.log(err);
		return [];
	}
}

export async function changeVesselDetails(data: any) {
	try {
		let url: string = `${host}/api/vessels/${data.id}`;
		const res = await axios.patch(
			url,
			{ data: data },
			{ withCredentials: true },
		);
		if (res.status >= 200 && res.status < 300) {
			return true;
		} else {
			return false;
		}
	} catch (error) {
		console.log(error);
		return false;
	}
}
