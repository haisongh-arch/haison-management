import axios from "axios";
import { type Container } from "../schemas/container-schema";
import {
	ContainerDeliverySchemaArray,
	type ContainerDelivery,
	type Delivery,
	DeliveriesPlanSchema,
	type DeliveryPlan,
} from "../schemas/container-delivery-schema";
const host = import.meta.env.VITE_HOST_URL;

export async function getContainerByShipment(shipmentID: number) {
	let url = host + `/api/containers/${shipmentID}`;
	const res = await axios.get(url, { withCredentials: true });
	if (res.status == 403) return []; //Unauthorize
	let containerDelivery: ContainerDelivery[];
	try {
		containerDelivery = ContainerDeliverySchemaArray.parse(res.data);
		return containerDelivery;
	} catch (error) {
		console.log(error);
	}
}

export async function deleteContainer(container: Container, colId: string) {
	try {
		let url = host + `/api/containers/${container.id}`;
		const res = await axios.delete(url, {
			data: {
				container: container,
				shipmentId: container.shipment_id,
				colId: colId,
			},
			withCredentials: true,
		});
		if (res.status == 403) return []; //Unauthorize
		return res.data;
	} catch (error) {
		console.log(error);
	}
}

export async function updateContainerDetails(
	container: Container,
	shipmentID: number,
	colId: string,
) {
	try {
		let url = host + `/api/containers/${container.id}`;
		const res = await axios.patch(
			url,
			{ container: container, shipmentID: shipmentID, colId: colId },
			{ withCredentials: true },
		);
		if (res.status == 403) return []; //Unauthorize
		return res.data;
	} catch (error) {
		console.log(error);
	}
}

export async function updateContainerDelivery(
	data: Delivery,
	shipmentID: number,
	colId: string,
) {
	try {
		let url = host + `/api/containers/delivery/${data.container_id}`;
		const res = await axios.patch(
			url,
			{ delivery: data, shipmentID: shipmentID, colId: colId },
			{ withCredentials: true },
		);
		if (res.status == 403) return []; //Unauthorize
		return res.data;
	} catch (error) {
		console.log(error);
	}
}

export async function addNewContainer(
	container: Container,
	shipmentID: number,
	colId: string,
) {
	try {
		let url = host + `/api/containers`;
		const res = await axios.post(
			url,
			{ container: container, shipmentID: shipmentID, colId: colId },
			{ withCredentials: true },
		);
		if (res.status == 403) return []; //Unauthorize
		return res.data;
	} catch (error) {
		console.log(error);
	}
}

export async function getDeliveryScheduleForNormalShipments() {
	try {
		let url = host + `/api/deliveries`;
		const res = await axios.get(url, { withCredentials: true });
		const deliveriesPlan: DeliveryPlan[] = DeliveriesPlanSchema.parse(res.data);
		return deliveriesPlan;
	} catch (error) {
		console.log(error);
		return [];
	}
}
