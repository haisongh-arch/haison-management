import { useState, useEffect } from "react";
import {
	Popover,
	PopoverTrigger,
	PopoverContent,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { preconnect } from "react-dom";
interface CsvExportProps {
	gridApi?: any;
	columnsSavingName: string;
}

export default function CsvExport({
	gridApi,
	columnsSavingName,
}: CsvExportProps) {
	const [columns, setColumns] = useState<String[]>([]);
	const colDefs = gridApi?.getColumns() || [];

	const SAVING_NAME = columnsSavingName;
	const exportColumns = localStorage.getItem(SAVING_NAME);

	const handleCheck = (colId: String) => {
		setColumns((pre) =>
			pre.includes(colId)
				? pre.filter((value) => value !== colId)
				: [...pre, colId],
		);
		localStorage.setItem(SAVING_NAME, JSON.stringify(columns));
	};

	const handleExport = () => {
		const columnsExport: String[] = [];
		colDefs?.forEach((col: any) => {
			if (columns.includes(col.getColId())) columnsExport.push(col.getColId());
		});
		gridApi?.exportDataAsCsv({
			skipColumnGroupHeaders: true,
			columnKeys: columnsExport,
		});
	};
	useEffect(() => {
		if (exportColumns) setColumns(JSON.parse(exportColumns));
		else {
			setColumns(colDefs?.map((col: any) => col.getColId()));
		}
	}, [colDefs]);

	return (
		<Popover>
			<PopoverTrigger render={<Button></Button>}>Export</PopoverTrigger>
			<PopoverContent>
				<div className="max-h-60 overflow-y-auto flex flex-col gap-2">
					{colDefs?.map((col: any) => {
						const colId = col.getColId();
						const label = col.getColDef().headerName || colId;
						const isChecked = columns.includes(colId);
						return (
							<label
								key={colId}
								className="flex items-center gap-2 text-xs cursor-pointer select-none"
							>
								<Checkbox
									checked={isChecked}
									onCheckedChange={(checked) => {
										handleCheck(colId);
									}}
								/>
								<span className="truncate">{label}</span>
							</label>
						);
					})}
				</div>
				<Button onClick={handleExport}>Export</Button>
			</PopoverContent>
		</Popover>
	);
}
