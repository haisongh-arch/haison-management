import React from "react";
import type { CustomCellRendererProps } from "ag-grid-react";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props extends CustomCellRendererProps {
	onDeleteRow?: (data: any, colId: string) => void;
}

export default function ContainerRender(props: Props) {
	const handleDelete = (e: React.MouseEvent) => {
		e.stopPropagation();
		if (props.onDeleteRow) {
			props.onDeleteRow(props.data?.container, props.colDef?.colId || "");
		}
	};

	return (
		<div className="flex items-center justify-between w-full">
			<span>{props.data?.container?.number}</span>
			<Button
				type="button"
				variant="ghost"
				size="icon-xs"
				title="Delete"
				onClick={handleDelete}
			>
				<Trash2 className="size-4" />
			</Button>
		</div>
	);
}
