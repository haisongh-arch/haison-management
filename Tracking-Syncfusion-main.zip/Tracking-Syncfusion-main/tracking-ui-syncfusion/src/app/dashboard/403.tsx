import { useNavigate } from "react-router";
import { ShieldAlert, ArrowLeft, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
	Card,
	CardContent,
	CardDescription,
	CardFooter,
	CardHeader,
	CardTitle,
} from "@/components/ui/card";

export default function ForbiddenPage() {
	const navigate = useNavigate();

	return (
		<div className="flex min-h-screen w-full items-center justify-center bg-muted/40 p-4">
			<Card className="w-full max-w-md text-center shadow-lg border-destructive/20">
				<CardHeader className="flex flex-col items-center gap-2 pt-8">
					{/* Icon Cảnh báo Bảo mật */}
					<div className="flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10 text-destructive">
						<ShieldAlert className="h-8 w-8" />
					</div>

					{/* Mã lỗi */}
					<span className="text-xs font-semibold tracking-widest text-muted-foreground uppercase">
						Error 403
					</span>

					<CardTitle className="text-2xl font-bold tracking-tight">
						Error
					</CardTitle>

					<CardDescription className="text-balance text-muted-foreground">
						You have no permission to access, please contact admin!
					</CardDescription>
				</CardHeader>

				<CardContent className="pb-4">
					<div className="rounded-lg bg-muted p-3 text-xs text-muted-foreground font-mono">
						Access-Denied: Insufficient Permissions
					</div>
				</CardContent>

				<CardFooter className="flex flex-col sm:flex-row gap-2 justify-center pt-2">
					{/* Nút Quay lại trang trước */}
					<Button
						variant="outline"
						className="w-full sm:w-auto gap-2"
						onClick={() => navigate(-1)}
					>
						<ArrowLeft className="h-4 w-4" />
						Back
					</Button>

					{/* Nút Về trang chủ */}
					<Button
						className="w-full sm:w-auto gap-2"
						onClick={() => {
							navigate("/");
						}}
					>
						<Home className="h-4 w-4" />
						Home
					</Button>
				</CardFooter>
			</Card>
		</div>
	);
}
