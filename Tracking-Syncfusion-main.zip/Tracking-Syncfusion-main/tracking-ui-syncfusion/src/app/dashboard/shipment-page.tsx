import { AppSidebar } from "@/components/app-sidebar";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/site-header";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuGroup,
	DropdownMenuItem,
	DropdownMenuLabel,
	DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import { SearchInput } from "@/components/search-input";
import { ShipmentTabs } from "@/app/tables/shipment/shipment-tabs-navigation";
import { DeliveryPanel } from "@/components/delivery-plan-panel";
import ShipmentTable from "@/app/tables/shipment/shipment-table";

import socket from "@/services/socket";
import { SOCKET_EVENTS } from "@/utils/socket-constants";
import React, { useEffect, useState, useRef, useMemo } from "react";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import {
	getAllShipment,
	addNewShipmentWithIdAndTeam,
	addNewClient,
} from "@/services/shipment-api";
import type { GridApi } from "ag-grid-community";

import {
	type ShipmentRefreshSignal,
	ShipmentRefreshSignalSchemaArray,
} from "@/schemas/shipment-schema";
import { type Client } from "@/schemas//client-schema";

import AddShipmentModal from "@/app/tables/shipment/add-shipment-modal";
import AddClientModal from "@/app/tables/shipment/add-client-modal";
import CsvExport from "@/components/csv-export";
import { Truck } from "lucide-react";
import useDropDownEditList from "@/hooks/useDropDownEditList";
import { Loader2 } from "lucide-react";
import HaiSonLogo from "@/assets/haison-logo.png";

const getShipment = async () => {
	return getAllShipment();
};

export default function ShipmentPage() {
	const queryClient = useQueryClient();
	const [gridApi, setGridApi] = useState<GridApi | null>(null);
	const refreshQueue = useRef<ShipmentRefreshSignal[]>([]);
	const [refreshVersion, setRefreshVersion] = useState(0);

	const refetchShipmentTimerRef = useRef<number | null>(null);
	const refetchDropdownTimerRef = useRef<number | null>(null);

	const {
		data,
		isLoading,
		isError: isShipmentError,
	} = useQuery({
		queryKey: ["allShipments"],
		queryFn: getShipment,
		retry: true,
	});

	const {
		data: dropDownEditList,
		isLoading: isDropDownEditListLoading,
		isError: isDropDownError,
	} = useDropDownEditList();

	//#region States for Modal
	const [isOpenAddShipmentModal, setIsOpenAddShipmentModal] = useState(false);
	const [isOpenAddClientModal, setIsOpenAddClientModal] = useState(false);

	const handleAddShipmentSubmit = (values: {
		shipmentId: string;
		teamId: number;
	}) => {
		// console.log("Form Values:", values);
		addNewShipmentWithIdAndTeam(values.shipmentId, values.teamId);
		setIsOpenAddShipmentModal(false);
	};
	const handleAddClientSubmit = (client: Client) => {
		console.log("Form Values:", client);
		addNewClient(client);
		setIsOpenAddShipmentModal(false);
	};
	//#endregion
	console.log("page rerender ");

	// Socket manager
	useEffect(() => {
		const ensureSocketConnected = () => {
			if (!socket.connected) {
				socket.connect();
			}
			socket.emit(SOCKET_EVENTS.SHIPMENTS.JOIN_ROOM);
			socket.emit(SOCKET_EVENTS.DROPDOWN.JOIN_ROOM);
		};

		// 2. Lắng nghe sự kiện ẩn/hiện Tab
		const handleVisibilityChange = () => {
			if (!document.hidden) {
				console.log("Tab active trở lại - Kiểm tra Socket & Đồng bộ Data");
				ensureSocketConnected();

				// Refetch lại toàn bộ Data để bù lại các event có thể đã bị lỡ khi tab đóng băng
				queryClient.invalidateQueries({ queryKey: ["allShipments"] });
				queryClient.invalidateQueries({
					queryKey: ["containerListWithJobNumber"],
				});
				queryClient.invalidateQueries({ queryKey: ["dropDownEditList"] });
			}
		};

		ensureSocketConnected();

		console.log("attached socket");
		socket.emit(SOCKET_EVENTS.SHIPMENTS.JOIN_ROOM); // Send event to server
		socket.emit(SOCKET_EVENTS.DROPDOWN.JOIN_ROOM); // Send event to server
		socket.on(SOCKET_EVENTS.SHIPMENTS.USER_JOINED, (message) => {
			// Listening "Entry shipment"
			console.log(message.message);
		});
		socket.on(SOCKET_EVENTS.DROPDOWN.USER_JOINED, (message) => {
			// Listening "Entry shipment"
			console.log(message.message);
		});

		socket.on(SOCKET_EVENTS.SHIPMENTS.EDITED, async (message) => {
			try {
				const signals: ShipmentRefreshSignal[] =
					ShipmentRefreshSignalSchemaArray.parse(message.signals);
				refreshQueue.current.push(...signals);
				// 2. Gom việc Refetch API lại, nếu timer đang đếm, refresh lại (Debounce 300ms)
				if (refetchShipmentTimerRef.current) {
					console.log("Reset timer");
					clearTimeout(refetchShipmentTimerRef.current);
				}
				refetchShipmentTimerRef.current = setTimeout(async () => {
					// Refetch API để lấy DỮ LIỆU MỚI THỰC SỰ từ DB về
					await Promise.all([
						queryClient.invalidateQueries({ queryKey: ["allShipments"] }),
						// queryClient.invalidateQueries({ queryKey: ["dropDownEditList"] }),
						queryClient.invalidateQueries({
							queryKey: ["containerListWithJobNumber"],
						}),
					]);

					// 3. Sau khi data mới đã về Cache, kích hoạt trigger để Table lấy Queue ra flash cell
					setRefreshVersion((v) => v + 1);
					console.log("Render lai" + refreshVersion);
				}, 300);
			} catch (error) {
				console.log(error);
			}
		});

		socket.on(SOCKET_EVENTS.DROPDOWN.EDITED, async (message) => {
			try {
				console.log(message);
				// 2. Gom việc Refetch API lại, nếu timer đang đếm, refresh lại (Debounce 300ms)
				if (refetchDropdownTimerRef.current) {
					console.log("Reset timer dropdown");
					clearTimeout(refetchDropdownTimerRef.current);
				}
				refetchDropdownTimerRef.current = setTimeout(async () => {
					// Refetch API để lấy DỮ LIỆU MỚI THỰC SỰ từ DB về
					await Promise.all([
						queryClient.invalidateQueries({ queryKey: ["dropDownEditList"] }),
					]);
				}, 300);
			} catch (error) {
				console.log(error);
			}
		});

		// 4. Lắng nghe sự kiện Visibility của trình duyệt
		document.addEventListener("visibilitychange", handleVisibilityChange);

		return () => {
			console.log("Remove socket");
			if (refetchShipmentTimerRef.current) {
				clearTimeout(refetchShipmentTimerRef.current);
			}
			if (refetchDropdownTimerRef.current) {
				clearTimeout(refetchDropdownTimerRef.current);
			}

			socket.emit(SOCKET_EVENTS.SHIPMENTS.LEAVE_ROOM);
			socket.off(SOCKET_EVENTS.SHIPMENTS.USER_JOINED);
			socket.off(SOCKET_EVENTS.SHIPMENTS.EDITED);

			socket.emit(SOCKET_EVENTS.DROPDOWN.LEAVE_ROOM);
			socket.off(SOCKET_EVENTS.DROPDOWN.USER_JOINED);
			socket.off(SOCKET_EVENTS.DROPDOWN.EDITED);
		};
	}, [queryClient]);

	//#region State for Toolbar
	const [currentNav, setCurrentNav] = useState("Handle");

	const NavItems = useMemo(() => {
		if (!Array.isArray(data)) {
			return [
				{
					label: `Handle`,
					value: "Handle",
				},
				{
					label: `Delivering`,
					value: "Delivering",
				},
				{
					label: `Invoice`,
					value: "Invoice",
				},
				{
					label: `All`,
					value: "All",
				},
			];
		}

		const shipmentCount = data.reduce(
			(acc, shipment) => {
				const statusId = shipment.status?.id ?? 0;

				if (statusId < 20) {
					acc.handleShipment++;
				} else if (statusId >= 20 && statusId < 50) {
					acc.deliveringShipment++;
				} else if (statusId >= 50 && statusId < 60) acc.invoiceShipment++;
				acc.allShipments++;
				return acc;
			},
			{
				handleShipment: 0,
				deliveringShipment: 0,
				invoiceShipment: 0,
				allShipments: 0,
			},
		);
		return [
			{
				label: `Handle(${shipmentCount.handleShipment})`,
				value: "Handle",
			},
			{
				label: `Delivering(${shipmentCount.deliveringShipment})`,
				value: "Delivering",
			},
			{
				label: `Invoice(${shipmentCount.invoiceShipment})`,
				value: "Invoice",
			},
			{
				label: `All(${shipmentCount.allShipments})`,
				value: "All",
			},
		];
	}, [data]);

	const handleShipmentNav = (value: string) => {
		let model: string[] = [];
		const status = dropDownEditList?.statusRefMap;
		if (value === "Handle") {
			for (const [key, value] of Object.entries(status)) {
				if (Number(key) < 20) model.push(String(value));
			}
			setCurrentNav("Handle");
		}

		if (value === "Delivering") {
			for (const [key, value] of Object.entries(status)) {
				if (Number(key) >= 20 && Number(key) < 50) model.push(String(value));
			}
			setCurrentNav("Delivering");
		}

		if (value === "Invoice") {
			for (const [key, value] of Object.entries(status)) {
				if (Number(key) == 50) model.push(String(value));
			}
			setCurrentNav("Invoice");
		}

		if (value === "All") {
			gridApi?.setColumnFilterModel("status.id", null);
			gridApi?.onFilterChanged();
			setCurrentNav("All");
			return;
		}
		gridApi?.setColumnFilterModel("status.id", {
			values: model,
		});
		gridApi?.onFilterChanged();
	};
	// Thêm 1 ref để đảm bảo chỉ auto-apply filter ở lần đầu tiên load trang
	const isInitialFilterApplied = useRef(false);
	useEffect(() => {
		// Chỉ kích hoạt khi cả gridApi và dropDownEditList đều đã load xong
		if (
			gridApi &&
			dropDownEditList?.statusRefMap &&
			!isInitialFilterApplied.current
		) {
			handleShipmentNav("Handle");
			isInitialFilterApplied.current = true;
		}
	}, [gridApi, dropDownEditList]);

	//#region State for Delivery sidebar

	const [isDeliverySideBarOpen, setisDeliverySideBarOpen] = useState(false);

	//#endregion
	//#endregion

	if (isLoading || isDropDownEditListLoading) {
		return (
			<div className="w-screen min-h-screen flex items-center justify-center bg-background">
				<div className="flex flex-col items-center gap-4">
					<img alt="Hai Son logo" src={HaiSonLogo} className="h-12 w-auto" />
					<Button disabled>
						<Loader2 className="mr-2 size-4 animate-spin" />
						Loading...
					</Button>
				</div>
			</div>
		);
	}
	// Handling Error Case
	if (isShipmentError || isDropDownError) {
		return (
			<div className="flex h-screen w-full flex-col items-center justify-center gap-4 bg-background p-4">
				<p className="text-sm font-medium text-destructive">Error</p>
				<Button
					variant="outline"
					onClick={() => queryClient.invalidateQueries()}
				>
					Retry
				</Button>
			</div>
		);
	}
	return (
		<SidebarProvider
			style={
				{
					"--sidebar-width": "calc(var(--spacing) * 72)",
					"--header-height": "calc(var(--spacing) * 12)",
				} as React.CSSProperties
			}
			className="h-screen w-full overflow-hidden"
		>
			<AppSidebar variant="inset" />
			<SidebarInset>
				<SiteHeader>
					<SiteHeader.Left>
						{/* Create button */}
						<DropdownMenu>
							<DropdownMenuTrigger render={<Button />}>
								Create
							</DropdownMenuTrigger>
							<DropdownMenuContent side="left">
								<DropdownMenuGroup>
									<DropdownMenuLabel>Create new</DropdownMenuLabel>
									<DropdownMenuItem
										onClick={(e: React.MouseEvent) => {
											setIsOpenAddShipmentModal(true);
										}}
									>
										Shipment
									</DropdownMenuItem>
									<DropdownMenuItem
										onClick={(e: React.MouseEvent) => {
											setIsOpenAddClientModal(true);
										}}
									>
										Client
									</DropdownMenuItem>
								</DropdownMenuGroup>
								{/* <DropdownMenuSeparator /> */}
							</DropdownMenuContent>
						</DropdownMenu>

						{/*Export button */}
						<CsvExport
							gridApi={gridApi}
							columnsSavingName="SHIPMENT-TABLE-EXPORT"
						></CsvExport>
					</SiteHeader.Left>
					<SiteHeader.Right>
						<ShipmentTabs
							className="hidden sm:inline-flex"
							items={NavItems}
							onValueChange={handleShipmentNav}
							value={currentNav}
						></ShipmentTabs>
						<SearchInput
							onChange={(value: string) => {
								gridApi?.setFilterModel(null);
								if (value == "") {
									setCurrentNav("Handle");
									handleShipmentNav("Handle");
								}
								gridApi?.setGridOption("quickFilterText", value);
							}}
							className="w-24 sm:w-48 "
						></SearchInput>
						<Button
							onClick={() => {
								queryClient.invalidateQueries({
									queryKey: ["deliveries-plan"],
								});
								setisDeliverySideBarOpen((previous: boolean) => !previous);
							}}
						>
							<Truck className="h-4 w-4" />
						</Button>
					</SiteHeader.Right>
				</SiteHeader>

				{/*Modals*/}
				<div className="flex flex-1 flex-col">
					<div className="@container/main flex flex-1 flex-col gap-2">
						<div className="flex flex-1 flex-col gap-4 py-4 md:gap-6 md:py-6 min-h-0">
							<div className="flex-1 min-h-0">
								<ShipmentTable
									data={data}
									refreshQueue={refreshQueue}
									refreshVersion={refreshVersion}
									setGridApi={setGridApi}
								/>
							</div>
							{/* UI Component Modal */}
							<AddShipmentModal
								open={isOpenAddShipmentModal}
								onClose={() => setIsOpenAddShipmentModal(false)}
								onSubmit={handleAddShipmentSubmit}
								teamOptions={dropDownEditList?.teams}
							/>

							<AddClientModal
								open={isOpenAddClientModal}
								onClose={() => setIsOpenAddClientModal(false)}
								onSubmit={handleAddClientSubmit}
							/>
						</div>
					</div>
				</div>
			</SidebarInset>
			<DeliveryPanel
				open={isDeliverySideBarOpen}
				onClose={() => {
					queryClient.invalidateQueries({ queryKey: ["deliveries-plan"] });
					setisDeliverySideBarOpen(false);
				}}
			/>
		</SidebarProvider>
	);
}
