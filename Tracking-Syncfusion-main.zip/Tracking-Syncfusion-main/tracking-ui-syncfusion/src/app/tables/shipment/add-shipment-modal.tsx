import { useState, useEffect } from "react";
import type { Team } from "@/schemas/user-schema";
import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle,
	DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@/components/ui/select";

interface AddShipmentModalProps {
	open: boolean;
	onClose: () => void;
	onSubmit: (values: { shipmentId: string; teamId: number }) => void;
	loading?: boolean;
	teamOptions?: Team[];
}

export default function AddShipmentModal({
	open,
	onClose,
	onSubmit,
	loading = false,
	teamOptions,
}: AddShipmentModalProps) {
	const [shipmentId, setShipmentId] = useState("");
	const [teamId, setTeamId] = useState<string>("");
	const [errors, setErrors] = useState<{
		shipmentId?: string;
		teamId?: string;
	}>({});

	useEffect(() => {
		if (!open) {
			setShipmentId("");
			setTeamId("");
			setErrors({});
		}
	}, [open]);

	const handleSubmit = (e: React.SubmitEvent) => {
		e.preventDefault();

		const newErrors: { shipmentId?: string; teamId?: string } = {};

		if (!shipmentId.trim()) {
			newErrors.shipmentId = "Please enter Shipment ID";
		}
		if (!teamId) {
			newErrors.teamId = "Please select team";
		}

		if (Object.keys(newErrors).length > 0) {
			setErrors(newErrors);
			return;
		}

		onSubmit({
			shipmentId: shipmentId.trim(),
			teamId: Number(teamId),
		});

		setShipmentId("");
		setTeamId("");
		setErrors({});
	};

	const handleCancel = () => {
		setShipmentId("");
		setTeamId("");
		setErrors({});
		onClose();
	};

	return (
		<Dialog open={open} onOpenChange={(isOpen) => !isOpen && handleCancel()}>
			<DialogContent className="sm:max-w-[400px]">
				<DialogHeader>
					<DialogTitle>Add New Shipment</DialogTitle>
				</DialogHeader>

				<form onSubmit={handleSubmit} className="space-y-4 py-2">
					{/* 1. Textbox nhập Shipment ID */}
					<div className="space-y-2">
						<Label htmlFor="shipmentId">
							Shipment ID <span className="text-destructive">*</span>
						</Label>
						<Input
							id="shipmentId"
							placeholder="e.g. 10293"
							value={shipmentId}
							onChange={(e) => {
								setShipmentId(e.target.value);
								if (errors.shipmentId) {
									setErrors((prev) => ({ ...prev, shipmentId: undefined }));
								}
							}}
						/>
						{errors.shipmentId && (
							<p className="text-xs text-destructive">{errors.shipmentId}</p>
						)}
					</div>

					{/* 2. Selector chọn Team */}
					<div className="space-y-2">
						<Label htmlFor="teamId">
							Team <span className="text-destructive">*</span>
						</Label>
						<Select
							value={teamId}
							onValueChange={(val) => {
								setTeamId(val ?? "");
								if (errors.teamId) {
									setErrors((prev) => ({ ...prev, teamId: undefined }));
								}
							}}
							items={teamOptions?.map((t) => ({
								value: String(t.id),
								label: t.name,
							}))}
						>
							<SelectTrigger id="teamId" className="w-full">
								<SelectValue placeholder="Select Team" />
							</SelectTrigger>
							<SelectContent>
								{teamOptions?.map((t) => (
									<SelectItem key={t.id} value={String(t.id)}>
										{t.name}
									</SelectItem>
								))}
							</SelectContent>
						</Select>
						{errors.teamId && (
							<p className="text-xs text-destructive">{errors.teamId}</p>
						)}
					</div>

					<DialogFooter className="pt-4">
						<Button
							type="button"
							variant="outline"
							onClick={handleCancel}
							disabled={loading}
						>
							Cancel
						</Button>
						<Button type="submit" disabled={loading}>
							{loading ? "Adding..." : "Add"}
						</Button>
					</DialogFooter>
				</form>
			</DialogContent>
		</Dialog>
	);
}
