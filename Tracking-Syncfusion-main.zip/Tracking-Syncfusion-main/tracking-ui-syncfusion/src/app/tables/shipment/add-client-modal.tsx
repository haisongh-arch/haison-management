import { useState, useEffect } from "react";
import { type Client } from "@/schemas/client-schema";
import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle,
	DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface AddClientModalProps {
	open: boolean;
	onClose: () => void;
	onSubmit: (values: Client) => void;
	loading?: boolean;
}

const initialFormState = {
	short_name: "",
	edi_code: "",
	full_name: "",
	phone: "",
	mail1: "",
	mail2: "",
	mail3: "",
	mail4: "",
	mail5: "",
	mail6: "",
};

export default function AddClientModal({
	open,
	onClose,
	onSubmit,
	loading = false,
}: AddClientModalProps) {
	const [formData, setFormData] = useState(initialFormState);
	const [errors, setErrors] = useState<Record<string, string>>({});

	useEffect(() => {
		if (!open) {
			setFormData(initialFormState);
			setErrors({});
		}
	}, [open]);

	const handleChange = (field: string, value: string) => {
		setFormData((prev) => ({ ...prev, [field]: value }));
		if (errors[field]) {
			setErrors((prev) => ({ ...prev, [field]: "" }));
		}
	};

	const handleSubmit = (e: React.FormEvent) => {
		e.preventDefault();

		if (!formData.short_name.trim()) {
			setErrors({ short_name: "Please enter short name" });
			return;
		}

		// Xử lý chuỗi rỗng "" thành null cho khớp với zNullableString
		const cleanedValues = Object.fromEntries(
			Object.entries(formData).map(([key, val]) => [
				key,
				val === undefined || (typeof val === "string" && val.trim() === "")
					? null
					: val,
			]),
		);

		onSubmit({
			id: null,
			edi_code: null,
			short_name: null,
			full_name: null,
			mail1: null,
			mail2: null,
			mail3: null,
			mail4: null,
			mail5: null,
			mail6: null,
			phone: null,
			...cleanedValues,
		} as Client);

		setFormData(initialFormState);
		setErrors({});
	};

	const handleCancel = () => {
		setFormData(initialFormState);
		setErrors({});
		onClose();
	};

	return (
		<Dialog open={open} onOpenChange={(isOpen) => !isOpen && handleCancel()}>
			<DialogContent className="sm:max-w-[600px]">
				<DialogHeader>
					<DialogTitle>Add New Client</DialogTitle>
				</DialogHeader>

				<form onSubmit={handleSubmit} className="space-y-4 py-2">
					{/* Information */}
					<div className="grid grid-cols-2 gap-4">
						<div className="space-y-2">
							<Label htmlFor="short_name">
								Short Name <span className="text-destructive">*</span>
							</Label>
							<Input
								id="short_name"
								placeholder="e.g. ABC Corp"
								value={formData.short_name}
								onChange={(e) => handleChange("short_name", e.target.value)}
							/>
							{errors.short_name && (
								<p className="text-xs text-destructive">{errors.short_name}</p>
							)}
						</div>

						<div className="space-y-2">
							<Label htmlFor="edi_code">EDI Code</Label>
							<Input
								id="edi_code"
								placeholder="e.g. EDI123"
								value={formData.edi_code}
								onChange={(e) => handleChange("edi_code", e.target.value)}
							/>
						</div>
					</div>

					<div className="space-y-2">
						<Label htmlFor="full_name">Full Name</Label>
						<Input
							id="full_name"
							placeholder="e.g. ABC Trading Company"
							value={formData.full_name}
							onChange={(e) => handleChange("full_name", e.target.value)}
						/>
					</div>

					<div className="space-y-2">
						<Label htmlFor="phone">Phone Number</Label>
						<Input
							id="phone"
							placeholder="e.g. 0901234567"
							value={formData.phone}
							onChange={(e) => handleChange("phone", e.target.value)}
						/>
					</div>

					{/* Emails */}
					<div className="border-t pt-3 mt-2">
						<p className="font-medium text-sm text-muted-foreground mb-3">
							Email Contacts
						</p>
						<div className="grid grid-cols-2 gap-4">
							<div className="space-y-2">
								<Label htmlFor="mail1">Email 1</Label>
								<Input
									id="mail1"
									type="email"
									placeholder="primary@client.com"
									value={formData.mail1}
									onChange={(e) => handleChange("mail1", e.target.value)}
								/>
							</div>

							<div className="space-y-2">
								<Label htmlFor="mail2">Email 2</Label>
								<Input
									id="mail2"
									type="email"
									value={formData.mail2}
									onChange={(e) => handleChange("mail2", e.target.value)}
								/>
							</div>

							<div className="space-y-2">
								<Label htmlFor="mail3">Email 3</Label>
								<Input
									id="mail3"
									type="email"
									value={formData.mail3}
									onChange={(e) => handleChange("mail3", e.target.value)}
								/>
							</div>

							<div className="space-y-2">
								<Label htmlFor="mail4">Email 4</Label>
								<Input
									id="mail4"
									type="email"
									value={formData.mail4}
									onChange={(e) => handleChange("mail4", e.target.value)}
								/>
							</div>

							<div className="space-y-2">
								<Label htmlFor="mail5">Email 5</Label>
								<Input
									id="mail5"
									type="email"
									value={formData.mail5}
									onChange={(e) => handleChange("mail5", e.target.value)}
								/>
							</div>

							<div className="space-y-2">
								<Label htmlFor="mail6">Email 6</Label>
								<Input
									id="mail6"
									type="email"
									value={formData.mail6}
									onChange={(e) => handleChange("mail6", e.target.value)}
								/>
							</div>
						</div>
					</div>

					<DialogFooter className="pt-4">
						<Button
							type="button"
							variant="outline"
							onClick={handleCancel}
							disabled={loading}
						>
							Cancel
						</Button>
						<Button type="submit" disabled={loading}>
							{loading ? "Adding..." : "Add"}
						</Button>
					</DialogFooter>
				</form>
			</DialogContent>
		</Dialog>
	);
}
