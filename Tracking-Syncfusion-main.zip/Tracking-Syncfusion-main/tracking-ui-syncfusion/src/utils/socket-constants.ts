export const SOCKET_ROOMS = {
	VESSELS: "vessels",
	SHIPMENTS: "shipments",
	DROPDOWN: "dropdown",
} as const;

export const SOCKET_EVENTS = {
	CORE: {
		CONNECTION: "connection",
		DISCONNECTING: "disconnecting",
	},
	VESSELS: {
		JOIN_ROOM: "vessels:join_room",
		LEAVE_ROOM: "vessels:leave_room",
		JOIN_LOBBY: "vessels:lobby",
		EDITED: "vessels:edit_vessel",
	},
	SHIPMENTS: {
		JOIN_ROOM: "shipments:join_room",
		LEAVE_ROOM: "shipments:leave_room",
		EDITED: "shipments:edit_shipments",
		USER_JOINED: "shipments:user_joined",
	},
	DROPDOWN: {
		JOIN_ROOM: "dropdown:join_room",
		LEAVE_ROOM: "dropdown:leave_room",
		EDITED: "dropdown:edit_shipments",
		USER_JOINED: "dropdown:user_joined",
	},
} as const;

// 1. Export kiểu dữ liệu (Types) cho các file TS khác dùng
export type SocketRooms = typeof SOCKET_ROOMS;
export type SocketEvents = typeof SOCKET_EVENTS;
export type SocketRoomValue = (typeof SOCKET_ROOMS)[keyof typeof SOCKET_ROOMS];

// 2. Dòng BẮT BUỘC để các file JS CŨ dùng require() không bị lỗi!
// module.exports = { SOCKET_ROOMS, SOCKET_EVENTS };
