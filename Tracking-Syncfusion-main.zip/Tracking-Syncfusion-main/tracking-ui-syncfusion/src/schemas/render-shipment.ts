import { z } from "zod";
import {
	ShipmentSchema,
	ShipmentStatusSchema,
	ShipmentTypesSchema,
	ShipmentPaymentsSchema,
	ShipmentInfoSchema,
	ShipmentNotesSchemaArray,
} from "./shipment-schema";
import { VesselSchema } from "./vesselSchema";
import { ClientsSchema } from "./client-schema";
import { ContainerSchemaArray } from "./container-schema";
import { TeamSchema } from "./user-schema";

export const RenderShipmentSchema = z.object({
	shipment: ShipmentSchema,
	vessel: VesselSchema.nullable(),
	status: ShipmentStatusSchema.nullable(),
	client: ClientsSchema.nullable(),
	type: ShipmentTypesSchema.nullable(),
	payment: ShipmentPaymentsSchema.nullable(),
	info: ShipmentInfoSchema.nullable(),
	containers: ContainerSchemaArray.nullable(),
	teams: TeamSchema.nullable(),
	notes: ShipmentNotesSchemaArray.nullable(),
});
export const RenderShipmentSchemaArray = z.array(RenderShipmentSchema);
export type RenderShipment = z.infer<typeof RenderShipmentSchema>;
