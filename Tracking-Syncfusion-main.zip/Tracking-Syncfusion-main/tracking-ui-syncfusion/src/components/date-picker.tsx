import type { CustomCellEditorProps } from "ag-grid-react";
import { format } from "date-fns";
import dayjs from "dayjs";
import timezone from "dayjs/plugin/timezone";
import utc from "dayjs/plugin/utc";
import { CalendarIcon, Clock3, X } from "lucide-react";
import { useMemo, useState } from "react";

import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from "@/components/ui/popover";

dayjs.extend(utc);
dayjs.extend(timezone);

const TIMEZONE_AU = "Australia/Sydney";

function getLocalDate(value: unknown): Date | undefined {
	if (typeof value !== "string" || !dayjs(value).isValid()) return undefined;

	const dateInAustralia = dayjs(value).tz(TIMEZONE_AU);
	return new Date(
		dateInAustralia.year(),
		dateInAustralia.month(),
		dateInAustralia.date(),
	);
}

export default function CustomDatePicker(props: CustomCellEditorProps) {
	const initialDate = useMemo(() => getLocalDate(props.value), [props.value]);
	const [open, setOpen] = useState(true);
	const [date, setDate] = useState<Date | undefined>(initialDate);
	const [time, setTime] = useState(() =>
		initialDate && typeof props.value === "string"
			? dayjs(props.value).tz(TIMEZONE_AU).format("HH:mm")
			: "00:00",
	);

	const commitValue = (nextDate: Date | undefined, nextTime: string) => {
		if (!nextDate) {
			props.onValueChange(null);
			return;
		}

		const dateTime = dayjs.tz(
			`${format(nextDate, "yyyy-MM-dd")}T${nextTime}`,
			TIMEZONE_AU,
		);
		props.onValueChange(dateTime.utc().toISOString());
	};

	const closeEditor = () => {
		setOpen(false);
		props.stopEditing();
	};

	const selectDate = (nextDate: Date | undefined) => {
		setDate(nextDate);
		commitValue(nextDate, time);
	};

	const selectTime = (nextTime: string) => {
		setTime(nextTime);
		commitValue(date, nextTime);
	};

	const selectNow = () => {
		const now = dayjs().tz(TIMEZONE_AU);
		const nextDate = new Date(now.year(), now.month(), now.date());
		const nextTime = now.format("HH:mm");
		setDate(nextDate);
		setTime(nextTime);
		commitValue(nextDate, nextTime);
	};

	const displayValue = date
		? `${format(date, "dd/MM/yyyy")} ${time}`
		: "Select date and time";

	return (
		<Popover
			open={open}
			onOpenChange={(nextOpen) => {
				setOpen(nextOpen);
				if (!nextOpen) props.stopEditing();
			}}
		>
			<PopoverTrigger
				render={
					<Button
						variant="ghost"
						className="h-full w-full justify-start rounded-none px-2 text-xs font-normal"
					>
						<CalendarIcon className="size-3.5 text-muted-foreground" />
						<span className="truncate">{displayValue}</span>
					</Button>
				}
			/>
			<PopoverContent
				className="w-auto p-0"
				align="start"
				onKeyDown={(event) => {
					if (event.key === "Tab") closeEditor();
					if (event.key === "Enter") closeEditor();
				}}
			>
				<Calendar
					mode="single"
					required
					selected={date}
					onSelect={selectDate}
					defaultMonth={date}
					onDayClick={(_, __, event) => {
						if (event.detail === 2) closeEditor();
					}}
				/>
				<div className="flex items-center gap-1.5 border-t p-2">
					<Clock3 className="ml-1 size-3.5 text-muted-foreground" />
					<Input
						type="time"
						step="60"
						value={time}
						onChange={(event) => selectTime(event.target.value)}
						className="h-7 w-2/3 px-1.5 text-xs"
						aria-label="Time"
					/>

					<Button
						variant="ghost"
						size="icon-xs"
						onClick={() => {
							selectDate(undefined);
							closeEditor();
						}}
						aria-label="Clear date and time"
					>
						<X />
					</Button>
					<Button
						variant="ghost"
						size="xs"
						onClick={() => {
							selectNow();
							closeEditor();
						}}
					>
						Now
					</Button>
				</div>
			</PopoverContent>
		</Popover>
	);
}
