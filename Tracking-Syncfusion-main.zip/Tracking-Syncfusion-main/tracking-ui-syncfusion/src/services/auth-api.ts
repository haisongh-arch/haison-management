import axios from "axios";
import { type User, UserSchema } from "../schemas/user-schema";

const host = import.meta.env.VITE_HOST_URL;

export async function login(userName: string, passWord: string) {
	let url = host + "/api/auth/login";
	try {
		const res = await axios.post(
			url,
			{
				userName: userName,
				passWord: passWord,
			},
			{ withCredentials: true },
		);
		// console.log(res.data);
		return res.data;
	} catch (err: any) {
		if (err.response?.status == 401) {
			throw new Error("Username or password wrong");
		}
		if (err.response?.status == 500) {
			throw new Error("Something wrong");
		}
	}
}
export async function logout() {
	let url = host + "/api/auth/logout";
	try {
		const res = await axios.post(url, {}, { withCredentials: true });
		return res.data;
	} catch (err: any) {
		if (err.response?.status == 401) {
			throw new Error("Username or password wrong");
		}
		if (err.response?.status == 500) {
			throw new Error("Something wrong");
		}
	}
}

export async function authenticate() {
	let url = host + "/api/auth/getme";
	try {
		const res = await axios.get(url, { withCredentials: true });
		const user: User = UserSchema.parse(res.data);
		console.log(user);
		return user;
	} catch (err) {
		return null;
	}
}
