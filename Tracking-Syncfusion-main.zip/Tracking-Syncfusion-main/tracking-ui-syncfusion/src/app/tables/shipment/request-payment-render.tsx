import { useState, useMemo } from "react";
import type { CustomCellEditorProps } from "ag-grid-react";
import dayjs from "dayjs";
import timezone from "dayjs/plugin/timezone";
import utc from "dayjs/plugin/utc";
import { Mail } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle,
	DialogFooter,
} from "@/components/ui/dialog";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
	SelectGroup,
} from "@/components/ui/select";
import {
	Tooltip,
	TooltipContent,
	TooltipProvider,
	TooltipTrigger,
} from "@/components/ui/tooltip";
import { Label } from "@/components/ui/label";

import useDropDownEditList from "@/hooks/useDropDownEditList";
import {
	type Shippingline,
	ShippinglinesSchemaArray,
} from "@/schemas/shipping-line-schema";

dayjs.extend(utc);
dayjs.extend(timezone);

const TIMEZONE_AU = "Australia/Sydney";

interface Props extends CustomCellEditorProps {
	requestType?: string;
	requestParty?: string;
	title?: string;
}

interface SelectOptions {
	value: string;
	label: string;
}

export default function RequestPaymentRender(props: Props) {
	const [isModalOpen, setIsModalOpen] = useState(false);
	const [selectedTarget, setSelectedTarget] = useState<string | null>(null);
	const { data: dropDownEditList } = useDropDownEditList();

	const shipping_lines = useMemo<Shippingline[]>(() => {
		if (!dropDownEditList.shipping_lines) return [];
		try {
			return ShippinglinesSchemaArray.parse(dropDownEditList.shipping_lines);
		} catch (error) {
			console.error("Parse shipping lines error:", error);
			return [];
		}
	}, [dropDownEditList]);

	const options: SelectOptions[] = useMemo(() => {
		if (!dropDownEditList?.shipping_lines) return [];

		try {
			const shipping_lines: Shippingline[] = ShippinglinesSchemaArray.parse(
				dropDownEditList.shipping_lines,
			);

			if (props.requestParty === "SHIPPING_LINE") {
				return shipping_lines.map((s) => ({
					value: String(s.id), // Bắt buộc ép về String
					label: s.name ?? "Unknown",
				}));
			}
			return [];
		} catch (error) {
			console.error("Parse shipping lines error:", error);
			return [];
		}
	}, [dropDownEditList?.shipping_lines, props.requestParty]);

	const handleChange = (value: string | null) => {
		if (value) setSelectedTarget(value);
	};

	const handleSendMail = () => {
		const sanitize = (val: any) =>
			typeof val === "string" ? val.replace(/[\r\n\t]+/g, "").trim() : val;

		const target = shipping_lines.find(
			(s: Shippingline) => String(s.id) === selectedTarget,
		);

		const { po, shipper, product, pod, pol, mbl, hbl, expedient_code } =
			props.data?.shipment || {};

		let emailList: string[] = [];
		let emailSubject = "";
		let emailBody = "";

		switch (props.requestType) {
			case "INVOICE": {
				emailList = [target?.email_invoice1, target?.email_invoice2].filter(
					Boolean,
				) as string[];
				emailSubject = `Local charge invoice request${mbl ? ` -MB/L ${sanitize(mbl) || ""}` : ""}${hbl ? ` -HBL ${sanitize(hbl) || ""}` : ""}${expedient_code ? ` -Our ref ${sanitize(expedient_code) || ""}` : ""}`;
				const invoiceBody = [
					`Dear ${target?.name},`,
					" ",
					"Please advise us on the local charge invoice for the subject shipment",
					" ",
					mbl ? `MBL: ${sanitize(mbl)}` : null,
					hbl ? `HBL: ${sanitize(hbl)}` : null,
				].filter(Boolean);
				emailBody = invoiceBody.join("\n");
				break;
			}
			case "EDO": {
				emailList = [target?.email_edo1, target?.email_edo2].filter(
					Boolean,
				) as string[];
				emailSubject = `EDO request${mbl ? ` -MB/L ${sanitize(mbl) || ""}` : ""}${hbl ? ` -HBL ${sanitize(hbl) || ""}` : ""}${expedient_code ? ` -Our ref ${sanitize(expedient_code) || ""}` : ""}`;
				const edoBody = [
					`Dear ${target?.name},`,
					" ",
					"Please find the attached Remittance and release EDO for the subject shipment",
					" ",
					mbl ? `MBL: ${sanitize(mbl)}` : null,
					hbl ? `HBL: ${sanitize(hbl)}` : null,
				].filter(Boolean);
				emailBody = edoBody.join("\n");
				break;
			}
			default:
				break;
		}

		const emailAddress = emailList.join("; ");
		const mailtoUrl = `mailto:${emailAddress}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
		window.location.href = mailtoUrl;
		setIsModalOpen(false);
	};

	if (props.value)
		return dayjs(props.value).tz(TIMEZONE_AU).format("DD/MM/YYYY");

	const tooltipTitle = props.title ?? "Sending email to request invoice";

	return (
		<div className="flex justify-end w-full h-full">
			<TooltipProvider delay={200}>
				<Tooltip>
					{/* 💡 Dùng trực tiếp TooltipTrigger làm Button luôn, xóa thẻ <Button> con */}
					<TooltipTrigger
						type="button"
						className="flex items-center justify-center h-full w-6 p-0 bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-300 rounded transition-colors"
						onClick={(e) => {
							e.stopPropagation();
							setIsModalOpen(true);
						}}
					>
						<Mail className="h-3 w-3" />
					</TooltipTrigger>
					<TooltipContent>{tooltipTitle}</TooltipContent>
				</Tooltip>
			</TooltipProvider>

			<Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
				<DialogContent className="sm:max-w-md">
					<DialogHeader>
						<DialogTitle>{tooltipTitle}</DialogTitle>
					</DialogHeader>

					<div className="mt-2 flex flex-col gap-2">
						<Label htmlFor="target-select">
							Choose target <span className="text-destructive">*</span>
						</Label>
						<Select
							onValueChange={handleChange}
							value={selectedTarget ?? undefined}
							items={options}
						>
							<SelectTrigger id="target-select" className="w-full">
								<SelectValue placeholder="Select target..." />
							</SelectTrigger>
							<SelectContent>
								<SelectGroup>
									{options.map((opt) => (
										<SelectItem key={opt.value} value={opt.value}>
											{opt.label}
										</SelectItem>
									))}
								</SelectGroup>
							</SelectContent>
						</Select>
					</div>

					<DialogFooter>
						<Button variant="outline" onClick={() => setIsModalOpen(false)}>
							Cancel
						</Button>
						<Button onClick={handleSendMail} disabled={!selectedTarget}>
							<Mail className="h-4 w-4" />
							Email (Mailto)
						</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</div>
	);
}
