// gridFilters.ts
import {
	type DoesFilterPassParams,
	type FilterHandler,
} from "ag-grid-community";

export const SetFilterHandler: () => FilterHandler<any, any, number> = () => {
	return {
		doesFilterPass: (params: DoesFilterPassParams) => {
			const { node, model, handlerParams } = params;
			// Nếu không có model (hoặc model = null) -> Không lọc (cho qua tất cả)
			if (!model) return true;

			if (node === undefined || node === null) return false;

			if (Array.isArray(model.values)) {
				if (typeof handlerParams.api.getCellValue === "function") {
					const stringNodeValue = String(
						handlerParams.api.getCellValue({
							rowNode: node,
							colKey: String(handlerParams.colDef.colId),
							useFormatter: true,
						}),
					);

					// Xử lý so sánh
					const isTrue = model.values.includes(stringNodeValue);
					return isTrue;
				} else {
					const cellValue = handlerParams.getValue(node);
					// Xử lý so sánh
					const isTrue = model.values.includes(cellValue);
					return isTrue;
				}
			}
			if (typeof model === "object" && model.filterType === "text") {
				let stringNodeValue = "";
				if (typeof handlerParams.api.getCellValue === "function") {
					stringNodeValue = String(
						handlerParams.api.getCellValue({
							rowNode: node,
							colKey: String(handlerParams.colDef.colId),
							useFormatter: true,
						}),
					)
						.toLowerCase()
						.trim();
				} else {
					stringNodeValue = String(handlerParams.getValue(node))
						.toLowerCase()
						.trim();
				}
				const searchText = String(model.filter).toLowerCase().trim();
				return stringNodeValue.includes(searchText);
			}
			return false;
		},
		getModelAsString: (model: any) => {
			if (!model) return "";
			if (typeof model === "object" && model.filterType === "text")
				return model.filter;
			if (Array.isArray(model.values)) {
				if (model.values.length === 0) return "";
				if (model.values.length === 1) return String(model.values[0]);
				return `${String(model.values.length)} selected`;
			}
			return "";
		},
	};
};
