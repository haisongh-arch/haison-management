// hooks/useDropDownEditList.ts
import { useQuery } from "@tanstack/react-query";
import { getDropDownEditList } from "../services/shipment-api";
import { arrayToMap } from "@/utils/array-to-map-helper";

export default function useDropDownEditList() {
	return useQuery({
		queryKey: ["dropDownEditList"],
		queryFn: getDropDownEditList,
		retry: true,
		staleTime: Infinity, // Đảm bảo không refetch lại vô lý
		select: (rawData) => {
			if (!rawData) return rawData;
			return {
				...rawData,
				clientRefMap: arrayToMap(rawData.client, "id", "short_name"),
				statusRefMap: arrayToMap(rawData.status, "id", "name"),
			};
		},
	});
}
