import { BrowserRouter, Routes, Route } from "react-router";
import Shipment from "@/app/dashboard/shipment-page";
import { AuthProvider } from "./providers/auth-provider";
import LoginPage from "@/app/dashboard/login-page";
import { ProtectProvider } from "./providers/protect-provider";
import RootIndex from "@/app/dashboard/root-index";
import ForbiddenPage from "@/app/dashboard/403";

import CustomerShipmentPage from "@/app/dashboard/external/customer-shipment-manage";

function App() {
	return (
		<BrowserRouter>
			<AuthProvider>
				<Routes>
					{/* Public Route */}
					<Route path="/" element={<RootIndex />} />
					<Route path="/403" element={<ForbiddenPage />} />

					{/* Login page */}
					<Route>
						<Route path="/login" element={<LoginPage />} />
					</Route>

					{/* Internal page */}
					<Route
						element={<ProtectProvider allowedRoles={["admin", "internal"]} />}
					>
						<Route path="/manage/shipment" element={<Shipment />} />
					</Route>

					{/* External page */}
					<Route element={<ProtectProvider />}>
						<Route
							path="/customer/shipment"
							element={<CustomerShipmentPage />}
						/>
					</Route>
				</Routes>
			</AuthProvider>
		</BrowserRouter>
	);
}

export default App;
