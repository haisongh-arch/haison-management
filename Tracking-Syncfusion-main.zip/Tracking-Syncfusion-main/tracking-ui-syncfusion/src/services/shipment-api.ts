import axios from "axios";
import { RenderShipmentSchemaArray } from "../schemas/render-shipment";
import type { RenderShipment } from "@/schemas/render-shipment";

import type { Client } from "@/schemas/client-schema";

const host = import.meta.env.VITE_HOST_URL;

export async function getAllShipment() {
	let url = host + "/api/shipments/all";
	const res = await axios.get(url, { withCredentials: true });
	if (res.status == 403) return []; //Unauthorize
	let shipments: RenderShipment[];
	try {
		shipments = RenderShipmentSchemaArray.parse(res.data);
		console.log("API get all shipment called");
		return shipments;
	} catch (error) {
		console.log(error);
	}
}

export async function getCustomerAllShipment() {
	let url = host + "/api/clients/shipments";
	const res = await axios.get(url, { withCredentials: true });
	if (res.status == 403) return []; //Unauthorize
	let shipments: RenderShipment[];
	try {
		shipments = RenderShipmentSchemaArray.parse(res.data);
		console.log("API get all shipment called");
		return shipments;
	} catch (error) {
		console.log(error);
	}
}

export async function getDropDownEditList() {
	try {
		let url = host + "/api/shipments/dropdown";
		const res = await axios.get(url, { withCredentials: true });
		if (res.status == 403) return []; //Unauthorize
		console.log("API get dropdown called");
		return res.data;
	} catch (error) {
		console.log(error);
	}
}

export async function confirmNewETA(idShipment: number, colId: string) {
	try {
		let url = host + `/api/shipments/eta-notification/${idShipment}`;
		const res = await axios.patch(
			url,
			{
				colId: colId,
			},
			{ withCredentials: true },
		);
		if (res.status == 403) return []; //Unauthorize
		return res.data;
	} catch (error) {
		console.log(error);
	}
}

export async function updateShipmentType(
	idShipment: number,
	idType: number,
	colId: string,
) {
	try {
		let url = host + `/api/shipments/type/${idShipment}`;
		const res = await axios.patch(
			url,
			{ idType: idType, colId: colId },
			{ withCredentials: true },
		);
		if (res.status == 403) return []; //Unauthorize
		return res.data;
	} catch (error) {
		console.log(error);
	}
}

export async function updateShipmentSB(
	idShipment: number,
	type: boolean,
	colId: string,
) {
	try {
		let url = host + `/api/shipments/sb/${idShipment}`;
		const res = await axios.patch(
			url,
			{ type: type, colId: colId },
			{ withCredentials: true },
		);
		if (res.status == 403) return []; //Unauthorize
		return res.data;
	} catch (error) {
		console.log(error);
	}
}

export async function updateShipmentDetails(idShipment: number, data: any) {
	try {
		let url = host + `/api/shipments/${idShipment}`;
		const res = await axios.patch(
			url,
			{ data: data },
			{ withCredentials: true },
		);
		if (res.status == 403) return []; //Unauthorize
		return res.data;
	} catch (error) {
		console.log(error);
		return null;
	}
}

export async function addNewShipmentWithIdAndTeam(
	shipmentId: string,
	teamId: number,
) {
	try {
		let url = host + `/api/shipments/`;
		const res = await axios.post(
			url,
			{ shipmentId: shipmentId, teamId: teamId },
			{ withCredentials: true },
		);
		if (res.status == 403) return []; //Unauthorize
		return res.data;
	} catch (error) {
		console.log(error);
	}
}

export async function addNewNoteWithShipmentId(
	shipmentId: string,
	userId: number,
	colId: String,
	note: String,
) {
	try {
		let url = host + `/api/shipments/${shipmentId}/notes`;
		const res = await axios.post(
			url,
			{ shipmentId: shipmentId, userId: userId, colId: colId, note: note },
			{ withCredentials: true },
		);
		if (res.status == 403) return []; //Unauthorize
		return res.data;
	} catch (error) {
		console.log(error);
	}
}

export async function addNewClient(client: Client) {
	try {
		let url = host + `/api/clients`;
		const res = await axios.post(url, { client }, { withCredentials: true });
		if (res.status == 403) return []; //Unauthorize
		return res.data;
	} catch (error) {
		console.log(error);
	}
}
