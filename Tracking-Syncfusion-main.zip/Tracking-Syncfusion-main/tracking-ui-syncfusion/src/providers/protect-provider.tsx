// src/providers/protect-provider.tsx
import { Navigate, Outlet } from "react-router";
import { useAuth } from "../context/auth-context";

type Props = {
	allowedRoles?: string[]; // Danh sách các role được phép truy cập
	children?: React.ReactNode;
};

export const ProtectProvider = ({ allowedRoles, children }: Props) => {
	const { user, isLoading } = useAuth(); // Nên có thêm state isLoading từ AuthContext

	// 1. Tránh redirect nhầm khi đang check session/token từ API
	if (isLoading) {
		return <div>Loading authentication...</div>; // Hoặc Spinner Component
	}

	// 2. Kiểm tra Authentication (Chưa đăng nhập)
	if (!user) {
		return <Navigate to="/login" replace />;
	}

	// 3. Kiểm tra Authorization (Phân quyền theo Role)
	if (allowedRoles && allowedRoles.length > 0) {
		const hasPermission = allowedRoles.includes(user.roleName);

		if (!hasPermission) {
			// Chuyển hướng tới trang 403 Forbidden hoặc Dashboard mặc định
			return <Navigate to="/403" replace />;
		}
	}

	// Tận dụng Outlet cho Layout Routes hoặc render children nếu bọc trực tiếp
	return children ? <>{children}</> : <Outlet />;
};
