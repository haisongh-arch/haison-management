import { z } from "zod";
import { ContainersSchema } from "../schemas/container-schema";
import { ShipmentSchema, ShipmentInfoSchema } from "@/schemas/shipment-schema";
import { ClientsSchema } from "@/schemas/client-schema";
const zNullableString = z.string().nullable();
const zNullableNumber = z.coerce.number().nullable();

export const DeliverySchema = z.object({
	id: zNullableNumber,
	created_at: zNullableString,
	container_id: zNullableNumber,
	delivery_plan: zNullableString,
	delivery_actual: zNullableString,
	dehire: zNullableString,
});

export const ContainerDeliverySchema = z.object({
	container: ContainersSchema,
	delivery: DeliverySchema,
});

export const DeliveryPlanSchema = z.object({
	shipment: ShipmentSchema,
	client: ClientsSchema,
	container: ContainersSchema,
	delivery: DeliverySchema,
});

export const DeliveriesPlanSchema = z.array(DeliveryPlanSchema);
export type DeliveryPlan = z.infer<typeof DeliveryPlanSchema>;

export const DeliverySchemaArray = z.array(DeliverySchema);
export type Delivery = z.infer<typeof DeliverySchema>;

export const ContainerDeliverySchemaArray = z.array(ContainerDeliverySchema);
export type ContainerDelivery = z.infer<typeof ContainerDeliverySchema>;
