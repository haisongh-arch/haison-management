import type { CustomCellEditorProps } from "ag-grid-react";
import { Check, ChevronsUpDown } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import {
	Command,
	CommandEmpty,
	CommandGroup,
	CommandInput,
	CommandItem,
	CommandList,
} from "@/components/ui/command";
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { type Vessel } from "@/schemas/vesselSchema";
import { getVesselByName } from "@/services/vessel-api";

type VesselOption = {
	value: string;
	vessel: Pick<Vessel, "name" | "id" | "in_voyage" | "pod">;
};

export default function VesselCellEditor(props: CustomCellEditorProps) {
	const [open, setOpen] = useState(true);
	const [query, setQuery] = useState("");
	const [options, setOptions] = useState<VesselOption[]>([]);
	const [isLoading, setIsLoading] = useState(false);
	const selectedValue = props.value == null ? "" : props.value;
	const selectedLabel = useMemo(
		() => options.find((option) => option.value === selectedValue)?.vessel.name,
		[options, selectedValue],
	);

	useEffect(() => {
		const searchString = query.trim();
		if (!searchString) {
			setOptions([]);
			setIsLoading(false);
			return;
		}

		let cancelled = false;
		setIsLoading(true);
		const timer = window.setTimeout(async () => {
			try {
				const vessels = await getVesselByName(
					searchString,
					props.data?.shipment?.pod ?? "",
				);
				if (cancelled) return;
				// const hasExactMatch = vessels.some(
				// 	(vessel) =>
				// 		vessel.name?.toLocaleLowerCase() ===
				// 		searchString.toLocaleLowerCase(),
				// );
				const vesselOptions = vessels.map((vessel) => ({
					value: String(vessel.id),
					vessel,
				}));
				setOptions([
					{
						value: searchString,
						vessel: {
							name: searchString,
							id: null,
							in_voyage: "",
							pod: String(props.data?.shipment?.pod ?? ""),
						},
					},
					...vesselOptions,
				]);
			} catch {
				if (!cancelled) setOptions([]);
			} finally {
				if (!cancelled) setIsLoading(false);
			}
		}, 200);

		return () => {
			cancelled = true;
			window.clearTimeout(timer);
		};
	}, [props.data?.shipment?.pod, query]);

	const selectVessel = (vessel: VesselOption["vessel"]) => {
		props.onValueChange(vessel);
		setOpen(false);
		props.stopEditing();
	};

	return (
		<Popover
			open={open}
			onOpenChange={(nextOpen) => {
				setOpen(nextOpen);
				if (!nextOpen) props.stopEditing();
			}}
		>
			<PopoverTrigger className="flex h-full w-full items-center justify-between gap-1 px-2 text-left ">
				<span className="truncate">
					{(selectedLabel ?? selectedValue.name) || "Select vessel"}
				</span>
				<ChevronsUpDown className="size-3 shrink-0 opacity-50" />
			</PopoverTrigger>
			<PopoverContent className="w-[320px] p-0" align="start">
				<Command shouldFilter={false}>
					<CommandInput
						autoFocus
						placeholder="Search vessel..."
						value={query}
						onValueChange={setQuery}
					/>
					<CommandList>
						<CommandEmpty>
							{isLoading
								? "Searching vessels..."
								: query
									? "No vessel found."
									: "Type to search vessels."}
						</CommandEmpty>
						<CommandGroup>
							{options.map(({ value, vessel }) => (
								<CommandItem
									key={value}
									value={value}
									onSelect={() => selectVessel(vessel)}
								>
									<div className="flex min-w-0 items-center gap-1 ">
										<span className="truncate font-bold text-gray-900">
											{vessel.name}
										</span>
										{vessel.in_voyage && (
											<span className="shrink-0 italic text-gray-600">
												/ {vessel.in_voyage}
											</span>
										)}
										{vessel.pod && (
											<span className="shrink-0 font-bold text-red-600">
												/ {vessel.pod}
											</span>
										)}
									</div>
									<Check
										className={cn(
											"ml-auto size-4",
											selectedValue === value ? "opacity-100" : "opacity-0",
										)}
									/>
								</CommandItem>
							))}
						</CommandGroup>
					</CommandList>
				</Command>
			</PopoverContent>
		</Popover>
	);
}
