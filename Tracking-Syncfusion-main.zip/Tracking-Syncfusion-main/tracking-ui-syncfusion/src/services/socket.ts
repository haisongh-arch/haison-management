import { io } from "socket.io-client";
const host = import.meta.env.VITE_HOST_URL;

const socket = io(host, {
	withCredentials: true, // 🌟 BẮT BUỘC: Lệnh cho trình duyệt tự động đính kèm Cookie HttpOnly lên Backend
	autoConnect: false, // Tự động kết nối ngay khi file này được nạp (Mặc định là true)
});

socket.on("connect", () => {
	console.log(`Socket established, your ID ${socket.id}`);
});

export default socket;
