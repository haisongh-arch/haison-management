import { Separator } from "@/components/ui/separator";
import { SidebarTrigger } from "@/components/ui/sidebar";
import type React from "react";

function SiteHeaderMain({ children }: { children?: React.ReactNode }) {
	return (
		<header className="flex h-(--header-height) shrink-0 items-center gap-2 border-b transition-[width,height] ease-linear group-has-data-[collapsible=icon]/sidebar-wrapper:h-(--header-height)">
			<div className="flex w-full items-center gap-1 px-4 lg:gap-2 lg:px-6">
				<SidebarTrigger className="-ml-1" />
				<Separator
					orientation="vertical"
					className="mx-2 h-4 data-vertical:self-auto"
				/>
				{children}
			</div>
		</header>
	);
}
const Title = ({ children }: { children?: React.ReactNode }) => {
	return <h1 className="text-base font-medium">{children}</h1>;
};

const Left = ({ children }: { children?: React.ReactNode }) => {
	return <div className="flex items-center gap-2">{children}</div>;
};

const Right = ({ children }: { children?: React.ReactNode }) => {
	return <div className="ml-auto flex items-center gap-2">{children}</div>;
};

export const SiteHeader = Object.assign(SiteHeaderMain, {
	Title,
	Left,
	Right,
});
