import { SearchIcon } from "lucide-react";
import { X } from "lucide-react";
import {
	InputGroup,
	InputGroupAddon,
	InputGroupInput,
} from "@/components/ui/input-group";
import { cn } from "@/lib/utils";
import { useState } from "react";
interface SearchInputProps {
	value?: string;
	defaultValue?: string;
	onChange?: (value: string) => void;
	placeholder?: string;
	className?: string;
}
export function SearchInput({
	value: externalValue,
	defaultValue = "",
	onChange,
	placeholder = "Search...",
	className,
}: SearchInputProps) {
	const [internalInput, setInternalInput] = useState(defaultValue);
	const isControlled = externalValue !== undefined;
	const currentValue = isControlled ? externalValue : internalInput;

	const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		if (!isControlled) {
			setInternalInput(e.target.value);
		}
		onChange?.(e.target.value);
	};

	const handleClear = (e: React.MouseEvent) => {
		e.preventDefault();
		if (!isControlled) {
			setInternalInput("");
		}
		onChange?.("");
	};

	return (
		<InputGroup className={cn("max-w-sm", className)}>
			<InputGroupInput
				id="inline-start-input"
				placeholder={placeholder}
				value={currentValue}
				onChange={handleChange}
			/>
			<InputGroupAddon align="inline-start">
				<SearchIcon className="text-muted-foreground" />
			</InputGroupAddon>
			<InputGroupAddon align="inline-end">
				{currentValue != "" ? (
					<X className="text-muted-foreground" onClick={handleClear} />
				) : (
					""
				)}
			</InputGroupAddon>
		</InputGroup>
	);
}
