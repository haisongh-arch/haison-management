import * as z from "zod";
const zNullableString = z.string().nullable();
const zNullableNumber = z.coerce.number().nullable();
export const UserSchema = z.object({
	id: zNullableNumber,
	userName: zNullableString,
	name: zNullableString,
	roleId: zNullableNumber,
	roleName: zNullableString,
	teamId: zNullableNumber,
	teamName: zNullableString,
	clientId: zNullableNumber,
});

export const TeamSchema = z.object({
	id: zNullableNumber,
	name: zNullableString,
});

export type User = z.infer<typeof UserSchema>;
export type Team = z.infer<typeof TeamSchema>;
