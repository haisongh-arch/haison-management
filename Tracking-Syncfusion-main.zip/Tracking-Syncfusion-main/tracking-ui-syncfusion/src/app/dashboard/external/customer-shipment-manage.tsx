import { AppSidebar } from "@/components/app-sidebar";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/site-header";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";

import { SearchInput } from "@/components/search-input";

import React, { useEffect, useState, useRef, useMemo } from "react";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { getCustomerAllShipment } from "@/services/shipment-api";
import type { GridApi } from "ag-grid-community";

import { Loader2 } from "lucide-react";
import HaiSonLogo from "@/assets/haison-logo.png";
import CustomerShipmentTable from "@/app/tables/customer-shipment/customer-shipment-table";
import CsvExport from "@/components/csv-export";
const getShipment = async () => {
	return getCustomerAllShipment();
};

export default function CustomerShipmentPage() {
	const queryClient = useQueryClient();
	const [gridApi, setGridApi] = useState<GridApi | null>(null);

	const {
		data,
		isLoading,
		isError: isShipmentError,
	} = useQuery({
		queryKey: ["allCustomerShipments"],
		queryFn: getShipment,
		retry: true,
	});

	//#region State for Delivery sidebar

	const [isDeliverySideBarOpen, setisDeliverySideBarOpen] = useState(false);

	//#endregion
	//#endregion

	if (isLoading) {
		return (
			<div className="w-screen min-h-screen flex items-center justify-center bg-background">
				<div className="flex flex-col items-center gap-4">
					<img alt="Hai Son logo" src={HaiSonLogo} className="h-12 w-auto" />
					<Button disabled>
						<Loader2 className="mr-2 size-4 animate-spin" />
						Loading...
					</Button>
				</div>
			</div>
		);
	}
	// Handling Error Case
	if (isShipmentError) {
		return (
			<div className="flex h-screen w-full flex-col items-center justify-center gap-4 bg-background p-4">
				<p className="text-sm font-medium text-destructive">Error</p>
				<Button
					variant="outline"
					onClick={() => queryClient.invalidateQueries()}
				>
					Retry
				</Button>
			</div>
		);
	}
	return (
		<SidebarProvider
			style={
				{
					"--sidebar-width": "calc(var(--spacing) * 72)",
					"--header-height": "calc(var(--spacing) * 12)",
				} as React.CSSProperties
			}
			className="h-screen w-full overflow-hidden"
		>
			<AppSidebar variant="inset" />
			<SidebarInset>
				<SiteHeader>
					<SiteHeader.Left>
						{/*Export button */}
						<CsvExport
							gridApi={gridApi}
							columnsSavingName="SHIPMENT-TABLE-EXPORT"
						></CsvExport>
					</SiteHeader.Left>
					<SiteHeader.Right>
						<SearchInput
							onChange={(value: string) => {
								gridApi?.setFilterModel(null);
								gridApi?.setGridOption("quickFilterText", value);
							}}
							className="w-24 sm:w-48 "
						></SearchInput>
					</SiteHeader.Right>
				</SiteHeader>

				{/*Modals*/}
				<div className="flex flex-1 flex-col">
					<div className="@container/main flex flex-1 flex-col gap-2">
						<div className="flex flex-1 flex-col gap-4 py-4 md:gap-6 md:py-6 min-h-0">
							<div className="flex-1 min-h-0">
								<CustomerShipmentTable
									data={data}
									setGridApi={setGridApi}
								></CustomerShipmentTable>
							</div>
						</div>
					</div>
				</div>
			</SidebarInset>
		</SidebarProvider>
	);
}
