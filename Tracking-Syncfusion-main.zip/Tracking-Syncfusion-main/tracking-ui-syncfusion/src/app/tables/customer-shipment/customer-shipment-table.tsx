import { useMemo, useRef, useEffect, useCallback, useState } from "react";

import { AllCommunityModule } from "ag-grid-community";
import {
	type ColDef,
	themeQuartz,
	type GetRowIdParams,
	type NewValueParams,
	type ValueGetterParams,
	type EditableCallbackParams,
	type ValueFormatterParams,
	type GridApi,
	type CellKeyDownEvent,
} from "ag-grid-community";
import {
	AgGridProvider,
	AgGridReact,
	type CustomCellRendererProps,
} from "ag-grid-react";

import { updateShipmentDetails } from "@/services/shipment-api";

import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { type Container } from "@/schemas/container-schema";

import CustomSetFilter from "@/app/ag-grid-utils/set-filter";
import { SetFilterHandler } from "@/app/ag-grid-utils/set-filter-handler";

import { CellClass } from "./css-class";

import CustomHeader from "../shipment/custom-column-header-aggrid";
import CustomGroupHeader from "../shipment/custom-columngroup-header-aggrid";
import useDropDownEditList from "@/hooks/useDropDownEditList";

type Props = {
	data: any;
	setGridApi: (params: GridApi) => void;
	searchTextForShipmentTable?: string;
	containerTypes?: [];
};

dayjs.extend(utc);
dayjs.extend(timezone);

const TIMEZONE_AU = "Australia/Sydney"; // Khóa cứng múi giờ Úc (Sydney)

const dateFormat = "DD/MM/YYYY HH:mm";

const dateFormatNormal = "DD/MM/YYYY";
// Initilaize Table property

const COLUMN_STATE = "customer-shipment-grid-column-state";
const COLUMN_DEFS = "customer-shipment-grid-column-defs";
const AG_GRID_FONT_SIZE = "ag_grid_font_size";
const modules = [AllCommunityModule];

const defaultColDef = {
	cellStyle: {
		padding: 0,
		paddingLeft: 2,
	},
	editable: false,
	wrapText: true,
	autoHeight: true,

	headerComponentParams: {
		innerHeaderComponent: CustomHeader,
	},
};

const defaultColGroupDef = {
	headerGroupComponentParams: {
		innerHeaderGroupComponent: CustomGroupHeader,
	},
};

function saveColumnsState(params: any) {
	try {
		const columnsSize = params.api.getColumnState();
		const columnsDef = params.api.getColumnDefs();
		localStorage.setItem(COLUMN_STATE, JSON.stringify(columnsSize));
		localStorage.setItem(COLUMN_DEFS, JSON.stringify(columnsDef));
	} catch (error) {}
}

function onGridReady(params: any) {
	try {
		const columnsSize = localStorage.getItem(COLUMN_STATE);
		const columnsDefs = localStorage.getItem(COLUMN_DEFS);
		if (columnsSize) {
			params.api.applyColumnState({
				state: JSON.parse(columnsSize),
				applyOrder: true,
			});
		}
		// 2. Restore thuộc tính columnGroupShow nhưng GIỮ NGUYÊN Custom Component gốc
		if (columnsDefs) {
			const savedDefs = JSON.parse(columnsDefs);
			const currentDefs = params.api.getColumnDefs() || [];

			// Hàm hợp nhất đệ quy (hỗ trợ cả Nhóm cột lồng nhau)
			const mergeGroupShow = (currentList: any[], savedList: any[]): any[] => {
				return currentList.map((col) => {
					// Tìm item tương ứng trong LocalStorage theo field hoặc colId
					const matched = savedList.find(
						(s) => (s.colId || s.field) === (col.colId || col.field),
					);

					let updatedCol = { ...col };

					// Khôi phục columnGroupShow nếu có
					if (matched?.columnGroupShow !== undefined) {
						updatedCol.columnGroupShow = matched.columnGroupShow;
					}

					// Đệ quy cho các cột con trong Group
					if (col.children && matched?.children) {
						updatedCol.children = mergeGroupShow(
							col.children,
							matched.children,
						);
					}

					return updatedCol;
				});
			};

			const updatedDefs = mergeGroupShow(currentDefs, savedDefs);

			// Cập nhật lại columnDefs an toàn mà không làm mất Component/Custom Header
			params.api.setGridOption("columnDefs", updatedDefs);
		}
	} catch (error) {}
}

export default function CustomerShipmentTable(props: Props) {
	const { data: dropDownEditList, isPending: dropDownPending } =
		useDropDownEditList();
	// 1. Khởi tạo state từ localStorage (nếu có)
	const [fontSize, setFontSize] = useState<number>(() => {
		const saved = localStorage.getItem(AG_GRID_FONT_SIZE);
		return saved ? Number(saved) : 9;
	});

	// 2. Tự động tính headerFontSize tỉ lệ thuận (hoặc cho user chỉnh riêng)
	const headerFontSize = useMemo(() => fontSize + 1, [fontSize]);

	// 3. Tự động đồng bộ CSS Variable toàn cục cho các Portal / Cell Editor / Popover
	useEffect(() => {
		// Cập nhật lại biến :root để các Popover/Dialog con ăn theo ngay lập tức
		document.documentElement.style.setProperty(
			"--ag-font-size",
			`${fontSize}px`,
		);
		localStorage.setItem("ag_grid_font_size", String(fontSize));
	}, [fontSize]);

	// 4. Khai báo Theme động bằng useMemo (Chỉ re-calculate khi fontSize đổi)
	const myTheme = useMemo(() => {
		return themeQuartz.withParams({
			columnBorder: true,
			headerFontSize: headerFontSize,
			borderWidth: 1,
			borderColor: "#000",
			fontSize: fontSize, // 👈 Truyền giá trị từ state vào đây
		});
	}, [fontSize, headerFontSize]);

	// Hold grid API
	const gridRef = useRef<any>(null);

	// Grid selection
	const rowSelection: any = useMemo(() => {
		return {
			mode: "singleRow",
			checkboxes: false,
			enableClickSelection: true,
		};
	}, []);

	// GetRowID to prevent AG grid re-render whole list
	const getRowId = useMemo(() => {
		return (params: GetRowIdParams) => {
			const shipmentId = params.data?.shipment?.id;

			// Cảnh báo nếu ID bị undefined/null (thủ phạm khiến AG Grid không định danh được row)
			if (shipmentId == null) {
				console.warn(
					"[getRowId] WARNING: shipment.id is missing or undefined for row:",
					params.data,
				);
			}

			return String(shipmentId);
		};
	}, []);

	//Defind column
	const colDefs = useMemo<ColDef[]>(() => {
		return [
			//#region Mandatory columns
			//Shipment
			{
				field: "shipment.expedient_code",
				colId: "shipment.expedient_code",
				headerName: "Hai Son REF",
				sortable: true,
				enableCellChangeFlash: true,
				pinned: true,
				filter: {
					component: CustomSetFilter,
					handler: SetFilterHandler,
				},
				// 2. Bật Floating Filter
				floatingFilter: true,
				floatingFilterComponent: "agTextColumnFloatingFilter",
				// 3. Chỉ định Floating Filter dùng giao diện Text đơn giản
				floatingFilterComponentParams: {
					suppressFilterButton: false, // Hiển thị hoặc ẩn nút phễu nhỏ bên cạnh ô text
				},
				valueFormatter: (params: ValueFormatterParams) => {
					return params.value.slice(0, 7);
				},
			},

			// Client
			// {
			// 	field: "client.full_name",
			// 	colId: "client.full_name",
			// 	headerName: "Client",
			// 	pinned: true,
			// 	editable: false,
			// 	sortable: true,
			// 	enableCellChangeFlash: true,
			// 	getQuickFilterText: (params: any) => {
			// 		const id = params.value;
			// 		return params.context?.clientRefMap?.[id];
			// 	},

			// 	// 2. Bật Floating Filter
			// 	floatingFilter: true,
			// 	floatingFilterComponent: "agTextColumnFloatingFilter",
			// 	// 3. Chỉ định Floating Filter dùng giao diện Text đơn giản
			// 	floatingFilterComponentParams: {
			// 		suppressFilterButton: false, // Hiển thị hoặc ẩn nút phễu nhỏ bên cạnh ô text
			// 	},
			// },

			// Status
			// {
			// 	field: "status.id",
			// 	colId: "status.id",
			// 	headerName: "Status",

			// 	pinned: true,
			// 	editable: false,
			// 	sortable: true,
			// 	filter: {
			// 		component: CustomSetFilter,
			// 		handler: SetFilterHandler,
			// 	},

			// 	// 2. Bật Floating Filter
			// 	floatingFilter: true,
			// 	floatingFilterComponent: "agTextColumnFloatingFilter",
			// 	enableCellChangeFlash: true,
			// },

			// To ETA
			// {
			// 	colId: "to_ETA",
			// 	headerName: "To ETA",
			// 	valueGetter: (p) => {
			// 		const vesselEta = p.data?.vessel?.eta;
			// 		const manualEta = p.data?.shipment?.manual_eta;
			// 		const rawEta = vesselEta || manualEta;

			// 		if (!rawEta) return 99999; // Hoặc trả về số cực lớn/bé nếu muốn đẩy lên đầu/cuối khi sort

			// 		const eta = dayjs(rawEta).tz(TIMEZONE_AU);
			// 		if (!eta.isValid()) return null;

			// 		const now = dayjs().tz(TIMEZONE_AU);

			// 		// Đặt true để lấy giá trị số thực (float) thay vì bị làm tròn nguyên
			// 		// Ví dụ: 3.12456 thay vì 3
			// 		return eta.diff(now, "day");
			// 	},

			// 	filter: "agNumberColumnFilter",
			// 	filterParams: {
			// 		// pass in additional parameters to the Number Filter
			// 		buttons: ["clear"],
			// 		defaultOption: "lessThanOrEqual",
			// 	},
			// 	filterValueGetter: (params: ValueGetterParams) => {
			// 		const value = params.getValue("to_ETA");

			// 		if (typeof value === "number") {
			// 			return value ?? null;
			// 		}
			// 		return null;
			// 	},
			// 	pinned: true,
			// 	editable: false,
			// 	sortable: true,
			// 	floatingFilter: true,
			// 	enableCellChangeFlash: true,
			// },
			//#endregion

			//#region B/L info
			{
				headerName: "B/L details",
				headerClass: CellClass.TABLE_HEADER_ORANGE,

				children: [
					//MBL
					{
						colId: "MBL",
						field: "shipment.mbl",
						headerName: "MBL",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						columnGroupShow: "close",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},
					//HBL
					{
						colId: "HBL",
						field: "shipment.hbl",
						headerName: "HBL",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						columnGroupShow: "close",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Containers (No target table, seperate API)
					{
						field: "containers",
						colId: "CONTAINERS",
						headerName: "Containers",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						columnGroupShow: "close",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueGetter: (params: any) => {
							let containers = params.data.containers;
							if (!containers || !Array.isArray(containers)) return "";
							return (containers = containers
								.map((c: any) => c.number)
								.join(", "));
						},
						filterValueGetter: (params: any) => {
							let containers = params.data.containers;
							if (!containers || !Array.isArray(containers)) return "";
							return (containers = containers
								.map((c: any) => c.number)
								.join(", "));
						},
						wrapText: true,
					},

					//Container type (No target table, seperate API)
					{
						field: "containers",
						colId: "CONTAINER-TYPE",
						headerName: "Type",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						columnGroupShow: "close",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueGetter: (params: ValueGetterParams) => {
							const containers = params.data.containers;
							if (
								!containers ||
								!Array.isArray(containers) ||
								containers.length === 0
							)
								return "";

							// 1. Dùng reduce để đếm số lượng từng loại container
							const counts = containers.reduce(
								(acc: Record<string, number>, container: Container) => {
									const typeID = container.type;
									const typeObj = params.context?.container_types?.find(
										(t: any) => t.id === typeID,
									);
									const typeName = typeObj?.name || "Unknown";

									// Tăng biến đếm
									acc[typeName] = (acc[typeName] || 0) + 1;
									return acc;
								},
								{},
							);

							// 2. Chuyển Object đếm được thành chuỗi hiển thị (VD: "2x 20GP, 1x 40HC")
							return Object.entries(counts)
								.map(([name, count]) => `${count}x${name}`)
								.join(" , ");
						},
					},

					//PO & Quote
					{
						colId: "PO",
						field: "shipment.po",
						headerName: "PO & Quote",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Shipper
					{
						colId: "SHIPPER",
						field: "shipment.shipper",
						headerName: "Shipper",
						headerClass: CellClass.TABLE_HEADER_ORANGE,
						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Product
					{
						colId: "PRODUCT",
						field: "shipment.product",
						headerName: "Product",
						headerClass: CellClass.TABLE_HEADER_ORANGE,

						columnGroupShow: "close",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Gross weight
					{
						colId: "GROSS WEIGHT",
						field: "info.gross_weight",
						headerName: "G.Weight",
						headerClass: CellClass.TABLE_HEADER_ORANGE,

						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Charge weight
					{
						colId: "CHARGE WEIGHT",
						field: "info.charge_weight",
						headerName: "C.Weight",
						headerClass: CellClass.TABLE_HEADER_ORANGE,

						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//Unit
					{
						colId: "UNIT",
						field: "info.unit",
						headerName: "Unit",
						headerClass: CellClass.TABLE_HEADER_ORANGE,

						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//POL
					{
						colId: "POL",
						field: "shipment.pol",
						headerName: "Origin",
						headerClass: CellClass.TABLE_HEADER_ORANGE,

						columnGroupShow: "close",
						editable: false,
						sortable: true,
						filter: true,
						filterParams: {
							// pass in additional parameters to the Number Filter
							buttons: ["clear"],
						},
						floatingFilter: true,
						enableCellChangeFlash: true,
					},

					//POD
					{
						colId: "POD",
						field: "shipment.pod",
						headerName: "Destination",
						headerClass: CellClass.TABLE_HEADER_ORANGE,

						columnGroupShow: "close",
						editable: false,
						sortable: true,

						filter: {
							component: CustomSetFilter,
							handler: SetFilterHandler,
						},
						// 2. Bật Floating Filter
						floatingFilter: true,
						floatingFilterComponent: "agTextColumnFloatingFilter",
						enableCellChangeFlash: true,
						filterValueGetter: (params: any) => {
							let pod = params.data.shipment.pod;
							if (!pod) return "";
							return pod;
						},
					},
				],
			},
			//#endregion

			//#region Vessel details
			{
				headerName: "Vessel",
				headerClass: CellClass.TABLE_HEADER_PURPLE,
				children: [
					//Vessel name
					{
						field: "shipment.vessel_id",
						colId: "vessel",
						headerName: "Vessel",
						headerClass: CellClass.TABLE_HEADER_PURPLE,

						columnGroupShow: "close",
						editable: false,
						sortable: true,
						filter: {
							component: CustomSetFilter,
							handler: SetFilterHandler,
						},

						// 2. Bật Floating Filter
						floatingFilter: true,
						floatingFilterComponent: "agTextColumnFloatingFilter",
						// 3. Chỉ định Floating Filter dùng giao diện Text đơn giản
						floatingFilterComponentParams: {
							suppressFilterButton: false, // Hiển thị hoặc ẩn nút phễu nhỏ bên cạnh ô text
						},
						enableCellChangeFlash: true,

						valueFormatter: (params: ValueFormatterParams) => {
							return params.data.shipment.vessel_id
								? params.data.vessel?.name
								: params.data.shipment.manual_vessel_name;
						},

						filterValueGetter: (params: any) => {
							return params.data.shipment.vessel_id
								? params.data.vessel?.name
								: params.data.shipment.manual_vessel_name;
						},
					},

					//Vessel voy
					{
						field: "shipment.manual_vessel_voy",
						colId: "VESSEL_VOY",
						headerName: "Voy",
						headerClass: CellClass.TABLE_HEADER_PURPLE,
						columnGroupShow: "close",

						editable: false,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueGetter: (params: ValueGetterParams) => {
							const voy =
								params.data.vessel?.in_voyage ||
								params.data.shipment.manual_vessel_voy;
							return voy;
						},
					},
					//ETD
					{
						field: "shipment.manual_etd",
						colId: "ETD",
						headerName: "ETD Transit",
						headerClass: CellClass.TABLE_HEADER_PURPLE,
						columnGroupShow: "close",

						editable: false,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueFormatter: (params: ValueFormatterParams) => {
							const value = params?.data?.shipment?.manual_etd;
							if (value) {
								return dayjs(value).tz(TIMEZONE_AU).format(dateFormatNormal);
							} else return "";
						},
					},
					//ETA
					{
						field: "shipment.manual_eta",
						colId: "ETA",
						headerName: "ETA",
						headerClass: CellClass.TABLE_HEADER_PURPLE,
						columnGroupShow: "close",

						editable: false,

						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueFormatter: (params: ValueFormatterParams) => {
							let eta = params?.data?.vessel?.eta;
							if (eta) {
								return dayjs(eta).tz(TIMEZONE_AU).format(dateFormat);
							} else {
								eta = params.data.shipment.manual_eta;
								if (!eta) return "";
								return dayjs(eta).tz(TIMEZONE_AU).format(dateFormat);
							}
						},
						valueGetter: (params: ValueGetterParams) => {
							let eta = params?.data?.vessel?.eta;
							if (eta) {
								return dayjs(eta).tz(TIMEZONE_AU);
							} else {
								eta = params.data.shipment.manual_eta;
								if (!eta) return "";
								return dayjs(eta).tz(TIMEZONE_AU);
							}
						},
					},

					//Vessel FA
					{
						field: "vessel.first_available",
						colId: "FIRST AVAILABLE",
						headerName: "First Available",
						headerClass: CellClass.TABLE_HEADER_PURPLE,
						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueGetter: (params: ValueGetterParams) => {
							let fa = params?.data?.vessel?.first_available;
							if (fa) {
								return dayjs(fa).tz(TIMEZONE_AU).format(dateFormat);
							} else {
								return "";
							}
						},
					},
					//Vessel FFD
					{
						field: "vessel.first_free",
						colId: "FIRST FREE DAY",
						headerName: "First Free Day",
						headerClass: CellClass.TABLE_HEADER_PURPLE,

						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueGetter: (params: ValueGetterParams) => {
							let ffd = params?.data?.vessel?.first_free;
							if (ffd) {
								return dayjs(ffd).tz(TIMEZONE_AU).format(dateFormat);
							} else {
								return "";
							}
						},
					},
					//Vessel Last Free
					{
						field: "vessel.storage_start",
						colId: "WHARF STORAGE",
						headerName: "Wharf Storage",
						headerClass: CellClass.TABLE_HEADER_PURPLE,

						columnGroupShow: "open",
						editable: false,
						sortable: true,
						filter: true,
						floatingFilter: true,
						enableCellChangeFlash: true,
						valueGetter: (params: ValueGetterParams) => {
							let str = params?.data?.vessel?.storage_start;
							if (str) {
								return dayjs(str).tz(TIMEZONE_AU).format(dateFormat);
							} else {
								return "";
							}
						},
					},
				],
			},
			//#endregion
		];
	}, [dropDownEditList]);

	const cellValueChanged = async (params: any) => {
		// 1. Helper làm sạch chuỗi
		const sanitize = (val: any) =>
			typeof val === "string" ? val.replace(/[\r\n\t]+/g, "").trim() : val;

		const cleanedOldValue = sanitize(params.oldValue);
		const cleanedNewValue = sanitize(params.newValue);

		if (cleanedOldValue === cleanedNewValue) return;

		const shipmentID = params.data.shipment?.id;
		if (!shipmentID) return;
		// 💡 Spread trực tiếp colDef.context và đè/thêm colId + newValue ngay tại chỗ
		const context = {
			...params.colDef.context,
			colId: params.colDef.colId,
			newValue: cleanedNewValue,
		};
		if (params.column.colId == "vessel") {
			if (context.newValue.id == null) {
				context.targetColumn = "manual_vessel_name";
				context.newValue = context.newValue.name;
			} else {
				context.targetColumn = "vessel_id";
				context.newValue = context.newValue.id;
			}
		}

		const result = await updateShipmentDetails(shipmentID, context);
		if (!result) {
		}
	};

	const handleKeyDown = useCallback(async (e: CellKeyDownEvent) => {
		// Kiểm tra phím Ctrl (hoặc Cmd trên Mac) + phím 'c' hoặc 'C'
		const keyDown = e.event as KeyboardEvent;
		if (
			(keyDown.ctrlKey || keyDown.metaKey) &&
			keyDown.key.toLowerCase() === "c"
		) {
			let valueCopy = e.value;
			if (e.colDef.colId === "vessel") {
				valueCopy = e.api.getCellValue({
					rowNode: e.node!,
					colKey: e.column,
					useFormatter: true,
				});
			}

			navigator.clipboard.writeText(valueCopy);
			// 2. Lấy thẻ ô AG Grid và add trực tiếp các utility class của Tailwind
			const target = keyDown.target as HTMLElement;
			const cellElement = target?.closest(".ag-cell") as HTMLElement;

			if (cellElement) {
				cellElement.classList.add("cell-copied-flash");

				setTimeout(() => {
					cellElement.classList.remove("cell-copied-flash");
				}, 400);
			}
		}

		if (
			(keyDown.ctrlKey || keyDown.metaKey) &&
			keyDown.key.toLowerCase() === "v"
		) {
			try {
				// 1. Đọc chuỗi văn bản bất đồng bộ từ Clipboard
				const textToPaste = await navigator.clipboard.readText();
				if (textToPaste !== undefined && textToPaste !== null) {
					// 2. Gán giá trị vào ô bằng e.column hoặc e.colDef.field
					if (typeof e.value === "number")
						return e.node?.setDataValue(e.column, Number(textToPaste.trim()));
					e.node?.setDataValue(e.column, textToPaste);
				}
			} catch (err) {
				console.error("Không thể đọc dữ liệu từ Clipboard:", err);
			}
		}
	}, []);

	return (
		<AgGridProvider modules={modules}>
			<div style={{ height: "100%", width: "100%" }}>
				<AgGridReact
					theme={myTheme}
					rowData={props.data}
					columnDefs={colDefs}
					defaultColDef={defaultColDef}
					defaultColGroupDef={defaultColGroupDef}
					onColumnResized={saveColumnsState}
					onColumnMoved={saveColumnsState}
					onColumnPinned={saveColumnsState}
					onColumnVisible={saveColumnsState}
					onSortChanged={saveColumnsState}
					onDisplayedColumnsChanged={saveColumnsState}
					onGridReady={(params) => {
						onGridReady(params);

						gridRef.current = params;
						props.setGridApi(params.api);
					}}
					onCellValueChanged={(params) => {
						cellValueChanged(params);
					}}
					getRowId={getRowId}
					undoRedoCellEditing={true}
					rowSelection={rowSelection}
					rowHeight={27}
					suppressDragLeaveHidesColumns={true}
					enableFilterHandlers={true}
					loading={!props.data}
					onCellKeyDown={handleKeyDown}
					suppressMoveWhenColumnDragging={true}
					context={dropDownEditList}
				/>
			</div>
		</AgGridProvider>
	);
}
