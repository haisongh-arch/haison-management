import { useMemo, useEffect, useRef } from "react";
import dayjs from "dayjs";
import { Badge } from "@/components/ui/badge";
import { Clock, Container, User } from "lucide-react";
import {
	groupDeliveriesByDate,
	formatDeliveryTime,
} from "@/utils/delivery-helpers";

import { cn } from "@/lib/utils";

import { type DeliveryPlan } from "@/schemas/container-delivery-schema";

interface DeliveryScheduleListProps {
	data?: DeliveryPlan[];
	isLoading?: boolean;
}

export function DeliveryScheduleList({
	data = [],
	isLoading,
}: DeliveryScheduleListProps) {
	const groupedData = useMemo(() => groupDeliveriesByDate(data), [data]);

	// Lưu danh sách ref của các phần tử group ngày
	const groupRefs = useRef<Record<string, HTMLDivElement | null>>({});

	useEffect(() => {
		if (isLoading || !groupedData.length) return;

		const todayKey = dayjs().format("YYYY-MM-DD");

		// 1. Ưu tiên tìm group ngày hôm nay
		let targetKey = groupedData.find((g) => g.dateKey === todayKey)?.dateKey;

		// 2. Nếu hôm nay không có lịch, tìm ngày tương lai gần nhất
		if (!targetKey) {
			const nextUpcomingGroup = groupedData.find(
				(g) => g.dateKey > todayKey && g.dateKey !== "9999-99-99",
			);
			targetKey = nextUpcomingGroup?.dateKey;
		}

		// 3. Thực hiện scroll mượt đến vị trí group đó
		if (targetKey && groupRefs.current[targetKey]) {
			// Dùng setTimeout nhỏ để đảm bảo DOM đã layout xong hoàn toàn
			const timer = setTimeout(() => {
				groupRefs.current[targetKey]?.scrollIntoView({
					behavior: "smooth",
					block: "start",
				});
			}, 100);

			return () => clearTimeout(timer);
		}
	}, [groupedData, isLoading]);

	if (isLoading) {
		return (
			<div className="p-4 text-center text-sm text-muted-foreground animate-pulse">
				Loading delivery schedule...
			</div>
		);
	}

	if (!groupedData.length) {
		return (
			<div className="p-4 text-center text-sm text-muted-foreground">
				No schedule found
			</div>
		);
	}

	const todayKey = dayjs().format("YYYY-MM-DD");

	return (
		<div className="space-y-6 pb-4">
			{groupedData.map((group) => {
				const isToday = group.dateKey === todayKey;

				return (
					<div
						key={group.dateKey}
						// Gán ref cho từng group ngày theo dateKey (YYYY-MM-DD)
						ref={(el) => {
							groupRefs.current[group.dateKey] = el;
						}}
						className={cn(
							"space-y-2 transition-all rounded-r-lg pl-3 pr-1 py-1",
							isToday
								? "border-l-4 border-emerald-500 bg-emerald-500/5 dark:bg-emerald-500/10"
								: "",
						)}
					>
						{/* Header Group Ngày */}
						<div className="sticky top-0 z-10 -mx-4 px-4 py-2 bg-background/95 backdrop-blur border-b flex items-center justify-between">
							<div className="flex items-center gap-2">
								<span className="text-xs font-bold tracking-wider text-primary uppercase">
									{group.dateDisplay}
								</span>
								{/* Badge highlight nếu là ngày hôm nay */}
								{isToday && (
									<Badge
										variant="default"
										className="text-[10px] h-4 px-1 bg-emerald-600 hover:bg-emerald-600"
									>
										TODAY
									</Badge>
								)}
							</div>
							<Badge variant="secondary" className="text-[10px] h-5 px-1.5">
								{group.items.length} container
							</Badge>
						</div>

						{/* Danh sách các container giao trong ngày */}
						<div className="space-y-2 pt-1">
							{group.items.map((item, idx) => {
								const timeStr = formatDeliveryTime(
									item.delivery?.delivery_actual,
								);
								return (
									<div
										key={item.delivery?.id || idx}
										className="p-3 rounded-lg border bg-card text-card-foreground shadow-sm hover:border-primary/50 transition-colors text-sm space-y-2"
									>
										<div className="flex items-center justify-between font-medium">
											<div className="flex items-center gap-1.5 text-xs text-foreground">
												<Clock className="w-3.5 h-3.5 text-primary shrink-0" />
												<span className="font-semibold">{timeStr}</span>
											</div>
											{item.container?.type && (
												<Badge
													variant="outline"
													className="text-[11px] font-normal py-0 h-5"
												>
													{item.container.type}
												</Badge>
											)}
										</div>

										<div className="text-xs space-y-1">
											<div className="flex items-center gap-1.5 font-mono font-medium text-foreground">
												<Container className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
												<span className="truncate text-wrap">
													{item.container?.number || "N/A"}{" "}
													{item.shipment.expedient_code}
												</span>
											</div>
											<div className="flex items-center gap-1.5 text-muted-foreground">
												<User className="w-3.5 h-3.5 shrink-0" />
												<span className="truncate text-wrap">
													{item.client?.short_name || "N/A"}
												</span>
											</div>
										</div>
									</div>
								);
							})}
						</div>
					</div>
				);
			})}
		</div>
	);
}
