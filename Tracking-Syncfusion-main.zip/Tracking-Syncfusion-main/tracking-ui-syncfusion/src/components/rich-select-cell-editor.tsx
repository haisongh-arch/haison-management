import { useState, useEffect } from "react";
import type { CustomCellEditorProps } from "ag-grid-react";
import { Check, ChevronsUpDown } from "lucide-react";

import { cn } from "@/lib/utils";

import {
	Command,
	CommandEmpty,
	CommandGroup,
	CommandInput,
	CommandItem,
	CommandList,
} from "@/components/ui/command";
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from "@/components/ui/popover";

interface MyCustomProps extends CustomCellEditorProps {
	values?: any[];
}

export default function CustomRichSelect(props: MyCustomProps) {
	const options = props.values || [];
	const [open, setOpen] = useState(true); // Mặc định mở popover khi vào chế độ edit
	const [selectedValue, setSelectedValue] = useState<string>(
		props.value != null ? String(props.value) : "",
	);

	const handleSelect = (currentValue: string) => {
		// Tìm option tương ứng
		const selectedOpt = options.find((opt: any) => {
			const v = typeof opt === "object" && opt !== null ? opt.value : opt;
			return String(v).toLowerCase() === currentValue.toLowerCase();
		});

		const finalVal =
			typeof selectedOpt === "object" && selectedOpt !== null
				? selectedOpt.value
				: currentValue;

		setSelectedValue(String(finalVal));
		props.onValueChange?.(finalVal);
		setOpen(false);
		props.stopEditing?.(); // Đóng cell editor của AG Grid
	};

	// Lấy label hiển thị trên nút Trigger
	const getDisplayLabel = () => {
		if (!selectedValue) return "Select an option...";
		const found = options.find((opt: any) => {
			const v = typeof opt === "object" && opt !== null ? opt.value : opt;
			return String(v) === selectedValue;
		});
		if (typeof found === "object" && found !== null) {
			return found.label ?? found.value;
		}
		return found ?? selectedValue;
	};

	return (
		<Popover
			open={open}
			onOpenChange={(isOpen) => {
				setOpen(isOpen);
				if (!isOpen) props.stopEditing?.();
			}}
		>
			<PopoverTrigger>
				<span className="truncate">{getDisplayLabel()}</span>
				<ChevronsUpDown className="ml-1 h-3 w-3 shrink-0 opacity-50" />
			</PopoverTrigger>
			<PopoverContent
				className="w-[200px] p-0"
				align="start"
				initialFocus={false}
			>
				<Command>
					<CommandInput
						placeholder="Search option..."
						className="h-8 text-xs"
						autoFocus={Boolean(props.cellStartedEdit)}
						tabIndex={-1} // Ngăn phím Tab tự động rơi vào input search khi chưa focus tới ô
					/>
					<CommandList>
						<CommandEmpty className="py-2 text-center text-xs">
							No option found.
						</CommandEmpty>
						<CommandGroup>
							{options.map((opt: any, index: number) => {
								const rawVal =
									typeof opt === "object" && opt !== null ? opt.value : opt;
								const rawLabel =
									typeof opt === "object" && opt !== null ? opt.label : opt;

								const itemValue = String(rawVal ?? index);
								const itemLabel = String(rawLabel ?? rawVal ?? "");

								return (
									<CommandItem
										key={itemValue}
										value={itemLabel} // cmdk dùng value này để filter theo chuỗi tìm kiếm
										onSelect={() => handleSelect(itemValue)}
										className="text-xs"
									>
										<Check
											className={cn(
												"mr-2 h-3 w-3",
												selectedValue === itemValue
													? "opacity-100"
													: "opacity-0",
											)}
										/>
										{itemLabel}
									</CommandItem>
								);
							})}
						</CommandGroup>
					</CommandList>
				</Command>
			</PopoverContent>
		</Popover>
	);
}
