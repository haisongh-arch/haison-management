export const CellClass = {
	// 🎨 Tông màu Ant Design Chuẩn (Nhẹ nhàng, chuyên nghiệp cho Table)
	ANTD_SUCCESS: "bg-[#f6ffed] text-[#389e0d] border border-[#b7eb8f]",
	ANTD_WARNING: "bg-[#fffbe6] text-[#d48806] border border-[#ffe58f]",
	ANTD_ERROR: "bg-[#fff2f0] text-[#cf1322] border border-[#ffccc7]",
	ANTD_INFO: "bg-[#e6f7ff] text-[#0958d9] border border-[#91caff]",

	TABLE_HEADER_ORANGE: "bg-[#E26B0A] text-black font-bold border border-black",
	TABLE_HEADER_PURPLE: "bg-[#538DD5] text-black font-bold border border-black",
	TABLE_HEADER_GREEN: "bg-[#00B050] text-black font-bold border border-black",

	CELL_GREEN: "bg-[#00B050] text-black  border border-black",

	// 🚦 Trạng thái hệ thống (Chuẩn Tailwind CSS)
	SUCCESS: "bg-emerald-100 text-emerald-800",
	WARNING: "bg-amber-100 text-amber-800",
	ERROR: "bg-rose-100 text-rose-800",
	INFO: "bg-sky-100 text-sky-800",

	// 🔥 Cảnh báo mức độ / Cấp độ thời gian (ETA, Số ngày chênh lệch)
	CRITICAL: "bg-red-200 text-red-900 font-bold", // Rất gấp / Quá hạn
	WARM: "bg-orange-100 text-orange-800", // Sắp tới hạn
	COOL: "bg-blue-100 text-blue-800", // Còn nhiều thời gian
	COLD: "bg-slate-100 text-slate-700", // Bình thường

	// ⚪ Trạng thái phụ
	NEUTRAL: "bg-gray-100 text-gray-600", // Trung tính
	DISABLED: "bg-gray-200 text-gray-400 opacity-60", // Vô hiệu hóa / Khóa
};
