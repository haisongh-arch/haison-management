import { AuthContext } from "../context/auth-context";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import HaiSonLogo from "../assets/haison-logo.png";
import { authenticate, login, logout } from "../services/auth-api";
import socket from "@/services/socket";
import { SOCKET_EVENTS } from "@/utils/socket-constants";

type Props = {
	children: React.ReactNode;
};

export const AuthProvider = ({ children }: Props) => {
	// #region Hook
	const { data, isLoading } = useQuery({
		queryKey: ["auth-me"],
		queryFn: authenticate,
		retry: false,
	});
	const queryClient = useQueryClient();

	// #endregion

	// #region Function

	const logIn = async (userName: string, passWord: string) => {
		try {
			await login(userName, passWord);
			queryClient.invalidateQueries({ queryKey: ["auth-me"] });
		} catch (err: any) {
			throw err;
		}
	};

	const logOut = async () => {
		try {
			const res = await logout();
			queryClient.invalidateQueries({ queryKey: ["auth-me"] });
			return res.data;
		} catch (err: any) {
			return err;
		} finally {
			// 2. Ngắt Socket chủ động để BE dọn dẹp Room ngay lập tức
			if (socket && socket.connected) {
				socket.disconnect();
			}

			// 3. Xóa sạch React Query Cache trong RAM
			queryClient.clear();

			// 4. HARD REFRESH & Chuyển hướng cứng về trang Login
			window.location.href = "/login";
		}
	};

	if (isLoading) {
		return (
			<div className="w-screen min-h-screen flex items-center justify-center bg-background">
				<div className="flex flex-col items-center gap-4">
					<img alt="Hai Son logo" src={HaiSonLogo} className="h-12 w-auto" />
					<Button disabled>
						<Loader2 className="mr-2 size-4 animate-spin" />
						Loading...
					</Button>
				</div>
			</div>
		);
	}

	return (
		<AuthContext.Provider
			value={{
				user: data ?? null,
				isLoading: isLoading,
				logIn: logIn,
				logOut: logOut,
			}}
		>
			{children}
		</AuthContext.Provider>
	);
};
