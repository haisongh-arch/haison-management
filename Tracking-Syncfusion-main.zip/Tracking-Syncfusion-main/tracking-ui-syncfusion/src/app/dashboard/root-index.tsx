// src/components/root-index.tsx
import { Navigate } from "react-router";
import { useAuth } from "@/context/auth-context";

export default function RootIndex() {
	const { user, isLoading } = useAuth();

	if (isLoading) return <div>Loading...</div>;
	if (!user) return <Navigate to="/login" replace />;

	// Điều hướng theo Role
	switch (user.roleName?.toLocaleLowerCase()) {
		case "admin":
		case "internal":
			return <Navigate to="/manage/shipment" replace />;
		case "external":
			return <Navigate to="/customer/shipment" replace />;
		default:
			return <Navigate to="/403" replace />;
	}
}
