import * as React from "react";

import { NavDocuments } from "@/components/nav-documents";
import { NavMain } from "@/components/nav-main";
import { NavSecondary } from "@/components/nav-secondary";
import { NavUser } from "@/components/nav-user";
import {
	Sidebar,
	SidebarContent,
	SidebarFooter,
	SidebarHeader,
	SidebarMenu,
	SidebarMenuButton,
	SidebarMenuItem,
} from "@/components/ui/sidebar";
import {
	LayoutDashboardIcon,
	CameraIcon,
	FileTextIcon,
	Settings2Icon,
	DatabaseIcon,
	CommandIcon,
	User,
	Settings,
} from "lucide-react";
import { useAuth } from "@/context/auth-context";

const data = {
	navMain: [
		{
			title: "Shipments",
			url: "/manage/shipment",
			icon: <LayoutDashboardIcon />,
		},
	],

	navCustomerMain: [
		{
			title: "Dashboard",
			url: "/customer/shipment",
			icon: <User />,
		},
	],
	navClouds: [
		{
			title: "Capture",
			icon: <CameraIcon />,
			isActive: true,
			url: "#",
			items: [
				{
					title: "Active Proposals",
					url: "#",
				},
				{
					title: "Archived",
					url: "#",
				},
			],
		},
		{
			title: "Proposal",
			icon: <FileTextIcon />,
			url: "#",
			items: [
				{
					title: "Active Proposals",
					url: "#",
				},
				{
					title: "Archived",
					url: "#",
				},
			],
		},
		{
			title: "Prompts",
			icon: <FileTextIcon />,
			url: "#",
			items: [
				{
					title: "Active Proposals",
					url: "#",
				},
				{
					title: "Archived",
					url: "#",
				},
			],
		},
	],

	navSecondary: [
		{
			title: "Setting",
			url: "#",
			icon: <Settings />,
		},
	],

	documents: [
		{
			name: "Data Library",
			url: "#",
			icon: <DatabaseIcon />,
		},
	],
};

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
	const auth = useAuth();

	let user = {
		name: auth?.user?.name ?? "",
		email: "",
		avatar: "/avatars/shadcn.jpg",
	};

	return (
		<Sidebar collapsible="offcanvas" {...props}>
			<SidebarHeader>
				<SidebarMenu>
					<SidebarMenuItem>
						<SidebarMenuButton
							className="data-[slot=sidebar-menu-button]:p-1.5!"
							render={<a href="#" />}
						>
							<CommandIcon className="size-5!" />
							<span className="text-base font-semibold">Management</span>
						</SidebarMenuButton>
					</SidebarMenuItem>
				</SidebarMenu>
			</SidebarHeader>

			{/* Sidebar content for internal */}
			{["internal", "admin"].includes(
				auth?.user?.roleName?.toLocaleLowerCase() ?? "",
			) && (
				<SidebarContent>
					<NavMain items={data.navMain} />

					{/* External sidebar */}
					<NavSecondary items={data.navSecondary} className="mt-auto" />
				</SidebarContent>
			)}

			{/* Sidebar content for customer */}
			{["external"].includes(
				auth?.user?.roleName?.toLocaleLowerCase() ?? "",
			) && (
				<SidebarContent>
					<NavMain items={data.navCustomerMain} />

					{/* External sidebar */}
					{/* <NavSecondary items={data.navSecondary} className="mt-auto" /> */}
				</SidebarContent>
			)}

			<SidebarFooter>
				<NavUser user={user} />
			</SidebarFooter>
		</Sidebar>
	);
}
