import { z } from "zod";

const zNullableString = z.string().nullable();
const zNullableNumber = z.coerce.number().nullable();

export const ContainersSchema = z.object({
	id: zNullableNumber,
	number: zNullableString,
	type: zNullableNumber,
	shipment_id: zNullableNumber,
});
export const ContainerSchemaArray = z.array(ContainersSchema);

export type Container = z.infer<typeof ContainersSchema>;
