import React, { useState } from "react";
import type { CustomInnerHeaderGroupProps } from "ag-grid-react";
import { Settings } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from "@/components/ui/popover";

export interface MyCustomInnerHeaderProps extends CustomInnerHeaderGroupProps {
	icon?: string;
}

export default function CustomColumnGroupHeaderAGGrid(
	props: MyCustomInnerHeaderProps,
) {
	const [isMainMenuOpen, setIsMainMenuOpen] = useState(false);

	const childrenCols = props.columnGroup?.getChildren() || [];

	const handleColumnToggle = (childId: string, isChecked: boolean) => {
		try {
			const allColumnDefs = props.api.getColumnDefs() || [];
			const currentGroupId = props.columnGroup.getGroupId();
			const headerName = props.columnGroup.getColGroupDef()?.headerName;

			const updateColDefs = (defs: any[]): any[] => {
				return defs.map((def) => {
					if (
						def.groupId === currentGroupId ||
						(headerName && def.headerName === headerName)
					) {
						return {
							...def,
							children: def.children?.map((childDef: any) => {
								const id = childDef.colId || childDef.field;
								if (id === childId) {
									return {
										...childDef,
										columnGroupShow: isChecked ? "close" : "open",
									};
								}
								return childDef;
							}),
						};
					}

					if (def.children) {
						return { ...def, children: updateColDefs(def.children) };
					}

					return def;
				});
			};

			const newColDefs = updateColDefs(allColumnDefs);
			props.api.setGridOption("columnDefs", newColDefs);
		} catch (error) {
			console.error("Error updating column group visibility:", error);
		}
	};

	return (
		<div className="flex items-center justify-between w-full customInnerHeader">
			<div className="flex items-center gap-1.5 overflow-hidden">
				{props.icon && <i className={`fa ${props.icon}`}></i>}
				<span className="truncate">{props.displayName}</span>
			</div>

			<Popover open={isMainMenuOpen} onOpenChange={setIsMainMenuOpen}>
				<PopoverTrigger
					render={
						<Button
							variant="ghost"
							size="icon-xs"
							onClick={(e) => e.stopPropagation()}
							className="h-5 w-5 p-0 opacity-60 hover:opacity-100"
						>
							<Settings className="size-3.5" />
						</Button>
					}
				/>
				<PopoverContent align="end" className="w-52 p-3">
					<div className="max-h-60 overflow-y-auto flex flex-col gap-2">
						{childrenCols.map((col: any) => {
							const colId = col.getColId();
							const label = col.getColDef()?.headerName || colId;
							const isVisible = col.getColumnGroupShow() === "close";

							return (
								<label
									key={colId}
									className="flex items-center gap-2 text-xs cursor-pointer select-none"
								>
									<Checkbox
										checked={isVisible}
										onCheckedChange={(checked) =>
											handleColumnToggle(colId, !!checked)
										}
									/>
									<span className="truncate">{label}</span>
								</label>
							);
						})}
					</div>
				</PopoverContent>
			</Popover>
		</div>
	);
}
