import { z } from "zod";

const zNullableString = z.string().nullable();
const zNullableNumber = z.coerce.number().nullable();

export const ShippinglineSchema = z.object({
	id: zNullableNumber,
	name: zNullableString,
	created_at: zNullableString,
	email_edo1: zNullableString,
	email_edo2: zNullableString,
	email_invoice1: zNullableString,
	email_invoice2: zNullableString,
});
export const ShippinglinesSchemaArray = z.array(ShippinglineSchema);

export type Shippingline = z.infer<typeof ShippinglineSchema>;
