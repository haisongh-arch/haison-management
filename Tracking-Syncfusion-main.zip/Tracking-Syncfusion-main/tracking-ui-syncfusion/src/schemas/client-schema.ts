import { z } from "zod";

const zNullableString = z.string().nullable();
const zNullableNumber = z.coerce.number().nullable();

export const ClientsSchema = z.object({
	id: zNullableNumber,
	edi_code: zNullableString,
	short_name: zNullableString,
	full_name: zNullableString,
	mail1: zNullableString,
	mail2: zNullableString,
	mail3: zNullableString,
	mail4: zNullableString,
	mail5: zNullableString,
	mail6: zNullableString,
	phone: zNullableString,
});
export const ClientsSchemaArray = z.array(ClientsSchema);

export type Client = z.infer<typeof ClientsSchema>;
