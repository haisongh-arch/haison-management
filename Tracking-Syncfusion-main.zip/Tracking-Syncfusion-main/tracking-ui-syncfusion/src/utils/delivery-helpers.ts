import dayjs from "dayjs";
import { z } from "zod";
// Import DeliveryPlanSchema từ file schema của bạn
import { type DeliveryPlan } from "@/schemas/container-delivery-schema";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";

dayjs.extend(utc);
dayjs.extend(timezone);

const TIMEZONE_AU = "Australia/Sydney"; // Khóa cứng múi giờ Úc (Sydney)

const dateFormat = "DD/MM/YYYY HH:mm";
export interface GroupedDelivery {
	dateKey: string; // VD: "2026-09-20" để sort
	dateDisplay: string; // VD: "MON 20/09/2026"
	items: DeliveryPlan[];
}

export function groupDeliveriesByDate(
	deliveries: DeliveryPlan[] = [],
): GroupedDelivery[] {
	if (!deliveries.length) return [];

	const groups: Record<string, { dateDisplay: string; items: DeliveryPlan[] }> =
		{};

	deliveries.forEach((item) => {
		// Giả định trường thời gian giao hàng là item.delivery.deliveryDate (hoặc đổi tên theo đúng schema của bạn)
		const d = dayjs(item.delivery.delivery_actual).tz(TIMEZONE_AU);
		if (!d.isValid()) return;

		const dateKey = d.format("YYYY-MM-DD");
		// ddd: MON, TUE... | DD/MM/YYYY: 20/09/2026
		const dateDisplay = `${d.format("ddd").toUpperCase()} ${d.format("DD/MM/YYYY")}`;

		if (!groups[dateKey]) {
			groups[dateKey] = { dateDisplay, items: [] };
		}
		groups[dateKey].items.push(item);
	});

	// Sắp xếp các nhóm ngày tăng dần (ngày sớm nhất lên trước)
	return Object.entries(groups)
		.sort(([keyA], [keyB]) => keyA.localeCompare(keyB))
		.map(([dateKey, group]) => ({
			dateKey,
			dateDisplay: group.dateDisplay,
			// Sắp xếp các item trong cùng 1 ngày theo giờ tăng dần
			items: group.items.sort(
				(a, b) =>
					dayjs(a.delivery.delivery_actual).valueOf() -
					dayjs(b.delivery.delivery_actual).valueOf(),
			),
		}));
}

export function formatDeliveryTime(dateInput?: string | Date | null): string {
	if (!dateInput) return "--:--"; // Hoặc "N/A" tùy bạn chọn

	const d = dayjs(dateInput).tz(TIMEZONE_AU);
	return d.isValid() ? d.format("HH:mm") : "--:--";
}
