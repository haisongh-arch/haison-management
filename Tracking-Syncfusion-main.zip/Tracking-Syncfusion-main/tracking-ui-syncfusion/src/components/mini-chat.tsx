import React, { useState, useRef, useEffect } from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

export interface ChatMessage {
	id: string | number;
	userName: string;
	message: string;
	time: string;
	isCurrentUser?: boolean;
}

interface Props extends React.HTMLAttributes<HTMLDivElement> {
	messages: ChatMessage[];
	handleSubmit?: (value: string) => Promise<void> | void;
	isSending?: boolean;
}

export function MiniChatBox({
	messages,
	handleSubmit,
	isSending = false,
	className,
	...props
}: Props) {
	const [noteText, setNoteText] = useState("");
	const messagesEndRef = useRef<HTMLDivElement>(null);
	// Sửa kiểu dữ liệu từ SubmitEvent -> FormEvent
	const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
		e.preventDefault();
		if (!noteText.trim() || isSending) return;

		try {
			await handleSubmit?.(noteText.trim());
			setNoteText("");
		} catch (error) {
			console.error("Failed to send note:", error);
		}
	};

	const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
		if (e.key === "Enter" && !e.shiftKey) {
			e.preventDefault();
			e.currentTarget.form?.requestSubmit();
		}
	};

	const handleScrollToBottom = () => {
		messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
	};

	useEffect(() => {
		handleScrollToBottom();
	}, [messages]);

	return (
		<div
			className={cn("flex min-w-80 flex-col gap-3 border-t pt-3", className)}
			{...props}
		>
			{/* 1. Khung cuộn tin nhắn */}
			<ScrollArea className="h-48 w-full rounded-md border p-3">
				<div className="flex flex-col gap-3">
					{messages?.map((item) => (
						<div key={item.id} className="flex items-start gap-2 text-xs">
							<Avatar className="h-6 w-6 text-[10px]">
								<AvatarFallback className="bg-primary/10 text-primary font-bold">
									{item.userName?.slice(0, 1).toUpperCase() ?? "U"}
								</AvatarFallback>
							</Avatar>

							<div className="flex flex-1 flex-col gap-1 rounded-lg bg-muted p-2">
								<div className="flex items-center justify-between gap-2">
									<span className="font-semibold text-foreground">
										{item.userName}
									</span>
									<span className="text-[10px] text-muted-foreground">
										{item.time}
									</span>
								</div>
								<p className="whitespace-pre-wrap break-words text-muted-foreground">
									{item.message}
								</p>
							</div>
						</div>
					))}
					<div ref={messagesEndRef} />
				</div>
			</ScrollArea>

			{/* 2. Ô nhập liệu và nút gửi */}
			<form onSubmit={onSubmit} className="flex items-end gap-2">
				<Textarea
					rows={2}
					value={noteText}
					onChange={(e) => setNoteText(e.target.value)}
					onKeyDown={handleKeyDown}
					placeholder="Add a note... (Enter to send, Shift+Enter for new line)"
					className="min-h-[80px] resize-none text-xs"
				/>
				<Button
					type="submit"
					size="sm"
					className="h-9 shrink-0 text-xs"
					disabled={isSending || !noteText.trim()}
				>
					{isSending ? "Sending..." : "Send"}
				</Button>
			</form>
		</div>
	);
}
