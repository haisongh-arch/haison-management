import { createContext, useContext } from "react";

import type { User } from "../schemas/user-schema";

type AuthContextType = {
	user: User | null;
	isLoading: boolean;
	logIn: (userName: string, passWord: string) => Promise<void | null>;
	logOut: () => Promise<void>;
};

export const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
	const context = useContext(AuthContext);
	if (!context) {
		throw new Error("No user information in cookie");
	}
	return context;
};
