import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import type { IAfterGuiAttachedParams } from "ag-grid-community";

import type { CustomFilterDisplayProps } from "ag-grid-react";

import { useGridFilterDisplay } from "ag-grid-react";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default ({
	model,
	onModelChange,
	api,
	colDef,
	getValue,
}: CustomFilterDisplayProps) => {
	const [allValues, setAllValues] = useState<any[]>([]);
	const [searchText, setSearchText] = useState("");
	const refInput = useRef<HTMLInputElement>(null);

	const afterGuiAttached = useCallback((params?: IAfterGuiAttachedParams) => {
		if (!params || !params.suppressFocus) {
			// Focus the input element for keyboard navigation.

			// Can't do this in an effect,

			// as the component is not recreated when hidden and then shown again

			refInput.current?.focus();
		}
	}, []);

	// Hàm lấy value từ node an toàn
	const getValueFromNode = useCallback(
		(node: any) => {
			if (!node || !colDef) return null;

			if (typeof api.getCellValue === "function")
				return api.getCellValue({
					rowNode: node,
					colKey: String(colDef.colId),
					useFormatter: true,
				});

			if (typeof getValue === "function") {
				return getValue(node);
			}
			const field = colDef?.field;
			if (field && node.data) {
				return field
					.split(".")
					.reduce((obj: any, key: string) => obj?.[key], node.data);
			}
			return null;
		},
		[colDef, getValue],
	);

	// 1. Quét dữ liệu bảng để trích xuất danh sách giá trị Unique
	useEffect(() => {
		if (!api) return;

		const uniqueValues = new Set();
		api.forEachNode((node: any) => {
			const val = getValueFromNode(node);
			if (val !== undefined && val !== null && val !== "") {
				uniqueValues.add(val);
			}
		});

		const valuesArray = Array.from(uniqueValues).sort();
		setAllValues(valuesArray);
	}, [api, getValueFromNode]);

	useEffect(() => {
		if (model === null) {
			setSearchText("");
		}
	}, [model]);
	// Đăng ký hook hiển thị với AG Grid theo đúng quy ước mới
	useGridFilterDisplay({ afterGuiAttached });

	// Model của ta lưu dạng mảng: string[] | null
	const selectedValues = useMemo(() => {
		return new Set(model?.values || allValues);
	}, [model, allValues]);

	// Hàm cập nhật model về cho AG Grid
	const updateModel = (nextSelected: Set<any>) => {
		if (nextSelected.size === allValues.length) {
			// Chọn tất cả = Tắt filter
			onModelChange(null);
		} else {
			// Truyền mảng giá trị được chọn sang cho doesFilterPass xử lý
			onModelChange({
				values: Array.from(nextSelected),
			});
		}
	};

	// Toggle từng Checkbox
	const handleToggleItem = (val: any) => {
		const next = new Set(selectedValues);
		if (next.has(val)) {
			next.delete(val);
		} else {
			next.add(val);
		}
		updateModel(next);
	};

	// Toggle Chọn Tất Cả
	const handleToggleSelectAll = (checked: boolean) => {
		const next = new Set(selectedValues);
		displayedValues.forEach((item: any) => {
			if (checked) next.add(item);
			else next.delete(item);
		});
		updateModel(next);
	};

	// Lọc danh sách hiển thị trong ô tìm kiếm
	const displayedValues = useMemo(() => {
		const itemsMatched = allValues.filter((item) =>
			String(item).toLowerCase().includes(searchText.toLowerCase()),
		);
		return itemsMatched;
	}, [allValues, searchText]);

	const isAllSelected =
		allValues.length > 0 && selectedValues.size === allValues.length;

	return (
		<div className="w-[220px] p-2 text-sm bg-popover text-popover-foreground flex flex-col gap-2">
			<div className="px-0.5">
				<Input
					ref={refInput}
					type="text"
					placeholder="Search"
					value={searchText}
					onChange={(e) => {
						setSearchText(e.target.value);
					}}
				/>
			</div>

			{/* Select All */}
			<div className="pb-1">
				<label className="flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer select-none font-medium hover:bg-accent hover:text-accent-foreground transition-colors">
					<Checkbox
						checked={isAllSelected}
						onCheckedChange={(checked) => handleToggleSelectAll(!!checked)}
					/>
					<span>Select all</span>
				</label>
			</div>

			<Separator />

			{/* Checkbox List Container */}
			<div className="max-h-[180px] overflow-y-auto flex flex-col gap-0.5">
				{displayedValues.map((val) => (
					<label
						key={String(val)}
						className="flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer select-none hover:bg-accent hover:text-accent-foreground transition-colors"
					>
						<Checkbox
							checked={selectedValues.has(val)}
							onCheckedChange={() => handleToggleItem(val)}
						/>
						<span className="flex-1 overflow-hidden text-ellipsis whitespace-nowrap">
							{String(val)}
						</span>
					</label>
				))}

				{displayedValues.length === 0 && (
					<div className="py-3 text-center text-muted-foreground">No data</div>
				)}
			</div>

			<Separator />

			{/* Clear */}
			<div className="flex justify-end">
				<Button
					variant="ghost"
					size="sm"
					onClick={() => {
						setSearchText("");
						onModelChange(null);
					}}
				>
					Clear
				</Button>
			</div>
		</div>
	);
};
